package com.nextplane.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zendesk.client.v2.Zendesk;
import org.zendesk.client.v2.model.Status;
import org.zendesk.client.v2.model.Ticket;

import com.nextplane.Constants.CRFed;
import com.nextplane.Constants.CRStatus;
import com.nextplane.Constants.DecisionStatus;
import com.nextplane.Constants.EmailContents;
import com.nextplane.Constants.Federation;
import com.nextplane.Constants.FederationType;
import com.nextplane.Constants.PFStatus;
import com.nextplane.Constants.Roles;
import com.nextplane.Constants.RuleMessaage;
import com.nextplane.Constants.TaskPriority;
import com.nextplane.Constants.TaskStatus;
import com.nextplane.Constants.UCFederationMessage;
import com.nextplane.Constants.ZendeskRef;
import com.nextplane.model.ActiveFederation;
import com.nextplane.model.ChangeRequest;
import com.nextplane.model.Company;
import com.nextplane.model.FedBaseRule;
import com.nextplane.model.FederationList;
import com.nextplane.model.PendingFederation;
import com.nextplane.model.PendingFederationList;
import com.nextplane.model.TaskRecords;
import com.nextplane.model.UCDomain;
import com.nextplane.model.User;
import com.nextplane.repository.ActiveFederationRepository;
import com.nextplane.repository.ChangeRequestRepository;
import com.nextplane.repository.CompanyRepository;
import com.nextplane.repository.FedBaseRuleRepository;
import com.nextplane.repository.MessagesRepository;
import com.nextplane.repository.NXPMPReferenceRepository;
import com.nextplane.repository.PendingFederationRepository;
import com.nextplane.repository.TaskRecordsHistoryRepository;
import com.nextplane.repository.TaskRecordsRepository;
import com.nextplane.repository.UCDomainRepository;
import com.nextplane.repository.UserRepository;
import com.nextplane.repository.UserRoleMappingRepository;

@Service
public class PendingFederationService {
	
	@Autowired
	PendingFederationRepository pendingFederationRepository;
	
	@Autowired
	ActiveFederationRepository activeFederationRepository;
	
	@Autowired
	NXPMPReferenceRepository nXPMPReferenceRepository;
	
	@Autowired
	UCDomainRepository ucdomainRepo;
	
	@Autowired
	FedBaseRuleRepository fedBaseRuleRepo;
	
	@Autowired
	MessagesRepository messagesRepo;
	
	@Autowired
	ChangeRequestRepository changeRequestRepository;
	
	@Autowired
	CompanyRepository companyRepository;

	@Autowired
	private FedCheckListService fedCheckListService;

	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRoleMappingRepository userRoleMappingRepository;

	@Autowired
	private TaskRecordsHistoryRepository taskRecordsHistoryRepository;
	
	@Autowired
	private TaskRecordsService taskRecordsService;
	
	@Autowired 
	private UserRepository userRepository;
	
	@Autowired
	private TaskRecordsRepository tRecordsRepository;

	@Autowired
	private TaskRecordsService taskService;
	
	Logger logger = LogManager.getLogger(PendingFederationService.class);
	
	/**
	 * 
	 * @param id
	 * @return
	 */
	public PendingFederation viewFederation(Long id ){
		PendingFederation fed = null;
		fed =  pendingFederationRepository.findById(id);
		return fed;
	}
	
	/**
	 * 
	 * @param pendingFederationApp
	 * @return
	 */
	public PendingFederation approveFederationByReceiver(PendingFederation  pendingFederationApp){
		PendingFederation pendingFederation = null; String emailTo = "";
		ChangeRequest changeRequest = null;
		pendingFederation =  pendingFederationRepository.findById(pendingFederationApp.getFedId());
		User user = userRepository.findByUserToken(pendingFederationApp.getUserToken());			
		if(pendingFederation != null && pendingFederationApp.getApprove() == 1) {
			fedCheckListService.createCheckLists(pendingFederation, user);
			pendingFederation.setDecisionStatus(nXPMPReferenceRepository.findByLname(DecisionStatus.APPROVED));
			createTaskHistory(pendingFederation.getId(), "", pendingFederation.getDestDomain().getDomainName(), user, TaskStatus.FED_APPROVED);

			// Mail send to src uc admin
			emailTo = userService.generateEmailUsers(pendingFederation.getSrcCompany());
			fedCheckListService.sendFederationNotification(pendingFederation, user, EmailContents.FEDRATION_APPROVED, "", emailTo+"\"");
			System.out.println("src fromEmail "+emailTo);
			
			// Mail send to desc uc admin
			emailTo = userService.generateEmailUsers(pendingFederation.getDestCompany());							
			fedCheckListService.sendFederationNotification(pendingFederation, user, EmailContents.FEDERATION_CHECKLIST_DESTDOMAAIN, "", emailTo);
			System.out.println("src fromEmail "+emailTo);
		
		} else if(pendingFederation != null && pendingFederationApp.getApprove() == 2) {
			pendingFederation.setDecisionStatus(nXPMPReferenceRepository.findByLname(DecisionStatus.REJECTED));
			changeRequest = pendingFederation.getChangeRequestId();
			changeRequest.setCrStatus(nXPMPReferenceRepository.findByLname(CRStatus.CR_REJECTED));
			changeRequestRepository.save(changeRequest);
			createTaskHistory(pendingFederation.getId(), "", pendingFederation.getDestDomain().getDomainName(), user, TaskStatus.FED_REJECTED);
			// Mail send to src uc admin
			emailTo = userService.generateEmailUsers(pendingFederation.getSrcCompany());
			fedCheckListService.sendFederationNotification(pendingFederation, user, EmailContents.NOTIFY_UCX_REJECTED, "", emailTo);
			System.out.println("src fromEmail "+emailTo);
			
		} else {
			pendingFederation.setDecisionStatus(nXPMPReferenceRepository.findByLname(DecisionStatus.CANCEL));	
			changeRequest = pendingFederation.getChangeRequestId();
			changeRequest.setCrStatus(nXPMPReferenceRepository.findByLname(CRStatus.CR_CANCELLED));
			changeRequestRepository.save(changeRequest);
			createTaskHistory(pendingFederation.getId(), pendingFederation.getSrcDomain().getDomainName(), "", user, TaskStatus.FED_CANCEL);
			
			// Mail send to desc uc admin
			emailTo = userService.generateEmailUsers(pendingFederation.getDestCompany());							
			fedCheckListService.sendFederationNotification(pendingFederation, user, EmailContents.NOTIFY_UC_CANCELLED, "", emailTo);

			System.out.println("desc fromEmail "+emailTo);
		}
		pendingFederationRepository.save(pendingFederation);
		
		return pendingFederation;
	}
	
	/**
	 * 
	 * @param list
	 * @return
	 */
	public List<PendingFederation> federationLogic(PendingFederationList list){
		
		List<Long> srcDomainId = list.getSrcDomainId();
		List<Long> destDomainId = list.getDestDomainId();
		List<PendingFederation> fedList = new ArrayList<PendingFederation>();
		PendingFederation fed = null;
		String message = "";
			// Check the federation compatibility between the domains 
			if(srcDomainId != null && destDomainId !=null){
				for(Long srcId :srcDomainId){
					//Get the source domain and if not null
					UCDomain srcDomain = ucdomainRepo.findById(srcId);
					if(srcDomain != null && srcDomain.getUcType() != null){
						for(Long destId : destDomainId){
							int count = 1;
							//Get the destination domain and if not null
							UCDomain destDomain = ucdomainRepo.findById(destId);
							
							if(destDomain != null && destDomain.getUcType()!=null){
								
								// check if federation already exists and is not cancelled								
								PendingFederation existingFed = pendingFederationRepository.findBysrcDomainAnddestDomain(srcDomain, destDomain,nXPMPReferenceRepository.findByLname(CRStatus.CR_ACTIVE),nXPMPReferenceRepository.findByLname(CRStatus.CR_COMPLETE));
																			
								System.out.println(srcDomain.getUcType().getUcprotocol() +" = "+ srcDomain.getOpenFed() +" = "+ srcDomain.getUcType().getId()
												 +" = "+ destDomain.getUcType().getUcprotocol() +" = "+ destDomain.getOpenFed() +" = "+ destDomain.getUcType().getId());

								
								Company company = companyRepository.findById(srcDomain.getCompanyid().getId());
								Long activeFedCount = activeFederationRepository.findActiveFederationCount(company);
								Long pendingFedCount = pendingFederationRepository.getSrcOrDestCompanyCount(company, DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED);
								if(pendingFedCount == null) pendingFedCount = 0L;
								if(activeFedCount != null) activeFedCount = 0L;
								if(existingFed == null && ((company.getAllowedFederations() == null) || (pendingFedCount+activeFedCount+count) > company.getAllowedFederations())) {
									message = messagesRepo.getmessage(RuleMessaage.MSGID6);
									fed = new PendingFederation(srcDomain, destDomain, message);	
								}else if(existingFed == null){
									FedBaseRule baseRule = null;
									
								// Find the baserule logic	
									if(srcDomain.getOpenFed() != null && destDomain.getOpenFed() == null)
										baseRule = fedBaseRuleRepo.findReceiverFedBaserule
											(srcDomain.getUcType().getUcprotocol(), srcDomain.getOpenFed(), srcDomain.getUcType().getId()
													, destDomain.getUcType().getUcprotocol(), destDomain.getUcType().getId());
									else if(srcDomain.getOpenFed() == null && destDomain.getOpenFed() != null)
										baseRule = fedBaseRuleRepo.findSenderFedBaserule
										(srcDomain.getUcType().getUcprotocol(), srcDomain.getUcType().getId()
												, destDomain.getUcType().getUcprotocol(), destDomain.getOpenFed(), destDomain.getUcType().getId());
									else if(srcDomain.getOpenFed() != null && destDomain.getOpenFed() != null)
										baseRule = fedBaseRuleRepo.findTop1FedBaserule
										(srcDomain.getUcType().getUcprotocol(), srcDomain.getOpenFed(), srcDomain.getUcType().getId()
												, destDomain.getUcType().getUcprotocol(), destDomain.getOpenFed(), destDomain.getUcType().getId());
								
									if(baseRule == null)
										baseRule = fedBaseRuleRepo.findFedBaserule
										(srcDomain.getUcType().getUcprotocol(), srcDomain.getUcType().getId()
												, destDomain.getUcType().getUcprotocol(), destDomain.getUcType().getId());
									//System.out.println(baseRule.toString());
									if(baseRule != null){
										if(baseRule.getGenerateError()){
											message = messagesRepo.getmessage(baseRule.getErrorMsg().getId());
											fed = new PendingFederation(srcDomain, destDomain, message);
										}else if(!baseRule.getGenerateError()){
											message = nXPMPReferenceRepository.getDName(FederationType.CHAT);
											fed = new PendingFederation(srcDomain, destDomain, message);	
										}
									}									
								}else{
									message = messagesRepo.getmessage(RuleMessaage.MSGID5);
									fed = new PendingFederation(srcDomain, destDomain, message);								  
								}
								fedList.add(fed);
							}	
							count++;
						}
					}
					
				}
				
			}		
		return fedList;
	}
	
	/**
	 * 
	 * @param request
	 * @param fedList
	 * @param userEmail
	 * @param user
	 * @return
	 */
	@Transactional
	public Boolean saveFederation(HttpServletRequest request , PendingFederationList fedList, String userEmail, User user){
		List<PendingFederation> lists = null;
		List<String> fedSave = new ArrayList<String>();
		Boolean fedSaveStatus = false;	
			lists = this.federationLogic(fedList);
			if(lists != null){
			    for(PendingFederation pendingFederaton :lists){
			    	if(pendingFederaton != null && pendingFederaton.getFedStatus() != null){
						if(pendingFederaton.getFedStatus().equals(nXPMPReferenceRepository.findByLname(FederationType.CHAT).getDname())){
							// set decision status to approved if auto approve is true
							if(pendingFederaton.getDestDomain().getCompanyid().isAutoApproveFederation() != null && pendingFederaton.getDestDomain().getCompanyid().isAutoApproveFederation() == true){
								pendingFederaton.setDecisionStatus(nXPMPReferenceRepository.findByLname(DecisionStatus.APPROVED));
							}else{
								pendingFederaton.setDecisionStatus(null);
							}
							
							if(pendingFederaton.getSrcDomain() != null)
								pendingFederaton.setSrcCompany(pendingFederaton.getSrcDomain().getCompanyid());
							if(pendingFederaton.getDestDomain() != null)
								pendingFederaton.setDestCompany(pendingFederaton.getDestDomain().getCompanyid());
							 	 
							//String requestUser, NXPMPReference crType, NXPMPReference crStatus, Company company ,Date dateCreated ,UCDomain pendingDomainId
							ChangeRequest changeRequest = new ChangeRequest(userEmail,nXPMPReferenceRepository.findByLname(CRFed.IM_FEDERATION),nXPMPReferenceRepository.findByLname(CRStatus.CR_ACTIVE),pendingFederaton.getSrcDomain().getCompanyid(),new Date(),pendingFederaton.getSrcDomain());
							//set the change request to pending federation
							changeRequest.setLastUpdated(new Date());
							changeRequestRepository.save(changeRequest);
							
							//set the changerequest to the federation
							pendingFederaton.setChangeRequestId(changeRequest);
							
							pendingFederaton.setDateCreated(new Date());
							pendingFederaton.setLastUpdated(new Date());
							
							//set Federation type - IM and Presence (default)
							pendingFederaton.setFedType(nXPMPReferenceRepository.findByLname(FederationType.CHAT));
							
							// set the federation status to submitted 
							pendingFederaton.setPfStatus(nXPMPReferenceRepository.findByLname(PFStatus.SUBMITTED));
							pendingFederationRepository.save(pendingFederaton);
							
							TaskRecords taskObj = new TaskRecords(
									user, Federation.FEDERATION, new Date(), 
									null, pendingFederaton.getSrcDomain(),  
									pendingFederaton.getDestDomain(),  new Date());
							Long commonTaskId = taskRecordsService.createFederationTask(taskObj, pendingFederaton, Integer.parseInt(nXPMPReferenceRepository.findOneByLnameAndType(TaskPriority.ONE, TaskPriority.type).getDname()));		
							pendingFederaton.setCommonTaskId(commonTaskId); 
							pendingFederationRepository.save(pendingFederaton);	
							
							taskRecordsService.updateTaskHistory(
									taskRecordsService.getReferenceValueForHistory(TaskStatus.FEDERATION),
									user,
									pendingFederaton.getId(),
									pendingFederaton.getSrcDomain().getDomainName(),
									"",
									taskRecordsService.getReferenceValueForHistory(
											TaskStatus.FED_CREATED).replace("$date",
											taskRecordsService.getDateString(new Date())), 0,
									new Date());
							
							fedSaveStatus = true;
							// set the status to true if there is IM and Presence
							fedSave.add(pendingFederaton.getId().toString()+ " :  save is "+fedSaveStatus.toString());
							if(pendingFederaton.getDestDomain().getCompanyid().isAutoApproveFederation() == true) {
								pendingFederaton.setApprove(1L);
								approveFederationByReceiver(pendingFederaton);
							}else {
								String emailTo = userService.generateEmailUsers(pendingFederaton.getDestCompany());						
								fedCheckListService.sendFederationNotification(pendingFederaton, user, EmailContents.NOTIFY_UC_FEDERATION_CREATED, "", emailTo);
							}
						}
			    	} else{
			    		fedSaveStatus = false;
			    		fedSave.add( " id is null :  save  is "+fedSaveStatus.toString());
			    	}
			    	
				}
			}
		return fedSaveStatus;
	}
	
	/**
	 * 
	 * @param company
	 * @param userToken
	 * @return
	 */
	public Long getPendingFederationCount(Company company, String userToken) {
		Long pendingFedCount = null;		
		if(userService.isSuperAdmin(userToken , Roles.ROLE_SUPER_ADMIN))
			pendingFedCount = pendingFederationRepository.getAllPendingFederationCount(DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED);
		else {
			pendingFedCount = pendingFederationRepository.getFederationCount(company, DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED);
		}
		return pendingFedCount;
	}
	/**
	 * 
	 * @param company
	 * @param userToken
	 * @return
	 */
	public Long getActiveFederationCount(Company company, String userToken) {		
		Long ActiveFedCount = null;		
		if(userService.isSuperAdmin(userToken , Roles.ROLE_SUPER_ADMIN))
			ActiveFedCount = activeFederationRepository.findAllActiveFederationCount();
		else
			ActiveFedCount = activeFederationRepository.findActiveFederationCount(company);		
		return ActiveFedCount;
	}
	/**
	 * 
	 * @param company
	 * @param userToken
	 * @return
	 */
	public Long getIncommingFederationCount(Company company, String userToken) {		
		Long incommingFedCount = pendingFederationRepository.getIncommingFederationCount(company, DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED);		
		return incommingFedCount;
	}
	
	/**
	 * 
	 * @param user
	 * @param company
	 * @param page
	 * @return
	 */
	public Page<FederationList> getPendingFederationCompanies(User user, Company company , Pageable page){
		Page<FederationList> pendingCompanies = null;	
		if(userService.isSuperAdmin(user.getUserToken() , Roles.ROLE_SUPER_ADMIN))
			pendingCompanies = pendingFederationRepository.getPendingCompaniesForUCX(DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED, page);
		else
			pendingCompanies = pendingFederationRepository.getPendingCompanies(company, DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED, page);
		return pendingCompanies;
	}
	
	/**
	 * 
	 * @param user
	 * @param company
	 * @param name
	 * @param page
	 * @return
	 */
	public Page<FederationList> searchPendingFederationCompanies(User user, Company company ,String name,  Pageable page){
		Page<FederationList> pendingCompanies = null;
		if(userService.isSuperAdmin(user.getUserToken() , Roles.ROLE_SUPER_ADMIN))
			pendingCompanies = pendingFederationRepository.searchPendingCompaniesForUCX(name, DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED, page);
		else
			pendingCompanies = pendingFederationRepository.searchPendingCompanies(company, name, DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED, page);
		return pendingCompanies;
	}
	
	/**
	 * 
	 * @param user
	 * @param company
	 * @param page
	 * @return
	 */
	public Page<FederationList> getIncomingFederationCompanies(User user, Company company , Pageable page){
		Page<FederationList> pendingCompanies = null;
		if(userService.isSuperAdmin(user.getUserToken() , Roles.ROLE_SUPER_ADMIN))
			pendingCompanies = pendingFederationRepository.getAllIncomingCompanies(DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED, page);
		else
			pendingCompanies = pendingFederationRepository.getIncomingCompanies(company, DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED, page);
		return pendingCompanies;
	}
	/**
	 * 
	 * @param user
	 * @param company
	 * @param name
	 * @param page
	 * @return
	 */
	public Page<FederationList> searchIncomingFederationCompanies(User user, Company company ,String name, Pageable page){
		Page<FederationList> pendingCompanies = null;	
		if(userService.isSuperAdmin(user.getUserToken() , Roles.ROLE_SUPER_ADMIN))
			pendingCompanies = pendingFederationRepository.searchAllIncominCompanies(DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED, page);
		else
			pendingCompanies = pendingFederationRepository.searchIncominCompanies(company, name, DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED, page);
			
		return pendingCompanies;
	}
	
	/**
	 * 
	 * @param user
	 * @param company
	 * @param page
	 * @return
	 */
	public Page<FederationList> getActiveFederationCompanies(User user, Company company , Pageable page){
		Page<FederationList> pendingCompanies = null;
		if (userService.isSuperAdmin(user.getUserToken(), Roles.ROLE_SUPER_ADMIN))
			pendingCompanies = activeFederationRepository .getActiveFederationsForcompanyForUCX(page);
		else
			pendingCompanies = activeFederationRepository.getActiveFederationsForcompany(company, page);
		return pendingCompanies;
	}
	
	/**
	 * 
	 * @param user
	 * @param company
	 * @param name
	 * @param page
	 * @return
	 */
	public Page<FederationList> searchActiveFederationCompanies(User user, Company company , String name , Pageable page){
		Page<FederationList> pendingCompanies = null;
		if(userService.isSuperAdmin(user.getUserToken() , Roles.ROLE_SUPER_ADMIN))
			pendingCompanies = activeFederationRepository.searchActiveFederationsForcompanyForUCX( name, page);
		else
			pendingCompanies = activeFederationRepository.searchActiveFederationsForcompany(company, name, page);
		return pendingCompanies;
	}
	
	
	public PendingFederation getDomainDate(long id) {
		Date d = null;
		PendingFederation domain = new PendingFederation();
		try {
			d = pendingFederationRepository.getDomainDate(id);
			domain.setDateCreated(d);
		} catch (Exception e) {
			logger.error("Exception in getDomainDate "+e.getMessage());
		}

		return domain;
	}
	
	public List<PendingFederation> findBySrcCompany(Company company,Pageable page){
		
		//Page<PendingFederation> fedList = null;
		List<PendingFederation> fedList = null;
		try {
			
			//fedList = fedRepo.findBySrcCompany(company, page);
			fedList = pendingFederationRepository.findBySrcCompany(company);
			
			
		} catch (Exception e) {
			logger.error("Exception e  "+ e.getMessage());
		}
		return fedList;
	}
	

	public  HashMap<String , List<PendingFederation>> viewPendingFederationForCompany(User user, Company srcCompany,Company desCompany){		
		HashMap<String , List<PendingFederation>> pendingFed = new HashMap<String, List<PendingFederation>>();
		String companyName = "";
		desCompany  = companyRepository.findById(desCompany.getId());
		if(desCompany != null)
			companyName = desCompany.getName();
		List<PendingFederation> list = null;
		if(userService.isSuperAdmin(user.getUserToken() , Roles.ROLE_SUPER_ADMIN))
			list = pendingFederationRepository.getSrcCompanyOrDestCompanyUCX(desCompany, DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED);
		else
			list = pendingFederationRepository.getSrcCompanyAndDestCompany(srcCompany, desCompany, DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED);
			System.out.println(list);
		//List<PendingFederation> list = fedRepo.findDestCompanyAndDecisionStatus(srcCompany, desCompany,nxpmpRepo.findByLname(DecisionStatus.REJECTED), nxpmpRepo.findByLname(DecisionStatus.CANCEL));
		pendingFed.put(companyName, list);
		return pendingFed;
	}
	

	public  HashMap<String , List<PendingFederation>> viewIncomingFederationForCompany(Company srcCompany,Company desCompany){
		
		HashMap<String , List<PendingFederation>> pendingFed = new HashMap<String, List<PendingFederation>>();
		String companyName = "";
		try {
			srcCompany  = companyRepository.findById(srcCompany.getId());
			if(srcCompany != null)
				companyName = srcCompany.getName();
			
			
		    List<PendingFederation> list = pendingFederationRepository.getSrcCompanyAndDestCompany(srcCompany, desCompany, DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED);
			
		    pendingFed.put(companyName, list);
		
		
			
		} catch (Exception e) {
			logger.error("Exception in viewIncomingFederationForCompany : "+e.getMessage() );
		}
		return pendingFed;
	}
	
	
	public  HashMap<String , List<ActiveFederation>> viewActiveFederationForCompany(User user, Company thisCompany , Company otherCompany){
		HashMap<String , List<ActiveFederation>> pendingFed = new HashMap<String, List<ActiveFederation>>();
		String companyName = "";
			otherCompany  = companyRepository.findById(otherCompany.getId());
			if(otherCompany != null)
				companyName = otherCompany.getName();
			List<ActiveFederation> list = null;
			if(userService.isSuperAdmin(user.getUserToken() , Roles.ROLE_SUPER_ADMIN)) {
				list = activeFederationRepository.findAllActiveFederationWithCompanyUCX(otherCompany);
			} else
				list = activeFederationRepository.findActiveFederationWithCompany(thisCompany, otherCompany);				
		    pendingFed.put(companyName, list);
		return pendingFed;
	}
	

	public ActiveFederation approveFederationByUCX(Long id){
		ActiveFederation activeFed = null;
		try {
			
			PendingFederation fed = pendingFederationRepository.findById(id);
			if(fed != null){

				ChangeRequest changeRequest = fed.getChangeRequestId();
				
				if(changeRequest != null){
					changeRequest.setCrStatus(nXPMPReferenceRepository.findByLname(CRStatus.CR_COMPLETE));
					changeRequestRepository.save(changeRequest);
					 activeFed = new ActiveFederation(fed.getSrcDomain(), fed.getSrcCompany(), fed.getDestDomain(), fed.getDestCompany(), fed.getFedType(), new Date());	
					activeFederationRepository.save(activeFed);
					
				}else{
					throw new Exception(UCFederationMessage.ERROR_CR_NULL);
				}
					
			}else{
				throw new Exception(UCFederationMessage.ERROR_PF_NULL);
			}
			
			
		} catch (Exception e) {
			if(e.getMessage().contains(UCFederationMessage.ERROR_CR_NULL))
					logger.error("Exception in approveFederationByUCX  "+UCFederationMessage.ERROR_CR_NULL+" : "+e.getMessage());
			else if(e.getMessage().contains(UCFederationMessage.ERROR_PF_NULL))
				logger.error("Exception in approveFederationByUCX  "+UCFederationMessage.ERROR_PF_NULL+" : "+e.getMessage());
			else
				logger.error("Exception in approveFederationByUCX  "+e.getMessage());
		}
		
		return activeFed;
		
	}
	

	/**
	 * Get pending federation
	 * @param pendingFederation
	 * @return
	 */
	public PendingFederation getPendingFederation(PendingFederation pendingFederation){
		pendingFederation = pendingFederationRepository.findOne(pendingFederation.getFedId());
		pendingFederation.setTaskRecordsHistory(taskRecordsHistoryRepository.findAllByDfIdAndTypeOrderById(pendingFederation.getId(), taskRecordsService.getReferenceValueForHistory(TaskStatus.FEDERATION)));
		return pendingFederation;
	}
	
	/**
	 * Approve or reject federation
	 * @param approve
	 * @param id
	 * @return
	 */
	public PendingFederation approveUcx(PendingFederation pendingFederationApp){
		PendingFederation pendingFederation = null;
		pendingFederation =  pendingFederationRepository.findById(pendingFederationApp.getFedId());
		User user = userRepository.findByUserToken(pendingFederationApp.getUserToken());	
		if(pendingFederation != null && pendingFederationApp.getApprove() == 1) {
			pendingFederation.setDecisionStatus(nXPMPReferenceRepository.findByLname(DecisionStatus.UCXAPPROVED));
			ChangeRequest changeRequest = pendingFederation.getChangeRequestId();			
			if(changeRequest != null){
				changeRequest.setCrStatus(nXPMPReferenceRepository.findByLname(CRStatus.CR_COMPLETE));
				changeRequestRepository.save(changeRequest);
				ActiveFederation activeFederation = new ActiveFederation(pendingFederation.getSrcDomain(), pendingFederation.getSrcCompany(), pendingFederation.getDestDomain(), pendingFederation.getDestCompany(), pendingFederation.getFedType(), new Date());	
				activeFederationRepository.save(activeFederation);
			}

			// Mail send to src uc admin
			String fromEmail = userService.generateEmailUsers(pendingFederationApp.getSrcCompany());
			fedCheckListService.sendFederationNotification(pendingFederationApp, user, EmailContents.FEDERATION_CHECKLIST_SRCDOMAIN, "", fromEmail+"\"");
		
			// Mail send to desc uc admin
			fromEmail = userService.generateEmailUsers(pendingFederationApp.getDestCompany());							
			fedCheckListService.sendFederationNotification(pendingFederationApp, user, EmailContents.FEDERATION_CHECKLIST_DESTDOMAAIN, "", fromEmail+"\"");
		
			createTaskHistory(pendingFederation.getId(), pendingFederation.getSrcDomain().getDomainName(),pendingFederation.getDestDomain().getDomainName(), user, TaskStatus.FED_UCXAPPROVED);
			
			taskService.updateTaskHistory(
				taskService.getReferenceValueForHistory("DOMAIN"), user,
				pendingFederation.getSrcDomain().getId(),
				pendingFederation.getSrcDomain().getDomainName(), "",
				TaskStatus.FEDERATATED.replace("$domain", pendingFederation.getDestDomain().getDomainName()), 0, new Date());
			
			taskService.updateTaskHistory(
				taskService.getReferenceValueForHistory("DOMAIN"), user,
				pendingFederation.getDestDomain().getId(),
				pendingFederation.getDestDomain().getDomainName(), "",
				TaskStatus.FEDERATATED.replace("$domain", pendingFederation.getSrcDomain().getDomainName()), 0,
				new Date());
		} else {
			pendingFederation.setDecisionStatus(nXPMPReferenceRepository.findByLname(DecisionStatus.UCXREJECTED));	
			createTaskHistory(pendingFederation.getId(), pendingFederation.getSrcDomain().getDomainName(), pendingFederation.getDestDomain().getDomainName(), user, TaskStatus.FED_UCXREJECTED);
		}
		
		TaskRecords taskRecords = tRecordsRepository.findLastTask(pendingFederation.getCommonTaskId());	
		taskRecordsService.updateCurrentTasks(taskRecords.getId());
		
		closeZendeskFederationTicket(pendingFederation);
		pendingFederationRepository.save(pendingFederation);		
		return pendingFederation;
	}
	
	/**
	 * 
	 * @param id
	 * @param srcDomainName
	 * @param desDomainName
	 * @param user
	 * @param taskType
	 */
	public void  createTaskHistory(Long id, String srcDomainName, String desDomainName, User user, String taskType) {		
		taskRecordsService.updateTaskHistory(
				taskRecordsService.getReferenceValueForHistory(TaskStatus.FEDERATION),
				user,
				id,
				srcDomainName,
				desDomainName,
				taskRecordsService.getReferenceValueForHistory(taskType).replace("$date",
						taskRecordsService.getDateString(new Date())), 0,
				new Date());
	}	

	public Ticket closeZendeskFederationTicket(PendingFederation pendingFederation){
		Ticket t = null;		
		String requester = nXPMPReferenceRepository.findByLname(ZendeskRef.REQUESTER).getDname();
		String url = nXPMPReferenceRepository.findByLname(ZendeskRef.URL).getDname();
		String requesterPassword = nXPMPReferenceRepository.findByLname(ZendeskRef.REQUESTER_PASSWORD).getDname();
		String token = nXPMPReferenceRepository.findByLname(ZendeskRef.TOKEN).getDname();
		Zendesk zd = null;
		try {
			if( token !=null && token.length() != 0 && requesterPassword != null && requesterPassword.length() != 0){
				zd = new Zendesk.Builder(url)
		        .setUsername(requester)
		        .setPassword(requesterPassword)
		        .setToken(token)
		        .build();
			}else if(token !=null && token.length() != 0 ){
				zd = new Zendesk.Builder(url)
		        .setUsername(requester)
		        .setToken(token)
		        .build();
			} else if(requesterPassword != null && requesterPassword.length() != 0){
				zd = new Zendesk.Builder(url)
		        .setUsername(requester)
		        .setPassword(requesterPassword)
		        .build();
			} else{
				zd = new Zendesk.Builder(url)
		        .setUsername(requester)
		        .build();
			}
			
			for( Ticket ticket : zd.getTickets()){				
				if(ticket.getSubject() != null && ticket.getSubject().contains(pendingFederation.getSrcDomain().getDomainName()) && ticket.getSubject().contains(pendingFederation.getDestDomain().getDomainName())){
					if(ticket.getStatus() == Status.OPEN ){
						ticket.setStatus(Status.CLOSED);
						zd.updateTicket(ticket);
						t=ticket;
					}					
				}
			}
		} catch (Exception e) {
			logger.error("Exception in closing the ticket"+e.getMessage());
		}		
		return t;
		
	}

	/**
	 * 
	 * @param userToken
	 * @return Boolean
	 */
	public Boolean getFedStatus(String userToken) {
		Boolean flag = true;
		User user = userRepository.findByUserToken(userToken);
		Company company = companyRepository.findById(user.getCompanyId().getId());
		Long activeFedCount = activeFederationRepository.findActiveFederationCount(company);
		Long pendingFedCount = pendingFederationRepository.getSrcOrDestCompanyCount(company, DecisionStatus.UCXAPPROVED, DecisionStatus.UCXREJECTED, DecisionStatus.CANCEL, DecisionStatus.REJECTED);
		if((pendingFedCount+activeFedCount) >= company.getAllowedFederations())
			flag = false;
		return flag;
	}
}
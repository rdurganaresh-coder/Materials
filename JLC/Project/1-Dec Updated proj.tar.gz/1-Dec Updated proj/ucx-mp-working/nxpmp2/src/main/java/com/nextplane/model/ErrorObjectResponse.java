package com.nextplane.model;

import java.util.ArrayList;
import java.util.List;

public class ErrorObjectResponse extends ResponseBean {
 
	private final Object response;

	public ErrorObjectResponse(int status, Object response) {
		super(status);
		this.response = response;
	}

	public ErrorObjectResponse(int status, String errMsg) {
		super(status);
		List<String> errorList = new ArrayList<String>();
		errorList.add(errMsg);
		this.response = errorList;
	}

	
	
	public Object getResponse() {
		return response;
	}

}

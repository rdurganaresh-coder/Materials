package com.nextplane.model;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;

public class PageableNxp {

	private String userToken;
	private int page;
	private int size;
    private String sort;
	private Direction order;
	private Pageable pageable;
	private String sSearch;
	private String vSearch;
	private String sortOrder;
	
	public String getUserToken() {
		return userToken;
	}
	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
    public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
    public Direction getOrder() {
		return order;
	}
	public void setOrder(Direction order) {
		this.order = order;
	}
	public Pageable getPageable() {
		return pageable;
	}
	public void setPageable() {
		this.pageable = new PageRequest(this.page, this.size, this.order, this.sort);
	}	
	public String getsSearch() {
		return sSearch;
	}
	public void setsSearch(String sSearch) {
		this.sSearch = "tr."+sSearch;
	}
	public String getvSearch() {
		return vSearch;
	}
	public void setvSearch(String vSearch) {
		this.vSearch = vSearch;
	}
	
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
}

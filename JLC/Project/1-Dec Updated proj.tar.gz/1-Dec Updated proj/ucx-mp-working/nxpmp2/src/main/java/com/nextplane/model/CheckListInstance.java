package com.nextplane.model;

/**
 * Module       : Check List management
 * Table		: check_list_instance
 * Class        : CheckListInstance
 * 
 * Created Date : 12/08/2016
 * Created By   : SVCIT NXPMP3
 */

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name="check_list_instance")
public class CheckListInstance {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	private boolean checked;
	private String checker;
	private long domainId;
	
	private String mnemonic;
	private Long refId1;
	private String refId2;
	private String scope;
	private String taskTemplateCode;

	@OneToOne
	@JoinColumn(name = "checklistId")
	private UCChecklists checklistId;
	
	@Version
	private long version;	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getVersion() {
		return version;
	}
	public void setVersion(long version) {
		this.version = version;
	}
	public boolean isChecked() {
		return checked;
	}
	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	public long getDomainid() {
		return domainId;
	}
	public void setDomainid(long domainId) {
		this.domainId = domainId;
	}
	public String getMnemonic() {
		return mnemonic;
	}
	public void setMnemonic(String mnemonic) {
		this.mnemonic = mnemonic;
	}
	public Long getRefId1() {
		return refId1;
	}
	public void setRefid1(Long refId1) {
		this.refId1 = refId1;
	}
	public String getRefId2() {
		return refId2;
	}
	public void setRefId2(String refId2) {
		this.refId2 = refId2;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	public String getChecker() {
		return checker;
	}
	public void setChecker(String checker) {
		this.checker = checker;
	}
	public String getTaskTemplateCode() {
		return taskTemplateCode;
	}
	public void setTaskTemplateCode(String taskTemplateCode) {
		this.taskTemplateCode = taskTemplateCode;
	}

	public long getDomainId() {
		return domainId;
	}
	public UCChecklists getChecklistId() {
		return checklistId;
	}
	public void setDomainId(long domainId) {
		this.domainId = domainId;
	}
	public void setChecklistId(UCChecklists checklistId) {
		this.checklistId = checklistId;
	}
	public CheckListInstance(){}
	
	public CheckListInstance(boolean checked, String checker,
			long domainId, String mnemonic, Long refId1,
			String refId2, String scope, String taskTemplateCode, long version) {
		super();
		this.checked = checked;
		this.checker = checker;
		this.domainId = domainId;
		this.mnemonic = mnemonic;
		this.refId1 = refId1;
		this.refId2 = refId2;
		this.scope = scope;
		this.taskTemplateCode = taskTemplateCode;
		this.version = version;
	}
	
	public CheckListInstance(boolean checked, String checker,
			long domainId, String mnemonic, Long refId1,
			String refId2, String scope, String taskTemplateCode, long version,UCChecklists checklistId) {
		super();
		this.checked = checked;
		this.checker = checker;
		this.domainId = domainId;
		this.mnemonic = mnemonic;
		this.refId1 = refId1;
		this.refId2 = refId2;
		this.scope = scope;
		this.taskTemplateCode = taskTemplateCode;
		this.version = version;
		this.checklistId = checklistId;
	}
}
package com.nextplane.model;

import java.util.List;

/**
 * Module       : Search
 * Class        : SearchValue
 * 
 * Created Date : 16/08/2016
 * Created By   : SVCIT NXPMP3
 */

public class SearchValue {

	private Long ucId;
	private boolean openFed;
	private Long domainId;
	private Long receiverDomainId;
	private String domainName;
	private String port;
	private String edgeName;
	private List<Long> checkedId;
	private Long changeRequestId;
	private Long currentTaskId;
	private Long pendingFederationId;
	private String userToken;
	private Long fedType;
	
	public Long getUcId() {
		return ucId;
	}
	public void setUcId(Long ucId) {
		this.ucId = ucId;
	}
	public boolean isOpenFed() {
		return openFed;
	}
	public void setOpenFed(boolean openFed) {
		this.openFed = openFed;
	}	
	public Long getDomainId() {
		return domainId;
	}
	public void setDomainId(Long domainId) {
		this.domainId = domainId;
	}
	public Long getReceiverDomainId() {
		return receiverDomainId;
	}
	public void setReceiverDomainId(Long receiverDomainId) {
		this.receiverDomainId = receiverDomainId;
	}	
	public String getDomainName() {
		return domainName;
	}
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}	
	public String getEdgeName() {
		return edgeName;
	}
	public void setEdgeName(String edgeName) {
		this.edgeName = edgeName;
	}
	public List<Long> getCheckedId() {
		return checkedId;
	}
	public void setCheckedId(List<Long> checkedId) {
		this.checkedId = checkedId;
	}
	public Long getChangeRequestId() {
		return changeRequestId;
	}
	public void setChangeRequestId(Long changeRequestId) {
		this.changeRequestId = changeRequestId;
	}
	public Long getCurrentTaskId() {
		return currentTaskId;
	}
	public void setCurrentTaskId(Long currentTaskId) {
		this.currentTaskId = currentTaskId;
	}
	public Long getpendingFederationId() {
		return pendingFederationId;
	}
	public void setpendingFederationId(Long pendingFederationId) {
		this.pendingFederationId = pendingFederationId;
	}
	public String getUserToken() {
		return userToken;
	}
	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}
	public Long getFedType() {
		return fedType;
	}
	public void setFedType(Long fedType) {
		this.fedType = fedType;
	}
}

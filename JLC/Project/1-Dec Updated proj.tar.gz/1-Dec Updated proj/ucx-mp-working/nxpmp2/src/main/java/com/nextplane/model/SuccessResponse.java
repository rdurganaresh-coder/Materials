package com.nextplane.model;

/**
 * Module       : Task management
 * Class        : Task Controller
 * 
 * Created Date : 27/07/2016
 * Created By   : SVCIT NXPMP3
 */

import com.nextplane.Constants.ResponseStatus;

public class SuccessResponse extends ResponseBean {

	private Object objResponse;
	private String message;

	public SuccessResponse() {
		super(ResponseStatus.SUCCESS);
	}
	
	public SuccessResponse(Object objResponse) {
		super(ResponseStatus.SUCCESS);
		this.objResponse = objResponse;
	}
	
	public Object getObjResponse() {
		return objResponse;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public void setObjResponse(Object objResponse, String message) {
		this.objResponse = objResponse;
		this.message = message;
	}

}

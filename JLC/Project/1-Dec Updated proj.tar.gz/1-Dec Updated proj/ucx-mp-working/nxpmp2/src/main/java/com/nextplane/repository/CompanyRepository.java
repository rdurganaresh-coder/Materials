package com.nextplane.repository;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.nextplane.model.Company;
import com.nextplane.model.NXPMPReference;

@Transactional
public interface CompanyRepository extends PagingAndSortingRepository<Company, Long> {
	@Query(" from Company c  where c.membershipType =250")
	List<Company> findSponsers();

	List<Company> findByMembershipTypeOrMembershipType(NXPMPReference id,NXPMPReference id2);
	
	@Query("from Company c where c.membershipType in (select id from NXPMPReference where lname = ?1 or lname = ?2)")
	List<Company> getSponsernames(String type1,String type2);
	
	List<Company> findByMembershipType(long id);
	
	Company findByName(String name); 
	
	Page<Company> findAllByNameLike(String name,Pageable page);
	Company findById(Long id);
	
	List<Company> findAllByIsDisabledOrderByName(boolean isDisabled);
	
	Page<Company> findAllByIsDisabled(boolean isDisabled,Pageable page);
	
	@Query("FROM Company AS c where c.isDisabled = ?1 AND c.id != ?2 ")
	List<Company> getAlldirctory(boolean isDisabled, Long id, Pageable page);

	List<Company> findByIsDisabledAndIdNot(boolean isDisabled, Long id, Pageable page);
}
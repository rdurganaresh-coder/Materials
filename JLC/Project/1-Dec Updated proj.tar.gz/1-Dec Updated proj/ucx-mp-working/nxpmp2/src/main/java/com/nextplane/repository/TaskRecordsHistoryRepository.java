package com.nextplane.repository;
/**
 * Module       : Task History management
 * Class        : Task Records History Repository
 * 
 * Created Date : 24/08/2016
 * Created By   : SVCIT NXPMP3
 */
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.nextplane.model.TaskRecordsHistory;

public interface TaskRecordsHistoryRepository extends JpaRepository<TaskRecordsHistory, Long> {
	
	List<TaskRecordsHistory> findAllByDfIdAndType(Long id,String type);	
	//List<TaskRecordsHistory> findAllByDfIdAndTypeAndCreatedByNotNull(Long id,String type);
	List<TaskRecordsHistory> findTop1ByDfIdAndTypeAndCreatedByNullOrderByCreatedTimeDesc(Long id,String type);
	@Transactional
	void deleteByDfId(Long id);

	List<TaskRecordsHistory> findAllByDfIdAndTypeOrderById(Long id,String type);
}

package com.nextplane.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nextplane.CommonUtils;
import com.nextplane.Constants.DomainMessage;
import com.nextplane.Constants.Federation;
import com.nextplane.Constants.ResponseMessage;
import com.nextplane.Constants.ResponseStatus;
import com.nextplane.Constants.UCFederationMessage;
import com.nextplane.model.ActiveFederation;
import com.nextplane.model.Company;
import com.nextplane.model.FederationList;
import com.nextplane.model.PageableNxp;
import com.nextplane.model.PendingFederationList;
import com.nextplane.model.ResponseBean;
import com.nextplane.model.UCDomain;
import com.nextplane.model.PendingFederation;
import com.nextplane.model.User;
import com.nextplane.service.PendingFederationService;
import com.nextplane.service.TaskRecordsService;
import com.nextplane.service.UCDomainService;
import com.nextplane.service.UserService;

@Controller
@RequestMapping(value = "/ucfederation")
public class PendingFederationController {
	
	@Autowired
	private UCDomainService domainService;

	@Autowired
	private PendingFederationService fedService;

	@Autowired
	private UserService userService;

	@Autowired
	private TaskRecordsService taskService;
	
	@Autowired
	private UCDomainService uCDomainService;

	@Value("${page}")
	private String PAGE;
	@Value("${limit}")
	private String LIMIT;
	@Value("${direction}")
	private String DIRECTION;
	@Value("${roles.3}")
	private String ROLE_SUPER_ADMIN;

	Logger logger = LogManager.getLogger(PendingFederationController.class);
	
	  @RequestMapping(path = "/listDomains",method = RequestMethod.POST,produces = "application/json")
	    @ResponseBody   

	    public ResponseBean listDomains(HttpServletRequest request , HttpServletResponse respons, @RequestBody PendingFederation ucFed){
	    	
		// get the user token .
			String userToken = ucFed.getUserToken();
			List<UCDomain> domains = null;
			try {
				if (userToken == null
						|| (userToken != null && userToken.equals(""))) {
					throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
				} else if (!userService.checkAdminToken(userToken)) {
					throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
				}

				// update the token time ..
				userService.updateAdminTokenTime(userToken);

				Company company = userService.getUserFromToken(userToken).getCompanyId();
				domains = domainService.getDomainsForFederation(company, null);
				if(domains == null){
					throw new Exception(UCFederationMessage.ERROR_LIST_DOMAINS);
				}

	    	
	  }catch(Exception e){
		  if (e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_INVALID);

			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else {
				logger.error(UCFederationMessage.ERROR_LIST_DOMAINS);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						UCFederationMessage.ERROR_LIST_DOMAINS);

			}
	  }
			return CommonUtils.getResponseBean(domains,UCFederationMessage.LIST_DOMAINS);
	  }


	  @RequestMapping(path = "/getCompanies",method = RequestMethod.POST,produces = "application/json")
	    @ResponseBody   

	    public ResponseBean getDestinationCompanies(HttpServletRequest request , HttpServletResponse respons, @RequestBody PendingFederation ucFed){
	    	
		// get the user token .
			String userToken = ucFed.getUserToken();
			Long id = null;
			Page<Company> companies = null;
			PageRequest page1 = null;
			PageableNxp pageableNXP =null;
		
					
			try {
				
				if (userToken == null
						|| (userToken != null && userToken.equals(""))) {
					throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
				} else if (!userService.checkAdminToken(userToken)) {
					throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
				} // update the token time ..
				userService.updateAdminTokenTime(userToken);
				if (ucFed.getPageable() != null) {
					pageableNXP = ucFed.getPageable();
					if (pageableNXP.getSort() == null)
						pageableNXP.setSort("name");
					if (pageableNXP.getSortOrder() == null)
						pageableNXP.setOrder(Direction.ASC);
					else {
						if (pageableNXP.getSortOrder().equals(DIRECTION))
							pageableNXP.setOrder(Direction.ASC);
						else
							pageableNXP.setOrder(Direction.DESC);

					}

				} else {
					pageableNXP = new PageableNxp();
					pageableNXP.setSort("name");
					pageableNXP.setOrder(Direction.ASC);
					pageableNXP.setPage(new Integer(PAGE));
					pageableNXP.setSize(new Integer(LIMIT));
				}
				page1 = new PageRequest(pageableNXP.getPage(),
						pageableNXP.getSize(), pageableNXP.getOrder(),
						pageableNXP.getSort());
				

				Company company = userService.getUserFromToken(userToken).getCompanyId();
				if(company != null )
					id = company.getId();
				if(ucFed.getCompanyName() != null)
					companies = domainService.searchDestinationCompaniesForFederation(id,"%"+ucFed.getCompanyName()+"%",page1);
				else
					companies = domainService.getDestinationCompaniesForFederation(id, page1);
				if(companies == null){
					throw new Exception(UCFederationMessage.ERROR_LIST_COMPANIES);
				}	

			}catch(Exception e){
			  if (e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)) {
					logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
					return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
							ResponseMessage.ADMIN_TOKEN_INVALID);
	
				} else if (e.getMessage().contains(
						ResponseMessage.ADMIN_TOKEN_EMPTY)) {
					logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
					return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
							ResponseMessage.ADMIN_TOKEN_EMPTY);
	
				} else {
					logger.error(UCFederationMessage.ERROR_LIST_COMPANIES);
					return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
							UCFederationMessage.ERROR_LIST_COMPANIES);
	
				}
			  
	  }
			return CommonUtils.getResponseBean(companies,
					UCFederationMessage.LIST_COMPANIES);
	  }
	  
	    @RequestMapping(path = "/getSelectedDomains",method = RequestMethod.POST,produces = "application/json")
	    @ResponseBody
	    public ResponseBean getSelectedDomains(HttpServletRequest request , HttpServletResponse respons, @RequestBody PendingFederation ucFed){
	    	
			String userToken = ucFed.getUserToken();
			HashMap<String,List<UCDomain>> companies = null;
				
				try {
					
					if (userToken == null
							|| (userToken != null && userToken.equals(""))) {
						throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
					} else if (!userService.checkAdminToken(userToken)) {
						throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
					} 

					// update the token time ..

					userService.updateAdminTokenTime(userToken);

					companies = domainService.getDestinationDomainsForSelectedCompanies(ucFed.getCompanyIds());
					if(companies == null){
						throw new Exception(UCFederationMessage.ERROR_LIST_DOMAINS);
					}

				}catch(Exception e){
		  
				  if (e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)) {
						logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
						return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
								ResponseMessage.ADMIN_TOKEN_INVALID);
		
					} else if (e.getMessage().contains(
							ResponseMessage.ADMIN_TOKEN_EMPTY)) {
						logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
						return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
								ResponseMessage.ADMIN_TOKEN_EMPTY);
		
					} else {
						logger.error(UCFederationMessage.ERROR_LIST_DOMAINS);
						return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
								UCFederationMessage.ERROR_LIST_DOMAINS);
		
					}
			}
				return CommonUtils.getResponseBean(companies,UCFederationMessage.LIST_COMPANIES);
	  }


	  		@RequestMapping(path = "/viewFederation",method = RequestMethod.POST,produces = "application/json")
		    @ResponseBody
		    public ResponseBean viewFederation(HttpServletRequest request , HttpServletResponse respons, @RequestBody FederationList ucFed){
		    	
			// get the user token .
				String userToken = ucFed.getUserToken();
				Company otherCompany = ucFed.getCompany();
				int type = ucFed.getType();
				HashMap<String, List<PendingFederation>> pendingList = null;
				HashMap<String, List<ActiveFederation>> activeList = null;
			/*	try {
					if (userToken == null
							|| (userToken != null && userToken.equals(""))) {
						throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
					} else if (!userService.checkAdminToken(userToken)) {
						throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
					}*/
					// update the token time ..
					userService.updateAdminTokenTime(userToken);
					Company thisCompany = userService.getUserFromToken(userToken).getCompanyId();

					//  get the active federations from active_federation 
					if(type == Integer.parseInt(Federation.ACTIVEFED)){	
						activeList = fedService.viewActiveFederationForCompany(userService.getUserFromToken(userToken), thisCompany,otherCompany);
					/*	if( activeList == null ){
							throw new Exception(UCFederationMessage.ERROR_VIEW_FED);
						}*/		
						return CommonUtils.getResponseBean(activeList,	UCFederationMessage.VIEW_FED);
						
					}else if(type == Integer.parseInt(Federation.PENDINDFED)){
						// get Pending federations
						pendingList = fedService.viewPendingFederationForCompany(userService.getUserFromToken(userToken), thisCompany, otherCompany);
						/*if(pendingList == null ){
							throw new Exception(UCFederationMessage.ERROR_VIEW_FED);
						}*/
						return CommonUtils.getResponseBean(pendingList,	UCFederationMessage.VIEW_FED);
					}else if(type == Integer.parseInt(Federation.INCOMINGFED)){
						
						// get Incoming
						pendingList = fedService.viewIncomingFederationForCompany(otherCompany, thisCompany);
						/*if(pendingList == null){
							throw new Exception(UCFederationMessage.ERROR_VIEW_FED);
						}*/
						return CommonUtils.getResponseBean(pendingList,	UCFederationMessage.VIEW_FED);
					}else 
						return CommonUtils.getErrorResponseBean(ResponseStatus.FED_VIEW_FAILURE,"No Federation saved"); 
					
					//fed = fedService.viewFederation(ucFed.getFedId());
				/*	 if(pendingList == null || activeList == null ){
						throw new Exception(UCFederationMessage.ERROR_VIEW_FED);
					}
	*/
		    	
				/*}catch(Exception e){
					  if (e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)) {
							logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
							return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
									ResponseMessage.ADMIN_TOKEN_INVALID);
			
						} else if (e.getMessage().contains(
								ResponseMessage.ADMIN_TOKEN_EMPTY)) {
							logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
							return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
									ResponseMessage.ADMIN_TOKEN_EMPTY);
			
						} else {
							logger.error(UCFederationMessage.ERROR_VIEW_FED);
							return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
									UCFederationMessage.ERROR_VIEW_FED);
			
						}
			  
				}*/
//			return CommonUtils.getResponseBean(fed,	UCFederationMessage.VIEW_FED);
		  }
		  	  
	  @RequestMapping(path = "/approveFedReceiver",method = RequestMethod.POST,produces = "application/json")
	    @ResponseBody   

	    public ResponseBean approveFedReceiver(HttpServletRequest request , HttpServletResponse respons, @RequestBody PendingFederation ucFed){
	    	
		// get the user token .
			String userToken = ucFed.getUserToken();
			PendingFederation fed = null;
			try {
				if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
				} else if (!userService.checkAdminToken(userToken)) {
			throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
				}
				// update the token time ..
				userService.updateAdminTokenTime(userToken);

				fed = fedService.approveFederationByReceiver(ucFed);
				 if(fed == null){
					throw new Exception(UCFederationMessage.ERROR_REC_APPROVE_FED);
				}

	    
			}catch(Exception e){
				  if (e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)) {
						logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
						return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
								ResponseMessage.ADMIN_TOKEN_INVALID);
		
					} else if (e.getMessage().contains(
							ResponseMessage.ADMIN_TOKEN_EMPTY)) {
						logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
						return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
								ResponseMessage.ADMIN_TOKEN_EMPTY);
		
					} else {
						logger.error(UCFederationMessage.ERROR_REC_APPROVE_FED);
						return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
								UCFederationMessage.ERROR_REC_APPROVE_FED);
		
					}
			}
			
			if(ucFed.getFedId() != null && ucFed.getApprove() == 1)
				return CommonUtils.getResponseBean(fed, UCFederationMessage.REC_APPROVE_FED);				
			else if(ucFed.getFedId() != null && ucFed.getApprove() == 2)
				return CommonUtils.getResponseBean(fed, UCFederationMessage.REC_REJECTED_FED);	
			else
				return CommonUtils.getResponseBean(fed, UCFederationMessage.REC_CANCEL_FED);				
	  }


	  

	  @RequestMapping(path = "/federationLogic",method = RequestMethod.POST,produces = "application/json")
	    @ResponseBody   
	    public ResponseBean federationLogic(HttpServletRequest request , HttpServletResponse respons, @RequestBody PendingFederationList ucFedList){
	    	
			// get the user token .
				String userToken = ucFedList.getUserToken();
				List<PendingFederation> fedList = null;
							
				try {
					
						if (userToken == null
								|| (userToken != null && userToken.equals(""))) {
							throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
						} else if (!userService.checkAdminToken(userToken)) {
							throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
						}
	
						// update the token time ..
						userService.updateAdminTokenTime(userToken);
						
						// Get the list of possible 
						fedList = fedService.federationLogic(ucFedList);
						if(fedList==null || fedList.isEmpty()){
							throw new Exception(UCFederationMessage.ERROR_LIST_FED_LOGIC);
						}
				}catch(Exception e){
					  if (e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)) {
							logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
							return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
									ResponseMessage.ADMIN_TOKEN_INVALID);
		
						} else if (e.getMessage().contains(
								ResponseMessage.ADMIN_TOKEN_EMPTY)) {
							logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
							return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
									ResponseMessage.ADMIN_TOKEN_EMPTY);
		
						} else {
							logger.error(UCFederationMessage.ERROR_LIST_FED_LOGIC);
							return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
									UCFederationMessage.ERROR_LIST_FED_LOGIC);

						}
			  
			}
				return CommonUtils.getResponseBean(fedList,UCFederationMessage.LIST_FED_LOGIC);
		  }


	  @RequestMapping(path = "/saveFederation",method = RequestMethod.POST,produces = "application/json")
	    @ResponseBody   
	    public ResponseBean saveFederation(HttpServletRequest request , HttpServletResponse respons, @RequestBody PendingFederationList ucFedList){
	    	
			// get the user token .
				String userToken = ucFedList.getUserToken();
				String userEmail = "";
				
				Boolean fedsave= false;
							
				try {
					
					if (userToken == null
							|| (userToken != null && userToken.equals(""))) {
						throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
					} else if (!userService.checkAdminToken(userToken)) {
						throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
					}
					// update the token time ..

					userService.updateAdminTokenTime(userToken);
				
					//Get the user email from userTOken
					User user = userService.getUserFromToken(userToken);
					if(user != null)
						userEmail = user.getEmail();
					
					// Save the federation ,  
					fedsave = fedService.saveFederation(request,ucFedList, userEmail, user);
					if(fedsave == null){
						throw new Exception(UCFederationMessage.EXCEPTION_SAVE_FED_LOGIC);
					}else if(!fedsave){
						throw new Exception(UCFederationMessage.ERROR_SAVE_FED_LOGIC);
					}
				}catch(Exception e){
					  if (e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)) {
							logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
							return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
									ResponseMessage.ADMIN_TOKEN_INVALID);
		
						} else if (e.getMessage().contains(
								ResponseMessage.ADMIN_TOKEN_EMPTY)) {
							logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
							return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
									ResponseMessage.ADMIN_TOKEN_EMPTY);
		
						} else if  (e.getMessage().contains(
								UCFederationMessage.EXCEPTION_SAVE_FED_LOGIC)) {
							logger.error(UCFederationMessage.EXCEPTION_SAVE_FED_LOGIC);
							return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
									UCFederationMessage.EXCEPTION_SAVE_FED_LOGIC+" "+e.getMessage());

				}
			  
		  }
				if(!fedsave)
					return CommonUtils.getErrorResponseBean(ResponseStatus.FED_SAVE_FAILURE,"No Federation saved"); 
				else 
					return CommonUtils.getResponseBean(fedsave,UCFederationMessage.SAVE_FED_LOGIC);
		  }	
	  
	  
	  
	  @RequestMapping(path = "/fedCount", method = RequestMethod.POST, produces = "application/json")
			@ResponseBody
		public ResponseBean  getFederationCount(HttpServletRequest request,
					HttpServletResponse response, @RequestBody PendingFederation fed) {

		  String userToken = fed.getUserToken();
		  HashMap<String, Long> fedCounts = new HashMap<String, Long>();
		  
		  try {
			  if (userToken == null
						|| (userToken != null && userToken.equals(""))) {
					throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
				} else if (!userService.checkAdminToken(userToken)) {
					throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
				}
				// update the token time ..

				userService.updateAdminTokenTime(userToken);

				  Company company = userService.getUserFromToken(userToken).getCompanyId();
				  fedCounts.put("PendingFedCount", fedService.getPendingFederationCount(company, userToken));
				  fedCounts.put("ActiveFedCount", fedService.getActiveFederationCount(company, userToken));
				  fedCounts.put("IncommingFedCount", fedService.getIncommingFederationCount(company, userToken));
  			}catch(Exception e){
				  if (e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)) {
						logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
						return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
								ResponseMessage.ADMIN_TOKEN_INVALID);
	
					} else if (e.getMessage().contains(
							ResponseMessage.ADMIN_TOKEN_EMPTY)) {
						logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
						return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
								ResponseMessage.ADMIN_TOKEN_EMPTY);
	
					} else if  (e.getMessage().contains(
							UCFederationMessage.EXCEPTION_SAVE_FED_LOGIC)) {
						logger.error(UCFederationMessage.EXCEPTION_SAVE_FED_LOGIC);
						return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
								UCFederationMessage.EXCEPTION_SAVE_FED_LOGIC+" "+e.getMessage());
						}
				  
			
  			}
		  return CommonUtils.getResponseBean(fedCounts,UCFederationMessage.FEDCOOUNT);
	  }
	  
	  @RequestMapping(path = "/pendinglist", method = RequestMethod.POST, produces = "application/json")
		@ResponseBody
		public ResponseBean listPendingFed(HttpServletRequest request,
				HttpServletResponse response, @RequestBody PendingFederation fed) {
			PageRequest page1 = null;
			PageableNxp pageableNXP = null;
			Page<FederationList> companyList = null;

			// get the user token .
			String userToken = fed.getUserToken();
			
			/*try {

				if (userToken == null
						|| (userToken != null && userToken.equals(""))) {
					throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
				} else if (!userService.checkAdminToken(userToken)) {
					throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
				}*/
				// update the token time ..
				userService.updateAdminTokenTime(userToken);
				Company company = userService.getUserFromToken(fed.getUserToken()).getCompanyId();
				if (fed.getPageable() != null) {
					pageableNXP = fed.getPageable();
					if (pageableNXP.getSort() == null || (pageableNXP.getSort() !=null && pageableNXP.getSort().equals("name")))
						pageableNXP.setSort("srcCompany.name");
					if (pageableNXP.getSortOrder() == null)
						pageableNXP.setOrder(Direction.ASC);
					else {
						if (pageableNXP.getSortOrder().equals(DIRECTION))
							pageableNXP.setOrder(Direction.ASC);
						else
							pageableNXP.setOrder(Direction.DESC);

					}

				} else {
					pageableNXP = new PageableNxp();
					pageableNXP.setSort("srcCompany.name");
					pageableNXP.setOrder(Direction.ASC);
					pageableNXP.setPage(new Integer(PAGE));
					pageableNXP.setSize(new Integer(LIMIT));
				}
				page1 = new PageRequest(pageableNXP.getPage(),
						pageableNXP.getSize(), pageableNXP.getOrder(),
						pageableNXP.getSort());
				
					if(fed.getCompanyName() != null){
						companyList = fedService.searchPendingFederationCompanies(userService.getUserFromToken(userToken), company, "%"+fed.getCompanyName()+"%", page1);
					} else{
						companyList = fedService.getPendingFederationCompanies(userService.getUserFromToken(userToken), company, page1);
					}
					
					
		/*	}catch (Exception e) {
				if (e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)) {
					logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
					return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
							ResponseMessage.ADMIN_TOKEN_INVALID);

				} else if (e.getMessage().contains(
						ResponseMessage.ADMIN_TOKEN_EMPTY)) {
					logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
					return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
							ResponseMessage.ADMIN_TOKEN_EMPTY);

				} else if (e.getMessage().contains(
						ResponseMessage.ADMIN_TOKEN_INVALID)) {
					logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
					return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
							ResponseMessage.ADMIN_TOKEN_INVALID);

				} else if (e.getMessage().contains(ResponseMessage.USER_NOTFOUND)) {
					logger.info("Error in saving the domain !!! " + e.getMessage());
					return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
							ResponseMessage.USER_NOTFOUND);

				} else {
					logger.info("Error in listing  the domain !!! "
							+ e.getMessage());
					return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
							UCFederationMessage.ERROR_PENDING_COMPANYLIST);				
					}
			}
*/
			return CommonUtils.getResponseBean(companyList,
					UCFederationMessage.PENDING_COMPANYLIST);
		}
	  
	  
	  @RequestMapping(path = "/incominglist", method = RequestMethod.POST, produces = "application/json")
		@ResponseBody
		public ResponseBean listIncomingFed(HttpServletRequest request,
				HttpServletResponse response, @RequestBody PendingFederation fed) {
			PageRequest page1 = null;
			PageableNxp pageableNXP =null;
			Page<FederationList> companyList = null;

			// get the user token .
			String userToken = fed.getUserToken();
			
			try {

				if (userToken == null
						|| (userToken != null && userToken.equals(""))) {
					throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
				} else if (!userService.checkAdminToken(userToken)) {
					throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
				}
				// update the token time ..
				userService.updateAdminTokenTime(userToken);
				Company company = userService.getUserFromToken(fed.getUserToken()).getCompanyId();
				if (fed.getPageable() != null) {
					pageableNXP =  fed.getPageable();
					if (pageableNXP.getSort() == null || (pageableNXP.getSort() !=null && pageableNXP.getSort().equals("name")))
						pageableNXP.setSort("srcCompany.name");
					if (pageableNXP.getSortOrder() == null)
						pageableNXP.setOrder(Direction.ASC);
					else {
						if (pageableNXP.getSortOrder().equals(DIRECTION))
							pageableNXP.setOrder(Direction.ASC);
						else
							pageableNXP.setOrder(Direction.DESC);
						}
				} else {
					pageableNXP = new PageableNxp();
					pageableNXP.setSort("srcCompany.name");
					pageableNXP.setOrder(Direction.ASC);
					pageableNXP.setPage(new Integer(PAGE));
					pageableNXP.setSize(new Integer(LIMIT));
				}
				page1 = new PageRequest(pageableNXP.getPage(),
						pageableNXP.getSize(), pageableNXP.getOrder(),
						pageableNXP.getSort());			
				if(fed.getCompanyName() != null){	
					companyList = fedService.searchIncomingFederationCompanies(userService.getUserFromToken(userToken), company, "%"+fed.getCompanyName()+"%", page1);
				} else{
					companyList = fedService.getIncomingFederationCompanies(userService.getUserFromToken(userToken), company, page1);
				}	
			}catch (Exception e) {
				if (e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)) {
					logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
					return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
							ResponseMessage.ADMIN_TOKEN_INVALID);

				} else if (e.getMessage().contains(
						ResponseMessage.ADMIN_TOKEN_EMPTY)) {
					logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
					return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
							ResponseMessage.ADMIN_TOKEN_EMPTY);

				} else if (e.getMessage().contains(
						ResponseMessage.ADMIN_TOKEN_INVALID)) {
					logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
					return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
							ResponseMessage.ADMIN_TOKEN_INVALID);

				} else if (e.getMessage().contains(ResponseMessage.USER_NOTFOUND)) {
					logger.info("Error in saving the domain !!! " + e.getMessage());
					return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
							ResponseMessage.USER_NOTFOUND);

				} else {
					logger.info("Error in listing  the domain !!! "
							+ e.getMessage());
					return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
							UCFederationMessage.ERROR_INCOMING_COMPANYLIST);
				}
			}

			return CommonUtils.getResponseBean(companyList,
					UCFederationMessage.INCOMING_COMPANYLIST);
		}
	  
	  
	  @RequestMapping(path = "/activelist", method = RequestMethod.POST, produces = "application/json")
		@ResponseBody
		public ResponseBean listActiveFed(HttpServletRequest request,
				HttpServletResponse response, @RequestBody ActiveFederation fed) {
			PageRequest page1 = null;
			PageableNxp pageableNXP = null;
			Page<FederationList> companyList = null;

			// get the user token .
			String userToken = fed.getUserToken();
			
			try {

				if (userToken == null
						|| (userToken != null && userToken.equals(""))) {	
					throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
				} else if (!userService.checkAdminToken(userToken)) {
					throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
				}
				// update the token time ..
				userService.updateAdminTokenTime(userToken);
				Company company = userService.getUserFromToken(fed.getUserToken()).getCompanyId();
				if (fed.getPageable() != null) {
					pageableNXP = fed.getPageable();
					if (pageableNXP.getSort() == null)
						pageableNXP.setSort("name");
					if (pageableNXP.getSortOrder() == null)
						pageableNXP.setOrder(Direction.ASC);
					else {
						if (pageableNXP.getSortOrder().equals(DIRECTION))
							pageableNXP.setOrder(Direction.ASC);
						else
							pageableNXP.setOrder(Direction.DESC);
						}

				} else {
					pageableNXP = new PageableNxp();
					pageableNXP.setSort("name");
					pageableNXP.setOrder(Direction.ASC);
					pageableNXP.setPage(new Integer(PAGE));
					pageableNXP.setSize(new Integer(LIMIT));
				}
				page1 = new PageRequest(pageableNXP.getPage(),
						pageableNXP.getSize(), pageableNXP.getOrder(),
						pageableNXP.getSort());		
			
			if (fed.getCompanyName() != null) {
				companyList = fedService.searchActiveFederationCompanies(userService.getUserFromToken(userToken), company, "%"
								+ fed.getCompanyName() + "%", page1);
			} else {
				companyList = fedService
						.getActiveFederationCompanies(userService.getUserFromToken(userToken),
								company, page1);
			}
			
			}catch (Exception e) {
				if (e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)) {
					logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
					return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
							ResponseMessage.ADMIN_TOKEN_INVALID);

				} else if (e.getMessage().contains(
						ResponseMessage.ADMIN_TOKEN_EMPTY)) {
					logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
					return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
							ResponseMessage.ADMIN_TOKEN_EMPTY);

				} else if (e.getMessage().contains(
						ResponseMessage.ADMIN_TOKEN_INVALID)) {
					logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
					return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
							ResponseMessage.ADMIN_TOKEN_INVALID);

				} else if (e.getMessage().contains(ResponseMessage.USER_NOTFOUND)) {
					logger.info("Error in saving the domain !!! " + e.getMessage());
					return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
							ResponseMessage.USER_NOTFOUND);

				} else {
					logger.info("Error in listing  the domain !!! "
							+ e.getMessage());
					return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
							UCFederationMessage.ERROR_INCOMING_COMPANYLIST);
				}
			}

			return CommonUtils.getResponseBean(companyList,
					UCFederationMessage.INCOMING_COMPANYLIST);
		}

	  @RequestMapping(path = "/test3", method = RequestMethod.POST, produces = "application/json")
		@ResponseBody
		public ResponseBean testDate(HttpServletRequest request,
				HttpServletResponse response, @RequestBody PendingFederation ucdomain) {

		  PendingFederation domain = new PendingFederation();
			try {
				domain = fedService.getDomainDate(ucdomain.getFedId());
			}

			catch (Exception e) {

			}

			return CommonUtils.getResponseBean(domain, DomainMessage.VIEW_DOMAIN);
		}
	  @RequestMapping(path = "/fedListCount", method = RequestMethod.POST, produces = "application/json")
			@ResponseBody
			public ResponseBean getFedCount(HttpServletRequest request,
					HttpServletResponse response, @RequestBody PendingFederation fed) {
				
				PageRequest page1 = null;
				PageableNxp pageableNXP =null;
				List<PendingFederation> companyList = null;

				// get the user token .
				String userToken = fed.getUserToken();

				try {

					if (userToken == null
							|| (userToken != null && userToken.equals(""))) {
						throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
					} else if (!userService.checkAdminToken(userToken)) {
						throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
					}
					// update the token time ..
					userService.updateAdminTokenTime(userToken);
					Company company = userService.getUserFromToken(fed.getUserToken()).getCompanyId();
					if (fed.getPageable() != null) {
						 pageableNXP = fed.getPageable();
						if (pageableNXP.getSort() == null)
							pageableNXP.setSort("name");
						if (pageableNXP.getSortOrder() == null)
							pageableNXP.setOrder(Direction.ASC);
						else {
							if (pageableNXP.getSortOrder().equals(DIRECTION))
								pageableNXP.setOrder(Direction.ASC);
							else
								pageableNXP.setOrder(Direction.DESC);
						}
					} else {
						pageableNXP = new PageableNxp();
						pageableNXP.setSort("name");
						pageableNXP.setOrder(Direction.ASC);
						pageableNXP.setPage(new Integer(PAGE));
						pageableNXP.setSize(new Integer(LIMIT));
					}
					page1 = new PageRequest(pageableNXP.getPage(),
							pageableNXP.getSize(), pageableNXP.getOrder(),
							pageableNXP.getSort());
					companyList = fedService.findBySrcCompany(company, page1);
				}catch (Exception e) {
					if (e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)) {
						logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
						return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
								ResponseMessage.ADMIN_TOKEN_INVALID);

					} else if (e.getMessage().contains(
							ResponseMessage.ADMIN_TOKEN_EMPTY)) {
						logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
						return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
								ResponseMessage.ADMIN_TOKEN_EMPTY);

					} else if (e.getMessage().contains(
							ResponseMessage.ADMIN_TOKEN_INVALID)) {
						logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
						return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
								ResponseMessage.ADMIN_TOKEN_INVALID);

					} else if (e.getMessage().contains(ResponseMessage.USER_NOTFOUND)) {
						logger.info("Error in saving the domain !!! " + e.getMessage());
						return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
								ResponseMessage.USER_NOTFOUND);

					} else {
						logger.info("Error in listing  the domain !!! "
								+ e.getMessage());
						return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
								UCFederationMessage.ERROR_INCOMING_COMPANYLIST);
					}
				}
				return CommonUtils.getResponseBean(companyList, DomainMessage.VIEW_DOMAIN);
			}
	  

	  	/** 
	  	 * get Pending Federation for view (UCX Approval) 14/10/2016
	  	 * @param request
	  	 * @param respons
	  	 * @param pendingFederation
	  	 * @return
	  	 */
		@RequestMapping(path = "/getOnePendingFederation", method = RequestMethod.POST, produces = "application/json")
		@ResponseBody
		public ResponseBean getOnePendingFederation(HttpServletRequest request, HttpServletResponse response, @RequestBody PendingFederation pendingFederation) {
			String userToken = pendingFederation.getUserToken();
			userService.updateAdminTokenTime(userToken);
			pendingFederation = fedService.getPendingFederation(pendingFederation);
			return CommonUtils.getResponseBean(pendingFederation, UCFederationMessage.REC_APPROVE_FED);
		}	  
		
		/**
		 * For approve ucx admin 13/10/2016
		 * close zendesk ticket
		 * @param request
		 * @param respons
		 * @param pendingFederation
		 * @return
		 */
		@RequestMapping(path = "/approveUcx", method = RequestMethod.POST, produces = "application/json")
		@ResponseBody
		public ResponseBean approveUcx(HttpServletRequest request, HttpServletResponse respons, @RequestBody PendingFederation pendingFederation) {
			String userToken = pendingFederation.getUserToken();
			userService.updateAdminTokenTime(userToken);
			pendingFederation = fedService.approveUcx(pendingFederation);
			return CommonUtils.getResponseBean(pendingFederation, UCFederationMessage.REC_APPROVE_FED);
		}
		
		/**
		 * 
		 * @param request
		 * @param respons
		 * @param userToken
		 * @return
		 */
		@RequestMapping(path = "/allowedFederarionCount", method = RequestMethod.POST, produces = "application/json")
		@ResponseBody
		public ResponseBean allowedFederarionCount(HttpServletRequest request, HttpServletResponse respons, @RequestHeader(value="userToken", required=true) String userToken) {
			Boolean flag = fedService.getFedStatus(userToken);
			if(flag == true)
				return CommonUtils.getResponseBean(flag, UCFederationMessage.FEDERATIONALLOWED);
			else
				return CommonUtils.getResponseBean(flag, UCFederationMessage.FEDERATIONNOTALLOWED);
		}
}
package com.nextplane.model;

/**
 * Module       : Task management
 * Class        : Task Type
 * 
 * Created Date : 27/07/2016
 * Created By   : SVCIT NXPMP3
 */

import javax.persistence.*;

@Entity
@Table(name = "task_type")
public class TaskType {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	private String taskDefKey;
	
	private String name;
	private String description;
	private String type;
	private String defultStatus;
	private int priority;
	private long prevTaskId;
	private long nextTaskId;	
	private String taskRole;		
	private String senderButton;
	private String receivercButton;

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTaskDefKey() {
		return taskDefKey;
	}
	public void setTaskDefKey(String taskDefKey) {
		this.taskDefKey = taskDefKey;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDefultStatus() {
		return defultStatus;
	}
	public void setDefultStatus(String defultStatus) {
		this.defultStatus = defultStatus;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public long getPrevTaskId() {
		return prevTaskId;
	}
	public void setPrevTaskId(long prevTaskId) {
		this.prevTaskId = prevTaskId;
	}
	public long getNextTaskId() {
		return nextTaskId;
	}
	public void setNextTaskId(long nextTaskId) {
		this.nextTaskId = nextTaskId;
	}
	public String getTaskRole() {
		return taskRole;
	}
	public void setTaskRole(String taskRole) {
		this.taskRole = taskRole;
	}
	public String getSenderButton() {
		return senderButton;
	}
	public void setSenderButton(String senderButton) {
		this.senderButton = senderButton;
	}
	public String getReceivercButton() {
		return receivercButton;
	}
	public void setReceivercButton(String receivercButton) {
		this.receivercButton = receivercButton;
	}
}

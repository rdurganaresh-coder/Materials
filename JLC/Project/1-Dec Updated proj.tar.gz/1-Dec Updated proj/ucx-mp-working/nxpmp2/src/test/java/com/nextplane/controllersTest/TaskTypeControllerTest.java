package com.nextplane.controllersTest;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.nextplane.controller.TaskTypeController;
import com.nextplane.model.ResponseBean;
import com.nextplane.model.TaskType;
import com.nextplane.model.User;
import com.nextplane.service.TaskTypeService;
import com.nextplane.service.UserService;

public class TaskTypeControllerTest {

	private TaskType taskType = null;

	@Autowired
	private TaskTypeController taskTypeController;

	@Before
	public void createObjects() throws Exception {
		System.out.println("@Before" + taskType);
		// userPositive.setId(Long.parseLong("1"));
		taskType = new TaskType();
		taskType.setId(2);
		taskType.setDescription("Test Description");

	}

	@Test
	public void create() {
		taskType = new TaskType();
		// taskType.setId(2);
		taskType.setDescription("Test Description");
		taskType.setDefultStatus("PENDING");
		taskType.setName("TASKNAME");
		System.out.println("@Test");
		System.out.println(taskType.getId());
		System.out.println(taskType.getDescription());
		// ResponseBean s =
		taskTypeController.create(taskType);
		assertNotNull(taskType);

	}

	@Test
	public void findOne() {
		taskType = new TaskType();
		taskType.setId(2);
		taskType.setDescription("Test Description");
		System.out.println("@Test");
		System.out.println(taskType.getId());
		System.out.println(taskType.getDescription());
		Pageable pageable = null;
		List<TaskType> a = taskTypeController.list(taskType.getDescription());
		assertNotNull(a);
	}

	@Test
	public void findAll() {
		taskType = new TaskType();
		taskType.setId(2);
		taskType.setDescription("Test Description");
		System.out.println("@Test");
		System.out.println(taskType.getId());
		System.out.println(taskType.getDescription());
		Pageable pageable = null;
		Page<TaskType> a = taskTypeController.list(pageable);
		System.out.println("-------------------" + a);
		// assertNotNull(taskType);

	}

	@After
	public void deleteObjects() throws Exception {
		System.out.println("@After");
	}

}

package com.nextplane.model;

/**
 * Module       : Check List management
 * Table		: uc_checklist_rules
 * Class        : UCChecklistRules
 * 
 * Created Date : 10/08/2016
 * Created By   : SVCIT NXPMP3
 */

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "uc_checklist_rules")
public class UCChecklistRules {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@OneToOne
	@JoinColumn(name="ucplatformId")
	private UCPlatform ucplatformId;	

	private boolean openFed;	
	private String srvDefaultRecord;	
	private char checklistGroup;
	private int port;
	private int srv;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public UCPlatform getUcplatformIdIndex() {
		return ucplatformId;
	}

	public void setUcplatformIdIndex(UCPlatform ucplatformId) {
		this.ucplatformId = ucplatformId;
	}
	
	public boolean isOpenFed() {
		return openFed;
	}

	public void setOpenFed(boolean openFed) {
		this.openFed = openFed;
	}

	public String getSrvDefaultRecord() {
		return srvDefaultRecord;
	}

	public void setSrvDefaultRecord(String srvDefaultRecord) {
		this.srvDefaultRecord = srvDefaultRecord;
	}

	public char getChecklistGroup() {
		return checklistGroup;
	}

	public void setChecklistGroup(char checklistGroup) {
		this.checklistGroup = checklistGroup;
	}

	public UCPlatform getUcplatformId() {
		return ucplatformId;
	}

	public void setUcplatformId(UCPlatform ucplatformId) {
		this.ucplatformId = ucplatformId;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public int getSrv() {
		return srv;
	}

	public void setSrv(int srv) {
		this.srv = srv;
	}

	public String toString(){
		return "UCChecklist_Rules id : "+this.id +" UC PLatform : "+this.ucplatformId +" Checklist group : "+this.checklistGroup; 
	}
}

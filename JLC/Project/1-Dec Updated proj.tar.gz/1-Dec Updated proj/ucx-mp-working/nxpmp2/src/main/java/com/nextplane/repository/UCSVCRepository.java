package com.nextplane.repository;

import java.util.List;
import java.util.SortedSet;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.UCSVC;
import com.nextplane.model.UCSVCDetails;


public interface UCSVCRepository extends CrudRepository<UCSVC, Long>{
	
	@Override
	public Iterable<UCSVC> findAll();

	@Query(" from UCSVC where isEnabled = true")
	public List<UCSVC> getEntitlements();
	
	@Query(" from UCSVCDetails where isEnabled = true")
	public List<UCSVCDetails> getUCSVCDetailsList();

	@Query(" from UCSVCDetails where id=?1")
	public UCSVCDetails getUCSVCDetails(long id);
	
	@Query("from UCSVC where isEnabled = true order by name")
	public List<UCSVC> sortedServices();
	
	
/*	UCSVC.where {
		isEnabled == true
	}
    query.list().sort { it.name }*/
 }
package com.nextplane.service;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

/**
 * Module       : File management
 * Class        : FileManagementService
 * 
 * Created Date : 22/11/2016
 * Created By   : SVCIT NXPMP3
 */

@Service
public class FileManagementService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FileManagementService.class);

	/**
	 * 
	 * Upload single file using Spring Controller
	 * @param name
	 * @param middleFileName
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public String uploadFileHandler(String name, String middleFileName, MultipartFile file) throws IOException {

		// Creating the directory to store file
		byte[] bytes = file.getBytes();
		String rootPath = System.getProperty("catalina.home");
		File dir = new File(rootPath + File.separator + name);
		System.out.println("Root Path = "+rootPath);		
		
		Date fileDate = new Date();
		DateFormat df = new SimpleDateFormat("MMddyyyy HH:mm:ss");
		String reportDate = df.format(fileDate);
		
		if (!dir.exists()) dir.mkdirs();
		String fileName = dir.getAbsolutePath() + File.separator + middleFileName + reportDate;
		
		// Create the file on server
		File serverFile = new File(fileName);
		BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
		stream.write(bytes);
		stream.close();	
		
		LOGGER.info("Server File Location=" + serverFile.getAbsolutePath());
		return fileName;
	}

	/**
	 * 
	 * Upload multiple file using Spring Controller
	 * @param names
	 * @param files
	 * @return
	 */
	public String uploadMultipleFileHandler(String[] names, MultipartFile[] files) {

		if (files.length != names.length)
			return "Mandatory information missing";

		String message = "";
		for (int i = 0; i < files.length; i++) {
			MultipartFile file = files[i];
			String name = names[i];
			try {
				byte[] bytes = file.getBytes();

				// Creating the directory to store file
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists())
					dir.mkdirs();

				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath() + File.separator + name);
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();

				LOGGER.info("Server File Location=" + serverFile.getAbsolutePath());

				message = message + "You successfully uploaded file=" + name + "<br />";
			} catch (Exception e) {
				return "You failed to upload " + name + " => " + e.getMessage();
			}
		}
		return message;
	}

	/**
	 * 
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public List<String> readFileHandler(String fileName) throws IOException {		
		String sCurrentLine;
		List<String> fileValues = new ArrayList<String>();
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		while ((sCurrentLine = br.readLine()) != null) {
			fileValues.add(sCurrentLine);
		}
		br.close();			
		return fileValues;
	}
}

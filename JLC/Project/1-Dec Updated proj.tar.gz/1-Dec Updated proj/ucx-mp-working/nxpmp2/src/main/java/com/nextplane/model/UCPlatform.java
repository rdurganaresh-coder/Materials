package com.nextplane.model;

/**
 * Module       : Domain management
 * Table		: ucplatform
 * Class        : UCPlatform
 * 
 * Created Date : 10/08/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "ucplatform")
public class UCPlatform {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	private String ucid;
	private String ucname;
	private String ucprotocol;
	private String ucstatus;
	private String edgename;
	
	@OneToOne
	@JoinColumn(name="ucbaseruleid")
	private UCBaseRule ucbaseruleid;
	
	@Transient
	private List<UCBaseRule> ruleList;	
	
	@Transient
	private long upid;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUcid() {
		return ucid;
	}

	public void setUcid(String ucid) {
		this.ucid = ucid;
	}

	public String getUcname() {
		return ucname;
	}

	public void setUcname(String ucname) {
		this.ucname = ucname;
	}

	public String getUcprotocol() {
		return ucprotocol;
	}

	public void setUcprotocol(String ucprotocol) {
		this.ucprotocol = ucprotocol;
	}

	public String getUcstatus() {
		return ucstatus;
	}

	public void setUcstatus(String ucstatus) {
		this.ucstatus = ucstatus;
	}

	public UCBaseRule getUcbaseruleid() {
		return ucbaseruleid;
	}

	public void setUcbaseruleid(UCBaseRule ucbaseruleid) {
		this.ucbaseruleid = ucbaseruleid;
	}

	public List<UCBaseRule> getRuleList() {
		return ruleList;
	}
	public void setRuleList(List<UCBaseRule> ruleList) {
		this.ruleList = ruleList;
	}

	public long getUpid() {
		return upid;
	}

	public void setUpid(long uid) {
		this.upid = uid;
	}
	
	public String getEdgename() {
		return edgename;
	}

	public void setEdgename(String edgename) {
		this.edgename = edgename;
	}

	public String toString() {
		return " UCPlatform  - id  : " + this.id + " UCName : " + this.ucname;
	}
}

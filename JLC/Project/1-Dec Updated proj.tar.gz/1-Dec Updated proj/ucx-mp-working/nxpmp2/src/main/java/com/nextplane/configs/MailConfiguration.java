package com.nextplane.configs;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

@Configuration
@PropertySource("classpath:mail.properties")
public class MailConfiguration {
	 @Value("${mail.protocol}")
	    private String protocol;
	    @Value("${mail.host}")
	    private String host;
	    @Value("${mail.port}")
	    private int port;
	    @Value("${mail.smtp.auth}")
	    private boolean auth;
	    @Value("${mail.smtp.starttls.enable}")
	    private boolean starttls;
	    @Value("${mail.from}")
	    private String from;
	    @Value("${mail.username}")
	    private String username;
	    @Value("${mail.password}")
	    private String password;
	    
	    
	    
	    @Bean
	    public JavaMailSender javaMailSender() {
	        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
	        Properties mailProperties = new Properties();
	        mailProperties.put("mail.smtp.auth", auth);
	        mailProperties.put("mail.smtp.starttls.enable", starttls);
		//added to test the issue with mail sending in AWS
 		    mailProperties.put("mail.smtp.ssl.trust", "smtp.1and1.com");
	        mailProperties.put("mail.debug", "true");
	        mailSender.setJavaMailProperties(mailProperties);
	        mailSender.setHost(host);
	        mailSender.setPort(587);
	        mailSender.setProtocol(protocol);
	        mailSender.setUsername("anju.p@siliconvalleycloudit.com");
	        mailSender.setPassword("anj2016npxs");
	        return mailSender;
	    }
}

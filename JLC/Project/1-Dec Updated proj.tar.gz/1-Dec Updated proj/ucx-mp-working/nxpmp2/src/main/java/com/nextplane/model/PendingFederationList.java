package com.nextplane.model;

import java.util.List;

public class PendingFederationList {

	String userToken ;
	List<PendingFederation> pendingFederation;
	
	List<Long> srcDomainId;
	List<Long> destDomainId;
	
	
	public String getUserToken() {
		return userToken;
	}
	public List<PendingFederation> getPendingFederation() {
		return pendingFederation;
	}
	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}
	public void setPendingFederation(List<PendingFederation> pendingFederation) {
		this.pendingFederation = pendingFederation;
	}

	public List<Long> getSrcDomainId() {
		return srcDomainId;
	}
	public List<Long> getDestDomainId() {
		return destDomainId;
	}
	public void setSrcDomainId(List<Long> srcDomainId) {
		this.srcDomainId = srcDomainId;
	}
	public void setDestDomainId(List<Long> destDomainId) {
		this.destDomainId = destDomainId;
	}
	
	
}

package com.nextplane.model;

/**
 * Module       : SRV Record management
 * Class        : SRV_Records
 * 
 * Created Date : 26/09/2016
 * Created By   : SVCIT NXPMP3
 */

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "srv_records")
public class SRVRecords {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@OneToOne
	@JoinColumn(name="domain_id")
	private UCDomain domainId;
	
	private String sipPort;
	private String xmppPort;
	
	private Boolean sipSrvRecord;
	private Boolean xmppSrvRecord;
	
	private String sipTarget;
	private String xmppTarget;
	
	private String sipSrvPort;
	private String xmppSrvPort;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}	
	public UCDomain getDomainId() {
		return domainId;
	}
	public void setDomainId(UCDomain domainId) {
		this.domainId = domainId;
	}
	public String getSipPort() {
		return sipPort;
	}
	public void setSipPort(String sipPort) {
		this.sipPort = sipPort;
	}
	public String getXmppPort() {
		return xmppPort;
	}
	public void setXmppPort(String xmppPort) {
		this.xmppPort = xmppPort;
	}
	public Boolean getSipSrvRecord() {
		return sipSrvRecord;
	}
	public void setSipSrvRecord(Boolean sipSrvRecord) {
		this.sipSrvRecord = sipSrvRecord;
	}
	public Boolean getXmppSrvRecord() {
		return xmppSrvRecord;
	}
	public void setXmppSrvRecord(Boolean xmppSrvRecord) {
		this.xmppSrvRecord = xmppSrvRecord;
	}
	public String getSipTarget() {
		return sipTarget;
	}
	public void setSipTarget(String sipTarget) {
		this.sipTarget = sipTarget;
	}
	public String getXmppTarget() {
		return xmppTarget;
	}
	public void setXmppTarget(String xmppTarget) {
		this.xmppTarget = xmppTarget;
	}
	public String getSipSrvPort() {
		return sipSrvPort;
	}
	public void setSipSrvPort(String sipSrvPort) {
		this.sipSrvPort = sipSrvPort;
	}	
	public String getXmppSrvPort() {
		return xmppSrvPort;
	}
	public void setXmppSrvPort(String xmppSrvPort) {
		this.xmppSrvPort = xmppSrvPort;
	}
	
	public String toString(){
		return "SRV - id"+this.id;
	}
	public SRVRecords(){	}
	public SRVRecords(UCDomain domainId, String sipPort,
			String xmppPort, Boolean sipSrvRecord, Boolean xmppSrvRecord,
			String xmppTarget, String sipSrvPort, String xmppSrvPort) {
		this.domainId = domainId;
		this.sipPort = sipPort;
		this.xmppPort = xmppPort;
		this.sipSrvRecord = sipSrvRecord;
		this.xmppSrvRecord = xmppSrvRecord;
		this.xmppTarget = xmppTarget;
		this.sipSrvPort = sipSrvPort;
		this.xmppSrvPort = xmppSrvPort;
	}
	
}

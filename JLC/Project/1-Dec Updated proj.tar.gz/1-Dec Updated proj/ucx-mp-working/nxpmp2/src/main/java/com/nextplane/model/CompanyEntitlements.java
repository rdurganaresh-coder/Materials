package com.nextplane.model;

public class CompanyEntitlements {

	//private long companyId;
	private UCSVC service;
	private long callVolume;
	private int yahooUserCount;
/*	public long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(long companyId) {
		this.companyId = companyId;
	}*/
	public UCSVC getService() {
		return service;
	}
	public void setService(UCSVC service) {
		this.service = service;
	}
	public long getCallVolume() {
		return callVolume;
	}
	public void setCallVolume(long callVolume) {
		this.callVolume = callVolume;
	}
	public int getYahooUserCount() {
		return yahooUserCount;
	}
	public void setYahooUserCount(int yahooUserCount) {
		this.yahooUserCount = yahooUserCount;
	}
	
	
	public CompanyEntitlements(){
		
	}
	
	public CompanyEntitlements(UCSVC service,long callVoume, int yahooUserCount){
		
		this.service = service;
		this.callVolume = callVoume;
		this.yahooUserCount = yahooUserCount;
	}

	
	public String toString(){
		return "Company Entitlements  -  service"+this.service+" call volume"+this.callVolume+" yahoo user count "+this.yahooUserCount;
	}

}

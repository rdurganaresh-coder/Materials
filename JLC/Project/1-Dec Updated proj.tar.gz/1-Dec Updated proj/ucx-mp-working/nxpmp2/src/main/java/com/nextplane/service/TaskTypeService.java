package com.nextplane.service;

/**
 * Module       : Task management
 * Class        : Task Controller
 * 
 * Created Date : 27/07/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.nextplane.model.TaskType;
import com.nextplane.repository.TaskTypeRepository;

@Service
public class TaskTypeService {

	@Autowired
	TaskTypeRepository taskTypeRepository;

	public TaskType createTask(TaskType task) {
		return taskTypeRepository.save(task);
	}

	public Page<TaskType> list(Pageable pageable) {
		return taskTypeRepository.findAll(pageable);
	}

	public TaskType list(long id) {
		return taskTypeRepository.findOne(id);
	}
	
	public List<TaskType> findByType(String type){
		return taskTypeRepository.findByType(type);
	}
	
	public List<TaskType> findByTypeOrderByPriority(String type){
		return taskTypeRepository.findByTypeOrderByPriority(type);
	}

	public TaskType findByTypeAndPriority(String formKey, int zero) {
		return taskTypeRepository.findByTypeAndPriority(formKey, zero);
	}

}

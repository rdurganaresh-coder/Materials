package com.nextplane;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;

@SpringBootApplication
public class NXPMPApplication extends SpringBootServletInitializer {
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(NXPMPApplication.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(NXPMPApplication.class, args);
		System.out.println("---------------------------------------------------------------------------- NXPMP Started -----------------------------------------------------------------------------------------------");
	}
}

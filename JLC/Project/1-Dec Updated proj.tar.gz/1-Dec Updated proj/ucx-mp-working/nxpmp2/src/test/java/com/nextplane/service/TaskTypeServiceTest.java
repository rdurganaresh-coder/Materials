package com.nextplane.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.nextplane.model.TaskType;
import com.nextplane.model.User;
import com.nextplane.service.UserService;

public class TaskTypeServiceTest {

	private TaskType taskType = null;

	@Autowired
	private TaskTypeService _taskTypeService;
	
	

	@Before
	public void createObjects() throws Exception {
		System.out.println("@Before"+taskType);
		//userPositive.setId(Long.parseLong("1"));
		taskType= new TaskType();
		taskType.setId(2);
		taskType.setDescription("Test Description");

	}

	
	
	
	@Test
	public void createTask() {
		taskType= new TaskType();
		//taskType.setId(2);
		taskType.setDescription("Test Description");
		System.out.println("@Test");
		System.out.println(taskType.getId());
		System.out.println(taskType.getDescription());
		TaskType a = _taskTypeService.createTask(taskType);
//		assertNotNull(taskType);

	}
	
	@Test
	public void findByType() {
		taskType= new TaskType();
		//taskType.setId(2);
		taskType.setDescription("Test Description");
		System.out.println("@Test");
		System.out.println(taskType.getId());
		System.out.println(taskType.getDescription());
		List<TaskType> taskList = _taskTypeService.findByType("Type");
//		assertNotNull(taskType);

	}

	
	@Test
	public void findOne() {
		taskType= new TaskType();
		taskType.setId(2);
		taskType.setDescription("Test Description");
		System.out.println("@Test");
		System.out.println(taskType.getId());
		System.out.println(taskType.getDescription());
		taskType = _taskTypeService.list(taskType.getId());
//		assertNotNull(taskType);

	}
	@Test
	public void findAll() {
		taskType= new TaskType();
		taskType.setId(2);
		taskType.setDescription("Test Description");
		System.out.println("@Test");
		System.out.println(taskType.getId());
		System.out.println(taskType.getDescription());
		Pageable pageable = null;
		Page<TaskType> a = _taskTypeService.list(pageable);
//		assertNotNull(taskType);

	}
	
	
	@After
	public void deleteObjects() throws Exception {
		System.out.println("@After");
	}

}

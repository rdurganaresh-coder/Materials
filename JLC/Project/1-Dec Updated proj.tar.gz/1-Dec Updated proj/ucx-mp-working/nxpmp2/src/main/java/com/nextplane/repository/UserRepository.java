package com.nextplane.repository;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.nextplane.model.Company;
import com.nextplane.model.User;

@Transactional
public interface UserRepository extends JpaRepository<User, Long> {
	<S extends User> S  save(S entity);
	User findByUsername(String username);
	User findByUsernameAndPassword(String username, String password);
	User findByEmailAndPasswordAndUserToken(String username, String password, String token);
	User findByEmail(String email);	
	User findByUserToken(String token);
	@Query("select password from User where email =?1 ")
	String  getPassword(String email);
	Page<User> findByFirstnameLikeOrLastnameLikeOrEmailLike(String firstname,String lastname,String email , Pageable page);
	List<User> findByCompanyId(Company id);	

	// user name & email for ucx admin
	@Query("select firstname, lastname, username, email from User where companyId =?1 ")
	List<User>  getUserByCompany(Company companyId);
	
}
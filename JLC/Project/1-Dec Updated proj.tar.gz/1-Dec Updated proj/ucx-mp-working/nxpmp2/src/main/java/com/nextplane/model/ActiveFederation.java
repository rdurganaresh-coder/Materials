package com.nextplane.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Version;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "active_federation")
public class ActiveFederation {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Version
	private Integer version;

	@JsonFormat(pattern="MM/dd/yyyy, hh:mm a")
	private Date dateCreated;
	
	@OneToOne
	@JoinColumn(name="src_domain_id")
	private UCDomain srcDomainId;

	@OneToOne
	@JoinColumn(name="dest_domain_id")
	private UCDomain desDomainId;

	@OneToOne
	@JoinColumn(name = "src_company")
	Company srcCompany;
	
	@OneToOne
	@JoinColumn(name = "dest_company")
	Company desCompany;
	
	@OneToOne
	@JoinColumn(name="fed_type")
	
	private NXPMPReference fedType;
	
	@Transient
	private String companyName;
	
	@Transient
	private String userToken;
	
	@Transient
	private PageableNxp pageable;

	public Long getId() {
		return id;
	}
	public Integer getVersion() {
		return version;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public UCDomain getSrcDomainId() {
		return srcDomainId;
	}
	public UCDomain getDesDomainId() {
		return desDomainId;
	}
	public NXPMPReference getFedType() {
		return fedType;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public void setSrcDomainId(UCDomain srcDomainId) {
		this.srcDomainId = srcDomainId;
	}
	public void setDesDomainId(UCDomain desDomainId) {
		this.desDomainId = desDomainId;
	}
	public Company getSrcCompany() {
		return srcCompany;
	}
	public void setSrcCompany(Company srcCompany) {
		this.srcCompany = srcCompany;
	}
	public Company getDesCompany() {
		return desCompany;
	}
	public void setDesCompany(Company desCompany) {
		this.desCompany = desCompany;
	}
	public void setFedType(NXPMPReference fedType) {
		this.fedType = fedType;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getUserToken() {
		return userToken;
	}
	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}
	public PageableNxp getPageable() {
		return pageable;
	}
	public void setPageable(PageableNxp pageable) {
		this.pageable = pageable;
	}
	public String toString(){
		return "AVtive FEderation - id"+this.id+" \t source domain  : "+this.srcDomainId+" \t destination domain id"+this.desDomainId;
	}
	
public ActiveFederation(){
		
	}
	
	public ActiveFederation(UCDomain srcDomain , Company srcCompany , UCDomain desDomain, Company desCompany, NXPMPReference fedType , Date dateCreated){
		
		this.srcDomainId = srcDomain;
		this.srcCompany = srcCompany;
		this.desCompany = desCompany;
		this.desDomainId = desDomain;
		this.fedType = fedType;
		this.dateCreated = dateCreated;
		
	}
}

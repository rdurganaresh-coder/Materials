package com.nextplane;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import javax.sql.DataSource;

import com.nextplane.NXPMPApplication;

@SpringBootApplication
@Configuration
@EnableJpaRepositories(entityManagerFactoryRef = "mysqlEntityManager")
public class NXPMPApplicationTests1 extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(NXPMPApplication.class, args);
		System.out.println("---------------------------------------------------------------------------- NXPMP Started -----------------------------------------------------------------------------------------------");
	}
	
	  @Primary
	  @ConfigurationProperties(prefix="spring.secondDatasource")
	  @Bean(name="mysqlEntityManager")
	  public DataSource testDataSource() {
	    return DataSourceBuilder.create().build();
	  }
/*	  @Bean(name="mysqlEntityManager")
	  public LocalContainerEntityManagerFactoryBean mySqlEntityManagerFactory(
	          EntityManagerFactoryBuilder builder){       
	      return builder.dataSource(mysqlDataSource())                
	              .packages("com.test.entity.db.mysql")
	              .build();
	  } */
}

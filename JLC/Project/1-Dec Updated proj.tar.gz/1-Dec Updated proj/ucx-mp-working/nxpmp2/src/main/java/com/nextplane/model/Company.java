package com.nextplane.model;

import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="company")
public class Company {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)	
	private Long id;
	
	@Version
	private Long version;

	private Boolean isDisabled;
	private Integer licenseCount;
	private Integer licenseConsumed;
	private Integer allowedFederations;
	
	@OneToOne
	@JoinColumn(name="membershipType")
	private NXPMPReference membershipType;
	
	@OneToOne
	@JoinColumn(name="contractType")
	private NXPMPReference contractType;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="companyType")
	private NXPMPReference companyType;
	 
	private Boolean valid;

	@NotNull
	private String name;

	@JsonFormat(pattern="MM/dd/yyyy")
	private Date renewalDate;
	
	@NotNull
	@JsonFormat(pattern="MM/dd/yyyy")
	private Date dateCreated;
	
	@NotNull
	@JsonFormat(pattern="MM/dd/yyyy")
	private Date lastUpdated;
	
	private Boolean agreementAccepted;
	
	private Boolean isPartner;
	
	private Boolean isReseller;
	private String agreementAcceptedBy;

	@JsonFormat(pattern="MM/dd/yyyy")
	private Date agreementAcceptedOn;
	private Integer contractTerm;
	private Long partnerId;
	private Long resellerId;
	
	@JsonFormat(pattern="MM/dd/yyyy")
	private Date serviceDate;
	private Long sponserId;
	
	private Boolean allowOnlyFederated;
	
	private Long udCompanyId;
	public Boolean allowCanOveride;
	private Long disclaimerId;
	private Integer intervalInMinutes;
	
	@NotNull
	private String internalName;
	private Boolean autoApproveFederation;
	
	@Transient
	private List<UCSVC> entitlements;
	@Transient
	private Boolean companyStatus;
	@Transient
	private Boolean companyExists;
	
	@Transient 
	private NXPMPReference country;
	
	@Transient 
	private NXPMPReference region;
	
	@Transient
	private String message;
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	@Transient
	List<CompanyEntitlements> companyEntitlements;
	
	public List<CompanyEntitlements> getCompanyEntitlements() {
		return companyEntitlements;
	}
	public void setCompanyEntitlements(List<CompanyEntitlements> companyEntitlements) {
		this.companyEntitlements = companyEntitlements;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getVersion() {
		return version;
	}
	public void setVersion(Long version) {
		this.version = version;
	}
	public Boolean isDisabled() {
		return isDisabled;
	}
	public void setDisabled(Boolean isDisabled) {
		this.isDisabled = isDisabled;
	}
	public Integer getLicenseCount() {
		return licenseCount;
	}
	public void setLicenseCount(Integer licenseCount) {
		this.licenseCount = licenseCount;
	}
	public Integer getLicenseConsumed() {
		return licenseConsumed;
	}
	public void setLicenseConsumed(Integer licenseConsumed) {
		this.licenseConsumed = licenseConsumed;
	}
	public Integer getAllowedFederations() {
		return allowedFederations;
	}
	public void setAllowedFederations(Integer allowedFederations) {
		this.allowedFederations = allowedFederations;
	}
	public void setMembershipType(NXPMPReference membershipType) {
		this.membershipType = membershipType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getRenewalDate() {
		return renewalDate;
	}
	public void setRenewalDate(Date renewalDate) {
		this.renewalDate = renewalDate;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public Boolean isAgreementAccepted() {
		return agreementAccepted;
	}
	public void setAgreementAccepted(Boolean agreementAccepted) {
		this.agreementAccepted = agreementAccepted;
	}
	public Boolean isPartner() {
		return isPartner;
	}
	public void setPartner(Boolean isPartner) {
		this.isPartner = isPartner;
	}
	public Boolean isReseller() {
		return isReseller;
	}
	public void setReseller(Boolean isReseller) {
		this.isReseller = isReseller;
	}
	public String getAgreementAcceptedBy() {
		return agreementAcceptedBy;
	}
	public void setAgreementAcceptedBy(String agreementAcceptedBy) {
		this.agreementAcceptedBy = agreementAcceptedBy;
	}
	public Date getAgreementAcceptedOn() {
		return agreementAcceptedOn;
	}
	public void setAgreementAcceptedOn(Date agreementAcceptedOn) {
		this.agreementAcceptedOn = agreementAcceptedOn;
	}
	public Integer getContractTerm() {
		return contractTerm;
	}
	public void setContractTerm(Integer contractTerm) {
		this.contractTerm = contractTerm;
	}
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	public Long getResellerId() {
		return resellerId;
	}
	public void setResellerId(Long resellerId) {
		this.resellerId = resellerId;
	}
	public Date getServiceDate() {
		return serviceDate;
	}
	public void setServiceDate(Date serviceDate) {
		this.serviceDate = serviceDate;
	}
	public Long getSponserId() {
		return sponserId;
	}
	public void setSponserId(Long sponserId) {
		this.sponserId = sponserId;
	}
	public Boolean isAllowOnlyFederated() {
		return allowOnlyFederated;
	}
	public void setAllowOnlyFederated(Boolean alloOnlyFederated) {
		this.allowOnlyFederated = alloOnlyFederated;
	}
	public Boolean isAllowCanOveride() {
		return allowCanOveride;
	}
	public void setAllowCanOveride(Boolean alloCanOveride) {
		this.allowCanOveride = alloCanOveride;
	}
	public Integer getIntervalInMinutes() {
		return intervalInMinutes;
	}
	public void setIntervalInMinutes(Integer intervalInMinutes) {
		this.intervalInMinutes = intervalInMinutes;
	}
	public String getInternalName() {
		return internalName;
	}
	public void setInternalName(String internalName) {
		this.internalName = internalName;
	}
	public Boolean isAutoApproveFederation() {
		return autoApproveFederation;
	}
	public void setAutoApproveFederation(Boolean autoApproveFederation) {
		this.autoApproveFederation = autoApproveFederation;
	}
	public NXPMPReference getContractType() {
		return contractType;
	}
	public void setContractType(NXPMPReference contractType) {
		this.contractType = contractType;
	}
	public NXPMPReference getCompanyType() {
		return companyType;
	}
	public void setCompanyType(NXPMPReference companyType) {
		this.companyType = companyType;
	}
	public NXPMPReference getMembershipType() {
		return membershipType;
	}
	public Long getUdCompanyId() {
		return udCompanyId;
	}
	public void setUdCompanyId(Long udCompanyId) {
		this.udCompanyId = udCompanyId;
	}
	public Long getDisclaimerId() {
		return disclaimerId;
	}
	public void setDisclaimerId(Long disclaimerId) {
		this.disclaimerId = disclaimerId;
	}
	public Boolean isCompanyStatus() {
		return companyStatus;
	}
	public void setCompanyStatus(Boolean companyStatus) {
		this.companyStatus = companyStatus;
	}
	public List<UCSVC> getEntitlements() {
		return entitlements;
	}
	public NXPMPReference getCountry() {
		return country;
	}
	public void setCountry(NXPMPReference country) {
		this.country = country;
	}
	public NXPMPReference getRegion() {
		return region;
	}
	public void setRegion(NXPMPReference region) {
		this.region = region;
	}
	public void setEntitlements(List<UCSVC> entitlements) {
		this.entitlements = entitlements;
	}	
	public Boolean isCompanyExists() {
		return companyExists;
	}
	public void setCompanyExists(Boolean companyExists) {
		this.companyExists = companyExists;
	}
	public Boolean isValid() {
		return valid;
	}
	public void setValid(Boolean valid) {
		this.valid = valid;
	}

	public Company(){}	

	public Company(Long id){
		this.id = id;
	}	
	
	public Company(String name, Long sponser , NXPMPReference membershipType , NXPMPReference contractType, Integer contractTerm, Date serviceDate, Integer licenseCount, Integer allowedFederation,NXPMPReference companyType){
		this.name = name;
		this.sponserId = sponser;
		this.internalName = name;		
		this.membershipType = membershipType;
		this.contractType = contractType;
		this.contractTerm = contractTerm;
		this.serviceDate = serviceDate!=null?serviceDate:new Date();
		this.dateCreated = serviceDate;
		this.lastUpdated = serviceDate;
		this.licenseCount = licenseCount;
		this.allowedFederations = allowedFederation;
		this.companyType = companyType;
	}
	
	public Company(String name, Long sponser , NXPMPReference membershipType , NXPMPReference contractType, Integer contractTerm, Integer licenseCount, Integer allowedFederation,NXPMPReference companyType){
		this.name = name;
		this.sponserId = sponser;
		this.internalName = name;		
		this.membershipType = membershipType;
		this.contractType = contractType;
		this.contractTerm = contractTerm;
		this.serviceDate = new Date();
		this.dateCreated = new Date();	
		this.licenseCount = licenseCount;
		this.allowedFederations = allowedFederation;
		this.companyType = companyType;
	}
		
	public String toString(){
		return "Company  : id :"+this.id+" name : "+this.name;
	}
}

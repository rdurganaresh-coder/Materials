 package com.nextplane.repository;

import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.Company;
import com.nextplane.model.UCSVC;
import com.nextplane.model.UCSVCInstance;

public interface UCSVCInstanceRepository extends CrudRepository<UCSVCInstance, Long> {
	

	UCSVCInstance findByCompanyIdAndServiceId(Company company , UCSVC service);
	
}
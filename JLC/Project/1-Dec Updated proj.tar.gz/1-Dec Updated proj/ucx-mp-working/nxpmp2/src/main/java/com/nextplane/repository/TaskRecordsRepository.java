package com.nextplane.repository;

/**
 * Module       : Task management
 * Class        : Task Controller
 * 
 * Created Date : 27/07/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.nextplane.model.Company;
import com.nextplane.model.TaskRecords;
import com.nextplane.model.UCDomain;

public interface TaskRecordsRepository extends JpaRepository<TaskRecords, Long> {

	//Old task selecting query for domain
	@Query(" FROM TaskRecords t WHERE t.id in(SELECT MIN(id) FROM TaskRecords tr"
			+ " where tr.taskStatus = CASE WHEN ?1 IS '' THEN tr.taskStatus ELSE ?1 END"
			+ " AND tr.companyId.id = CASE WHEN ?2 IS NULL THEN tr.companyId.id ELSE ?2 END"
			+ " AND tr.formKey = 'Domain_Provisioning'"
			+ " AND tr.srcDomainId.runSelfTest = CASE WHEN ?3 IS NULL THEN tr.srcDomainId.verification ELSE ?3 END"
			+ " AND tr.srcDomainId.approved = CASE WHEN ?4 IS NULL THEN tr.srcDomainId.approved ELSE ?4 END"
			+ " GROUP BY tr.commonTaskId)")
	Page<TaskRecords> findTasks(String vSearch, String companyId, boolean runSelfTest, boolean approval, Pageable pageable);

	TaskRecords findById(long id); 
	
	@Query(" FROM TaskRecords t WHERE t.id in(SELECT MAX(id) FROM TaskRecords tr"
			+ " where tr.commonTaskId = ?1"
			+ " AND taskStatus = ?2)")
	TaskRecords findByTaskIdByOne(long commonTaskId, String taskStatus);	

	List<TaskRecords> findByCommonTaskId(Long id);

	@Transactional
	void deleteBySrcDomainId(UCDomain domain);

	@Query(" FROM TaskRecords t WHERE t.taskStatus = CASE WHEN ?1 IS '' THEN t.taskStatus ELSE ?1 END"
			+ " AND t.companyId.id = CASE WHEN ?2 IS NULL THEN t.companyId.id ELSE ?2 END"
			+ " AND t.taskId.taskRole = CASE WHEN ?3 IS '' THEN t.taskId.taskRole ELSE ?3 END")
	Page<TaskRecords> findFedTasks(String vSearch, Company companyId, String TaskRole, Pageable pageable);
	
	@Query(" FROM TaskRecords t WHERE t.id in(SELECT MAX(id) FROM TaskRecords tr"
			+ " where tr.commonTaskId = ?1"
			+ " AND taskStatus = ?2"
			+ " AND tr.companyId = ?3"
			+ " GROUP BY tr.commonTaskId)")
	TaskRecords findByOneCompany(long commonTaskId, String taskStatus, Company companyId);	

	@Query(" FROM TaskRecords t WHERE t.id in(SELECT MAX(id) FROM TaskRecords tr"
			+ " where tr.commonTaskId = ?1)")
	TaskRecords findLastTask(long commonTaskId);	
	
	@Query(" FROM TaskRecords t WHERE t.taskStatus = CASE WHEN ?1 IS '' THEN t.taskStatus ELSE ?1 END"
			+ " AND t.taskId.taskRole = CASE WHEN ?2 IS '' THEN t.taskId.taskRole ELSE ?2 END")
	Page<TaskRecords> findFedTasksUCX(String vSearch, String TaskRole, Pageable pageable);
	
}

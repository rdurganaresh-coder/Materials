package com.nextplane.repository;

/**
 * Module       : Fed Check List Role management
 * Class        : FedBaseRuleRepository
 * 
 * Created Date : 20/09/2016
 * Created By   : SVCIT NXPMP3
 */

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nextplane.model.FedBaseRule;

public interface FedBaseRuleRepository extends JpaRepository<FedBaseRule, Long> {
	
	@Query("from FedBaseRule where senderProtocol = ?1 and senderOpenFed = ?2 and senderUcType = ?3  and receiverProtocol = ?4 and receiverOpenFed = ?5  and receiverUcType = ?6")
	FedBaseRule findTop1FedBaserule(String senProtocol,Boolean senOpenFed,long senUCtype,String recProtocol,Boolean recOpenFed,long recUCtype);
	
	@Query("from FedBaseRule where senderProtocol = ?1 and (senderOpenFed is null) and senderUcType = ?2 and receiverProtocol = ?3 and receiverOpenFed = ?4  and receiverUcType = ?5")
	FedBaseRule findSenderFedBaserule(String senProtocol,long senUCtype,String recProtocol,Boolean recOpenFed,long recUCtype);

	@Query("from FedBaseRule where senderProtocol = ?1 and senderOpenFed = ?2 and senderUcType = ?3  and receiverProtocol = ?4 and receiverOpenFed is null  and receiverUcType = ?5")
	FedBaseRule findReceiverFedBaserule(String senProtocol,Boolean senOpenFed,long senUCtype,String recProtocol,long recUCtype);
	
	// For open fed is null 
	@Query("from FedBaseRule where senderProtocol = ?1 and senderOpenFed is null and senderUcType = ?2  and receiverProtocol = ?3 and receiverOpenFed is null  and receiverUcType = ?4")
	FedBaseRule findFedBaserule(String senProtocol, long senUCtype, String recProtocol, long recUCtype);
}

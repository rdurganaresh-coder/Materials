package com.nextplane.repository;

/**
 * Module       : Pending Federation management
 * Class        : PendingFederationRepository
 * 
 * Created Date : 23/09/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nextplane.model.ChangeRequest;
import com.nextplane.model.Company;
import com.nextplane.model.FederationList;
import com.nextplane.model.NXPMPReference;
import com.nextplane.model.PendingFederation;
import com.nextplane.model.UCDomain;

public interface PendingFederationRepository extends JpaRepository<PendingFederation, Long> {


	PendingFederation findById(Long id);	
	Page<PendingFederation> findBySrcCompany(Company company,Pageable page);
	List<PendingFederation> findBySrcCompany(Company company);
	Page<PendingFederation> findByDestCompany(Company company,Pageable page);
	List<PendingFederation> findByDestCompany(Company company);

	@Query("select dateCreated from PendingFederation where id =?1")
	Date getDomainDate(long id);
	
	@Query("from PendingFederation where ((srcDomain = ?1 and destDomain = ?2) or (srcDomain = ?2 and destDomain = ?1)) and changeRequestId in (select id from ChangeRequest where crStatus = ?3 or crStatus = ?4)")
	PendingFederation findBysrcDomainAnddestDomain(UCDomain srcdomain, UCDomain desDomain,NXPMPReference pending , NXPMPReference active);

	@Query("select min(pf.dateCreated), pf.destCompany,count(*) from PendingFederation pf where pf.srcCompany = ?1 and pf.destCompany in (select id from Company where name like ?2) and (pf.decisionStatus not in (select id  from NXPMPReference d where d.lname = ?3 or d.lname = ?4 or d.lname = ?5 or d.lname = ?6 ) or pf.decisionStatus is null)  group by pf.destCompany")
	Page<FederationList>  searchPendingCompanies(Company company,String name, String ucxApprove, String ucxReject, String cancel, String rejected, Pageable page);
	
	@Query("select max(pf.dateCreated) , c,count(*) from PendingFederation pf, Company c where c=pf.srcCompany and c.name like ?1 and (pf.decisionStatus not in (select d.id  from NXPMPReference d where d.lname = ?2 or d.lname = ?3 or d.lname = ?4 or d.lname = ?5 ) or pf.decisionStatus is null) group by pf.srcCompany ")
	Page<FederationList>  searchPendingCompaniesForUCX(String name, String ucxApprove, String ucxReject, String cancel, String rejected, Pageable page);	
	
	PendingFederation findByChangeRequestId(ChangeRequest changeRequestId);

	@Query("from PendingFederation where srcDomain = ?1 and destDomain = ?2 and (decisionStatus in (select id  from NXPMPReference d where d.lname = ?3 or d.lname = ?4) or decisionStatus is null)")
	List<PendingFederation> findDestCompanyAndDecisionStatus(Company srcCompany, Company desCompany, NXPMPReference rej, NXPMPReference can);
	
	//Incoming company for federation
	@Query("select min(pf.dateCreated),  pf.srcCompany,count(*) from PendingFederation pf where (pf.decisionStatus not in (select id  from NXPMPReference d where d.lname = ?1 or d.lname = ?2 or d.lname = ?3 or d.lname = ?4 ) or pf.decisionStatus is null) group by pf.srcCompany ")
	Page<FederationList>  getAllIncomingCompanies(String ucxApprove, String ucxReject, String cancel, String rejected, Pageable page);

	@Query("select min(pf.dateCreated),  pf.srcCompany,count(*) from PendingFederation pf where pf.destCompany = ?1 and (pf.decisionStatus not in (select id  from NXPMPReference d where d.lname = ?2 or d.lname = ?3 or d.lname = ?4 or d.lname = ?5 ) or pf.decisionStatus is null) group by pf.srcCompany ")
	Page<FederationList>  getIncomingCompanies(Company company, String ucxApprove, String ucxReject, String cancel, String rejected, Pageable page);

	@Query("select min(pf.dateCreated),  pf.srcCompany,count(*) from PendingFederation pf where (pf.decisionStatus not in (select id  from NXPMPReference d where d.lname = ?1 or d.lname = ?2 or d.lname = ?3 or d.lname = ?4 ) or pf.decisionStatus is null) group by pf.srcCompany ")
	Page<FederationList>  searchAllIncominCompanies(String ucxApprove, String ucxReject, String cancel, String rejected, Pageable page);

	@Query("select min(dateCreated),  pf.srcCompany,count(*) from PendingFederation pf where pf.destCompany = ?1 and pf.srcCompany in (select id from Company where name like ?2 ) and (pf.decisionStatus not in (select id  from NXPMPReference d where d.lname = ?3 or d.lname = ?4 or d.lname = ?5 or d.lname = ?6 ) or pf.decisionStatus is null) group by pf.srcCompany ")
	Page<FederationList>  searchIncominCompanies(Company company,String name, String ucxApprove, String ucxReject, String cancel, String rejected, Pageable page);
	
	
	//For pending federation 
	
	//UCX admin
	@Query("select count(*) from PendingFederation where (decisionStatus not in (select id  from NXPMPReference d where d.lname = ?1 or d.lname = ?2 or d.lname = ?3 or d.lname = ?4 ) or decisionStatus is null)")
	Long getAllPendingFederationCount(String ucxApprove, String ucxReject, String cancel, String rejected);	

	@Query("select max(pf.dateCreated), c ,count(*) from PendingFederation pf, Company c where c=pf.srcCompany and (pf.decisionStatus not in (select id  from NXPMPReference d where d.lname = ?1 or d.lname = ?2 or d.lname = ?3 or d.lname = ?4 ) or pf.decisionStatus is null) group by pf.srcCompany ")
	Page<FederationList>  getPendingCompaniesForUCX(String ucxApprove, String ucxReject, String cancel, String rejected, Pageable page);

	@Query("from PendingFederation where srcCompany = ?1 and (decisionStatus not in (select id  from NXPMPReference d where d.lname = ?2 or d.lname = ?3 or d.lname = ?4 or d.lname = ?5) or decisionStatus is null)")
	List<PendingFederation> getSrcCompanyOrDestCompanyUCX(Company srcCompany, String ucxApprove, String ucxReject, String cancel, String rejected);

	
	//Uc Admin pending federation
	@Query("select count(*) from PendingFederation where srcCompany = ?1 and (decisionStatus not in (select id  from NXPMPReference d where d.lname = ?2 or d.lname = ?3 or d.lname = ?4 or d.lname = ?5 ) or decisionStatus is null)")
	Long getFederationCount(Company company, String ucxApprove, String ucxReject, String cancel, String rejected);
	
	@Query("from PendingFederation where srcCompany = ?1 and destCompany = ?2 and (decisionStatus not in (select id  from NXPMPReference d where d.lname = ?3 or d.lname = ?4 or d.lname = ?5 or d.lname = ?6 ) or decisionStatus is null)")
	List<PendingFederation> getSrcCompanyAndDestCompany(Company srcCompany,Company desCompany, String ucxApprove, String ucxReject, String cancel, String rejected);

	@Query("select max(pf.dateCreated),pf.destCompany, count(pf.destCompany) from PendingFederation pf  where  pf.srcCompany = ?1 and (pf.decisionStatus not in (select d.id  from NXPMPReference d where d.lname = ?2 or d.lname = ?3 or d.lname = ?4 or d.lname = ?5 ) or pf.decisionStatus is null) group by pf.destCompany ")
	Page<FederationList>  getPendingCompanies(Company company, String ucxApprove, String ucxReject, String cancel, String rejected, Pageable page);
	
	@Query("select count(*) from PendingFederation where destCompany = ?1 and (decisionStatus not in (select id  from NXPMPReference d where d.lname = ?2 or d.lname = ?3 or d.lname = ?4 or d.lname = ?5 ) or decisionStatus is null)")
	Long getIncommingFederationCount(Company company, String ucxApprove, String ucxReject, String cancel, String rejected);
	

	@Query("select count(*) from PendingFederation where (srcCompany = ?1 or destCompany = ?1) and (decisionStatus not in (select id  from NXPMPReference d where d.lname = ?2 or d.lname = ?3 or d.lname = ?4 or d.lname = ?5) or decisionStatus is null)")
	Long getSrcOrDestCompanyCount(Company srcCompany, String ucxApprove, String ucxReject, String cancel, String rejected);

}

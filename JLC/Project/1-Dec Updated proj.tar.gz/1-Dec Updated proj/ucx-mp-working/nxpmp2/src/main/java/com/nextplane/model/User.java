package com.nextplane.model;

import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "sec_user")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	private String firstname;
	private String lastname;
	private String mobilephone;
	private String password;
	private String title;
	private String workphone;	
	private String username;
	private String email;	
	private long version;

	@OneToOne
	@JoinColumn (name="companyId")
	private Company companyId;
	
	private Date lastlogin;
	private Boolean accountexpired;
	private Boolean accountlocked;
	private Boolean enabled;
	private Boolean passwordexpired;
	
	@Transient
	private List<String> roleIds; 
	@Transient
	private String name;
	
	@Transient
	private long userid;

	@Transient
	private List<NXPMPReference> roles; 
	
	@Transient
	private boolean userStatus;
	
	@Transient
	private String verificationToken;	

	private String userToken;
	private Date tokenTime;
	
	private String nxpmpUrl;
	
	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}

	public Date getTokenTime() {
		return tokenTime;
	}

	public void setTokenTime(Date tokenTime) {
		this.tokenTime = tokenTime;
	}

	public String getUserToken() {
		return userToken;
	}

	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}

	public long getId() {
		return id;
	}
	
	public void setId(long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getMobilephone() {
		return mobilephone;
	}

	public void setMobilephone(String mobilephone) {
		this.mobilephone = mobilephone;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWorkphone() {
		return workphone;
	}

	public void setWorkphone(String workphone) {
		this.workphone = workphone;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public Date getLastlogin() {
		return lastlogin;
	}

	public void setLastlogin(Date lastlogin) {
		this.lastlogin = lastlogin;
	}

	public Boolean getAccountexpired() {
		return accountexpired;
	}

	public void setAccountexpired(Boolean accountexpired) {
		this.accountexpired = accountexpired;
	}

	public Boolean getAccountlocked() {
		return accountlocked;
	}

	public void setAccountlocked(Boolean accountlocked) {
		this.accountlocked = accountlocked;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	public Boolean getPasswordexpired() {
		return passwordexpired;
	}

	public void setPasswordexpired(Boolean passwordexpired) {
		this.passwordexpired = passwordexpired;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<NXPMPReference> getRoles() {
		return roles;
	}

	public void setRoles(List<NXPMPReference> roles) {
		this.roles = roles;
	}
	
	public Company getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Company companyId) {
		this.companyId = companyId;
	}

	public boolean isUserStatus() {
		return userStatus;
	}

	public void setUserStatus(boolean userStatus) {
		this.userStatus = userStatus;
	}


	public String getVerificationToken() {
		return verificationToken;
	}

	public void setVerificationToken(String verificationToken) {
		this.verificationToken = verificationToken;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getRoleIds() {
		return roleIds;
	}

	public void setRoleIds(List<String> roleIds) {
		this.roleIds = roleIds;
	}


	public String getNxpmpUrl() {
		return nxpmpUrl;
	}

	public void setNxpmpUrl(String nxpmpUrl) {
		this.nxpmpUrl = nxpmpUrl;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", firstname=" + firstname + ", lastname="
				+ lastname + ", mobilephone=" + mobilephone + ", password="
				+ password + ", title=" + title + ", workphone=" + workphone
				+ ", username=" + username + ", email=" + email + ", version="
				+ version + ", companyId=" + companyId + ", lastlogin="
				+ lastlogin + ", accountexpired=" + accountexpired
				+ ", accountlocked=" + accountlocked + ", enabled=" + enabled
				+ ", passwordexpired=" + passwordexpired + ", roleIds="
				+ roleIds + ", name=" + name + ", userid=" + userid
				+ ", roles=" + roles + ", userStatus=" + userStatus
				+ ", verificationToken=" + verificationToken + ", userToken="
				+ userToken + ", tokenTime=" + tokenTime + ", nxpmpUrl="
				+ nxpmpUrl + "]";
	}

	public User() {}
	
	public User(String firstname, String lastname,
			String email,Company companyid,	Boolean accountexpired, Boolean accountlocked, Boolean enabled,
			Boolean passwordexpired ,List<NXPMPReference> roles ) {

		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.username = email;
  	    this.companyId = companyid;
		this.accountexpired = accountexpired;
		this.accountlocked = accountlocked;
		this.enabled = enabled;
		this.passwordexpired = passwordexpired;
		this.roles = roles;
	}
	

	public User(String firstname, String lastname, Company companyid, List<NXPMPReference> roles ) {
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = email;
  	    this.companyId = companyid;
		this.roles = roles;
	}	
}

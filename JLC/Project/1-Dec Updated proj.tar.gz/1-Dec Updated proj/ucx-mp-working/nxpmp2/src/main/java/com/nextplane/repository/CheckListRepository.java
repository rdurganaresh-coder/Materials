package com.nextplane.repository;

/**
 * Module       : Check List management
 * Class        : CheckListRepository
 * 
 * Created Date : 10/08/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nextplane.model.UCChecklists;

public interface CheckListRepository extends JpaRepository<UCChecklists, Long> {

	@Query(" FROM UCChecklists ucc WHERE ucc.checklistId in( ?1 )")
	List<UCChecklists> findByChecklistId(String checklistId);
	
	@Query(" FROM UCChecklists ")
	Page<UCChecklists> findCheckList(Pageable pageable);

}

package com.nextplane.repository;

public interface UCChecklistsRepository {

}

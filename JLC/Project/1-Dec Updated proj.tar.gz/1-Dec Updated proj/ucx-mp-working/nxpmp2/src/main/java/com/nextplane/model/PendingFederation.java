package com.nextplane.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="pending_federation")
public class PendingFederation {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long id;	

	@OneToOne
	@JoinColumn(name = "srcDomain")
	UCDomain srcDomain;

	@OneToOne
	@JoinColumn(name = "destDomain")
	UCDomain destDomain;

	@OneToOne
	@JoinColumn(name = "src_company")
	Company srcCompany;

	@OneToOne
	@JoinColumn(name = "dest_company")
	Company destCompany;	

	@OneToOne
	@JoinColumn(name = "pfStatus")
	NXPMPReference pfStatus;

	@OneToOne
	@JoinColumn(name = "decisionStatus")
	NXPMPReference decisionStatus;

	@OneToOne
	@JoinColumn(name = "change_request_id")
	ChangeRequest changeRequestId;

	@OneToOne
	@JoinColumn(name = "fedType")
	NXPMPReference fedType;

	@OneToOne
	@JoinColumn(name = "desCheckList")
	private NXPMPReference desCheckList;

	@OneToOne
	@JoinColumn(name = "srcCheckList")
	private NXPMPReference srcCheckList;

	@Transient
	private String userToken;

	@Transient
	private List<Long> companyIds;

	@Transient
	private Long fedId;

	@Transient
	private Long approve;

	@Transient
	private String fedStatus;

	@JsonFormat(pattern="MM/dd/yyyy, hh:mm a")
	private Date dateCreated;

	@JsonFormat(pattern="MM/dd/yyyy, hh:mm a")
	private Date lastUpdated;

	@Transient
	private PageableNxp pageable;

	@Transient
	private String destCompanyName;

	@Transient
	private String companyName;
	
	private Long commonTaskId;

	@Transient
	private List<TaskRecordsHistory> taskRecordsHistory;

	public Long getId() {
		return id;
	}

	public UCDomain getSrcDomain() {
		return srcDomain;
	}

	public UCDomain getDestDomain() {
		return destDomain;
	}

	public Company getSrcCompany() {
		return srcCompany;
	}

	public void setSrcCompany(Company srcCompany) {
		this.srcCompany = srcCompany;
	}

	public Company getDestCompany() {
		return destCompany;
	}

	public void setDestCompany(Company destCompany) {
		this.destCompany = destCompany;
	}

	public NXPMPReference getPfStatus() {
		return pfStatus;
	}

	public NXPMPReference getDecisionStatus() {
		return decisionStatus;
	}

	public ChangeRequest getChangeRequestId() {
		return changeRequestId;
	}

	public NXPMPReference getFedType() {
		return fedType;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setSrcDomain(UCDomain srcDomain) {
		this.srcDomain = srcDomain;
	}

	public void setDestDomain(UCDomain destDomain) {
		this.destDomain = destDomain;
	}

	public void setPfStatus(NXPMPReference pfStatus) {
		this.pfStatus = pfStatus;
	}

	public void setDecisionStatus(NXPMPReference decisionStatus) {
		this.decisionStatus = decisionStatus;
	}

	public void setChangeRequestId(ChangeRequest changeRequest) {
		this.changeRequestId = changeRequest;
	}

	public void setFedType(NXPMPReference fedType) {
		this.fedType = fedType;
	}

	public String getUserToken() {
		return userToken;
	}

	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}

	public List<Long> getCompanyIds() {
		return companyIds;
	}

	public void setCompanyIds(List<Long> companyIds) {
		this.companyIds = companyIds;
	}

	public Long getFedId() {
		return fedId;
	}

	public void setFedId(Long fedId) {
		this.fedId = fedId;
	}

	public Long getApprove() {
		return approve;
	}

	public void setApprove(Long approve) {
		this.approve = approve;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getFedStatus() {
		return fedStatus;
	}

	public void setFedStatus(String fedStatus) {
		this.fedStatus = fedStatus;
	}

	public PageableNxp getPageable() {
		return pageable;
	}

	public void setPageable(PageableNxp pageable) {
		this.pageable = pageable;
	}

	public String getDestCompanyName() {
		return destCompanyName;
	}

	public void setDestCompanyName(String destCompanyName) {
		this.destCompanyName = destCompanyName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public NXPMPReference getDesCheckList() {
		return desCheckList;
	}

	public void setDesCheckList(NXPMPReference desCheckList) {
		this.desCheckList = desCheckList;
	}

	public NXPMPReference getSrcCheckList() {
		return srcCheckList;
	}

	public void setSrcCheckList(NXPMPReference srcCheckList) {
		this.srcCheckList = srcCheckList;
	}

	public List<TaskRecordsHistory> getTaskRecordsHistory() {
		return taskRecordsHistory;
	}

	public void setTaskRecordsHistory(List<TaskRecordsHistory> taskRecordsHistory) {
		this.taskRecordsHistory = taskRecordsHistory;
	}

	public Long getCommonTaskId() {
		return commonTaskId;
	}

	public void setCommonTaskId(Long commonTaskId) {
		this.commonTaskId = commonTaskId;
	}

	public String toString(){
		return " PendingFederation  : src domain "+this.srcDomain +" \t  destination domain : "+this.destDomain+"  \t status :"+this.pfStatus+ " \t fedStatus "+this.fedStatus; 
	}

	public PendingFederation(){}

	public PendingFederation(UCDomain srcDomain, UCDomain destDomain,NXPMPReference pfStatus,NXPMPReference decisionStatus,NXPMPReference fedType, Date dateCreated, Date lastUpdated){
		this.srcDomain = srcDomain;
		this.destDomain = destDomain;
		this.pfStatus = pfStatus;
		this.decisionStatus = decisionStatus;
		this.fedType = fedType;
		this.dateCreated = dateCreated;
		this.lastUpdated = lastUpdated;
	}

	public PendingFederation(UCDomain srcDomain , UCDomain destDomain , String fedStatus){
		this.srcDomain = srcDomain;
		this.destDomain = destDomain;
		this.fedStatus = fedStatus;
	}
}

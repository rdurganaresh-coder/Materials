package com.nextplane.controller;

/**
 * Module       : Task management
 * Class        : Task Controller
 * 
 * Created Date : 27/07/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nextplane.CommonUtils;
import com.nextplane.Constants.TasksResponseMessage;
import com.nextplane.Constants.ResponseStatus;
import com.nextplane.model.ResponseBean;
import com.nextplane.model.TaskType;
import com.nextplane.service.TaskTypeService;

@Controller
@RequestMapping(value = "/taskType")
public class TaskTypeController {

	private static final Logger LOG = LoggerFactory.getLogger(TaskTypeController.class);
	
	@Autowired
	TaskTypeService taskTypeService;
	
	/**
	 * 
	 * @param task
	 * @return
	 */
	@RequestMapping(value = "/create",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean create(@RequestBody TaskType task){
		try {
			taskTypeService.createTask(task);
		} catch (Exception ex) {
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, TasksResponseMessage.ERROR_TASK_CREATE);
		}
		LOG.info(TasksResponseMessage.TASK_CREATED);
		return CommonUtils.getResponseBean(task, TasksResponseMessage.TASK_CREATED);
	}	

	/**
	 * 
	 * @param pageable
	 * @return
	 */
	@RequestMapping(value = "/list",method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public Page<TaskType> list(Pageable pageable) {		
		return taskTypeService.list(pageable);
	}
	/**
	 * 
	 * @param pageable
	 * @return
	 */
	@RequestMapping(value = "/listTaskType",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public List<TaskType> list(@RequestBody String type) {
		return taskTypeService.findByType(type);
	}
}

package com.nextplane.repository;

/**
 * Module       : SRV Record management
 * Class        : SRVRecordsRepository
 * 
 * Created Date : 26/09/2016
 * Created By   : SVCIT NXPMP3
 */

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.nextplane.model.SRVRecords;
import com.nextplane.model.UCDomain;

public interface SRVRecordsRepository extends JpaRepository<SRVRecords, Long> {

	SRVRecords findByDomainId(UCDomain ucDomain);
	
	@Transactional
	long deleteByDomainId(UCDomain domain);
}

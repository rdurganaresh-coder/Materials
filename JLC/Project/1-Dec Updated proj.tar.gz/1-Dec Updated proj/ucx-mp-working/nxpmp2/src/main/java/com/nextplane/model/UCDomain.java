package com.nextplane.model;
 
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Version;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="ucdomain")
public class UCDomain {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Version
	private int version;
	
	@OneToOne
	@JoinColumn(name="companyid")
	private Company companyid;	
	
	@OneToOne
	@JoinColumn(name="uc_type")
	private UCPlatform ucType;
	
	@OneToOne
	@JoinColumn(name="domain_type")
	private NXPMPReference domainType;	
	
	@JsonFormat(pattern="MM/dd/yyyy, hh:mm a")
	private Date dateCreated;	
	
	@JsonFormat(pattern="MM/dd/yyyy, hh:mm a")
	private Date lastUpdated;

	private String domainName;	
	private String fqdn;
	
	private Long changeRequestId;	
	
	private Boolean isPrivate;
	private Boolean isNcoreReady;	
	private Boolean openFed;	
	private Boolean srvRecord;
	private Boolean isPublicDomain;	
	private Boolean isActive;
	
	private boolean enabled;
	private boolean allChecked =false;	
	private boolean runSelfTest = false;	
	private boolean verification = false;	
	private boolean approved =false;
	private boolean verificationPending = false;
	private boolean portOpenStaus = false;
	private boolean deactivate = false;
	
	@Transient
	private PageableNxp pageable;	
	@Transient
	private List<CheckListInstance> lists;
	@Transient
	private List<TaskRecordsHistory> tasklists;
	@Transient
	private List<TaskRecordsHistory> taskVerifylists;
	@Transient
	private List<UCChecklists> srvVerification;
	@Transient
	private List<User> userList;
	@Transient
	private Map<String, String> srvChecking;
	@Transient	
	private String userToken;
	
	@Transient
	private List<Long> checkedId;
	@Transient
	private boolean domainStatus;	
	@Transient
	private boolean domainExists;	
	@Transient
	private Long ucid;
	@Transient
	private Runselftest_instance selftestInstance;
	@Transient
	private boolean  isEdit;
	@Transient
	private Boolean verifyDomain = null;
	
	public Long getUcid() {
		return ucid;
	}
	public void setUcid(Long ucid) {
		this.ucid = ucid;
	}
	public boolean isDomainStatus() {
		return domainStatus;
	}
	public void setDomainStatus(boolean domainStatus) {
		this.domainStatus = domainStatus;
	}
	public Boolean getIsPublicDomain() {
		return isPublicDomain;
	}
	public void setIsPublicDomain(Boolean isPublicDomain) {
		this.isPublicDomain = isPublicDomain;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public Boolean getIsPrivate() {
		return isPrivate;
	}
	public void setIsPrivate(Boolean isPrivate) {
		this.isPrivate = isPrivate;
	}
	public Boolean getIsNcoreReady() {
		return isNcoreReady;
	}
	public void setIsNcoreReady(Boolean isNcoreReady) {
		this.isNcoreReady = isNcoreReady;
	}	
	public Boolean getOpenFed() {
		return openFed;
	}
	public Boolean getSrvRecord() {
		return srvRecord;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public Company getCompanyid() {
		return companyid;
	}
	public void setCompanyid(Company companyid) {
		this.companyid = companyid;
	}
	public String getDomainName() {
		return domainName;
	}
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	public String getFqdn() {
		return fqdn;
	}
	public void setFqdn(String fqdn) {
		this.fqdn = fqdn;
	}
	public Boolean isOpenFed() {
		return openFed;
	}
	public void setOpenFed(Boolean openFed) {
		this.openFed = openFed;
	}
	public Boolean isSrvRecord() {
		return srvRecord;
	}
	public void setSrvRecord(Boolean srvRecord) {
		this.srvRecord = srvRecord;
	}
	public UCPlatform getUcType() {
		return ucType;
	}
	public void setUcType(UCPlatform ucType) {
		this.ucType = ucType;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public Boolean isPublicDomain() {
		return isPublicDomain;
	}
	public void setPublicDomain(Boolean isPublicDomain) {
		this.isPublicDomain = isPublicDomain;
	}
	public Boolean isActive() {
		return isActive;
	}
	public void setActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public Boolean isPrivate() {
		return isPrivate;
	}
	public void setPrivate(Boolean isPrivate) {
		this.isPrivate = isPrivate;
	}
	public NXPMPReference getDomainType() {
		return domainType;
	}
	public void setDomainType(NXPMPReference domainType) {
		this.domainType = domainType;
	}
	public Boolean isNcoreReady() {
		return isNcoreReady;
	}
	public void setNcoreReady(Boolean isNcoreReady) {
		this.isNcoreReady = isNcoreReady;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	public List<Long> getCheckedId() {
		return checkedId;
	}
	public void setCheckedId(List<Long> checkedId) {
		this.checkedId = checkedId;
	}
	public boolean isAllChecked() {
		return allChecked;
	}
	public void setAllChecked(boolean allChecked) {
		this.allChecked = allChecked;
	}
	public PageableNxp getPageable() {
		return pageable;
	}
	public void setPageable(PageableNxp pageable) {
		this.pageable = pageable;
	}
	public List<CheckListInstance> getLists() {
		return lists;
	}
	public void setLists(List<CheckListInstance> lists) {
		this.lists = lists;
	}
	public List<TaskRecordsHistory> getTasklists() {
		return tasklists;
	}
	public void setTasklists(List<TaskRecordsHistory> tasklists) {
		this.tasklists = tasklists;
	}
	public List<TaskRecordsHistory> getTaskVerifylists() {
		return taskVerifylists;
	}
	public void setTaskVerifylists(List<TaskRecordsHistory> taskVerifylists) {
		this.taskVerifylists = taskVerifylists;
	}
	public Long getChangeRequestId() {
		return changeRequestId;
	}
	public void setChangeRequestId(Long changeRequestId) {
		this.changeRequestId = changeRequestId;
	}
	public boolean isRunSelfTest() {
		return runSelfTest;
	}
	public void setRunSelfTest(boolean runSelfTest) {
		this.runSelfTest = runSelfTest;
	}
	public boolean isVerification() {
		return verification;
	}
	public boolean isApproved() {
		return approved;
	}
	public void setVerification(boolean verification) {
		this.verification = verification;
	}
	public void setApproved(boolean approved) {
		this.approved = approved;
	}
	public boolean isDomainExists() {
		return domainExists;
	}
	public void setDomainExists(boolean domainExists) {
		this.domainExists = domainExists;
	}
	public String getUserToken() {
		return userToken;
	}
	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}
	public boolean isVerificationPending() {
		return verificationPending;
	}
	public void setVerificationPending(boolean verificationPending) {
		this.verificationPending = verificationPending;
	}
	public boolean isPortOpenStaus() {
		return portOpenStaus;
	}
	public void setPortOpenStaus(boolean portOpenStaus) {
		this.portOpenStaus = portOpenStaus;
	}	
	public boolean isDeactivate() {
		return deactivate;
	}
	public void setDeactivate(boolean deactivate) {
		this.deactivate = deactivate;
	}
	public Runselftest_instance getSelftestInstance() {
		return selftestInstance;
	}
	public void setSelftestInstance(Runselftest_instance selftestInstance) {
		this.selftestInstance = selftestInstance;
	}
	public boolean isEdit() {
		return isEdit;
	}
	public void setEdit(boolean isEdit) {
		this.isEdit = isEdit;
	}
	public List<UCChecklists> getSrvVerification() {
		return srvVerification;
	}
	public void setSrvVerification(List<UCChecklists> srvVerification) {
		this.srvVerification = srvVerification;
	}
	public Map<String, String> getSrvChecking() {
		return srvChecking;
	}
	public List<User> getUserList() {
		return userList;
	}
	public void setUserList(List<User> userList) {
		this.userList = userList;
	}
	public void setSrvChecking(Map<String, String> srvChecking) {
		this.srvChecking = srvChecking;
	}
	
	public Boolean getVerifyDomain() {
		return verifyDomain;
	}
	public void setVerifyDomain(Boolean verifyDomain) {
		this.verifyDomain = verifyDomain;
	}
	public String toString(){		
		return "UCDomain    - id : "+this.id+" name : "+this.domainName;
	}
	
	public UCDomain(){}
	
	public UCDomain(String domainName,String fqdn , Boolean openFed,Boolean srvRecord ,
			UCPlatform ucType,Date dateCreated,Boolean isActive,Boolean isPrivate, NXPMPReference domainType){
			this.domainName = domainName;
			this.fqdn = fqdn;
			this.openFed = openFed;
			this.srvRecord = srvRecord;
			this.ucType = ucType;
			this.dateCreated = dateCreated;
			this.isActive = isActive;
			this.isPrivate = isPrivate;
			this.domainType = domainType;
	}
}
package com.nextplane.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.nextplane.model.CheckListInstance;

public interface ChecklistInstanceRepository extends JpaRepository<CheckListInstance, Long> {

	List<CheckListInstance> findAllByDomainId(long domain);	
	Long countByDomainIdAndChecked(long domainId, boolean checked);
	
	@Transactional
	void deleteByDomainId(Long domainid);

	List<CheckListInstance> findAllByRefId1(Long refId1);	
	List<CheckListInstance> findAllByRefId1AndDomainId(Long refId1, Long domainId);	
}

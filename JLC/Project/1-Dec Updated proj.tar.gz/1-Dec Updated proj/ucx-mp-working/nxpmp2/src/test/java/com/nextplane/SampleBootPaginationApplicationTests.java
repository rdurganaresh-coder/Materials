package com.nextplane;

import java.util.Date;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.nextplane.model.Company;
import com.nextplane.model.NXPMPReference;
import com.nextplane.repository.CompanyRepository;
import com.nextplane.repository.NXPMPReferenceRepository;




public class SampleBootPaginationApplicationTests {
	@Autowired
	CompanyRepository repo;
	@Autowired
	NXPMPReferenceRepository sspreo;
	 
	@Test
	public void  contextLoads() { 
		Company company;
		System.out.println("test junit");
	}
}

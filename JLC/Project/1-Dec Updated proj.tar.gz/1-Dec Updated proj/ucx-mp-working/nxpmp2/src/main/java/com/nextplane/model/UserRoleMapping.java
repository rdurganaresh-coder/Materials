package com.nextplane.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name="sec_user_sec_role")
public class UserRoleMapping  {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Version 
	private int version;
	

	@ManyToOne
	@JoinColumn(name="secUserId")
	User user;
	
	@ManyToOne
	@JoinColumn(name="secRoleId")
	NXPMPReference role;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}


	
	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}


	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public NXPMPReference getRole() {
		return role;
	}

	public void setRole(NXPMPReference role) {
		this.role = role;
	}

	public UserRoleMapping()
	{
		
	}
	
	public UserRoleMapping(User user , NXPMPReference role){
		this.user = user;
		this.role = role;
	}
	

}

package com.nextplane.repository;

import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.ChangeRequest;

public interface ChangeRequestRepository extends CrudRepository<ChangeRequest, Long>{

	ChangeRequest findById(Long id);
	
	ChangeRequest findTop1ById(Long id);
}

package com.nextplane.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.regex.Pattern;

import javax.mail.internet.MimeMessage;
import javax.ws.rs.core.MediaType;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.nextplane.Constants;
import com.nextplane.Constants.EmailContents;
import com.nextplane.Constants.MailGunConf;
import com.nextplane.Constants.ZendeskRef;
import com.nextplane.model.EmailContent;
import com.nextplane.model.EmailParams;
import com.nextplane.model.NXPMPReference;
import com.nextplane.model.PendingFederation;
import com.nextplane.model.User;
import com.nextplane.repository.ChecklistInstanceRepository;
import com.nextplane.repository.EmailContentRepository;
import com.nextplane.repository.NXPMPReferenceRepository;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.core.util.MultivaluedMapImpl;

@Service
public class NXPMPService {

	@Autowired
	EmailContentRepository emailRepo;

	@Autowired
	ChecklistInstanceRepository instacerepo;

	@Autowired
	NXPMPReferenceRepository nxpmprepo;

	@Autowired
	private JavaMailSender javaMailSender;

	@Value("${req_more_info}")
	private String REQ_MORE_INFO;

	@Value("${domain_validation}")
	private String DOMAIN_VALIDATION;

	public static String body;
	public static String subject;
	
	Logger logger = LogManager.getLogger(NXPMPService.class);

	public void sendNotification(HashMap<String, String> params, String subjectName) {
		EmailContent content = emailRepo.findBySubjectName(subjectName);
		String body = "";
			switch (subjectName) {
			case EmailContents.REQ_MORE_INFO:
				body = content.getContent()
						.replace("$name", params.get("name"))
						.replace("$companyName", params.get("companyName"))
						.replace("$domainName", params.get("domainName"))
						.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
				subject = content.getSubject().replace("$companyName", params.get("companyName"));
				NXPMPService.body = body;
				break;
				
			case EmailContents.DOMAIN_VALIDATION:
				body = content
						.getContent()
						.replace("$name", params.get("name"))
						.replace("$ucdomain", params.get("domainName"))
						.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
				subject = content.getSubject().replace("$ucdomain", params.get("domainName"));
				NXPMPService.body = body;
				break;

			case EmailContents.DOMAIN_CHECKLIST:
				body = content
						.getContent()
						.replace("$name", params.get("name"))
						.replace("$ucdomain", params.get("domainName"))
						.replace("$supportemail",
								Constants.EmailContents.SUPPORTEMAIL);
				subject = content.getSubject().replace("$ucdomain", params.get("domainName"));
				NXPMPService.body = body;
				break;

				
			case EmailContents.DOMAIN_CHECKLIST_COMPLETED:
				body = content
						.getContent()
						.replace("$name", params.get("name"))
						.replace("$ucdomain", params.get("domainName"))
						.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
				subject = content.getSubject().replace("$ucdomain",
						params.get("domainName"));
				NXPMPService.body = body;
				break;

			// case for DOMAIN_VERIFICATION_COMPLETED
			case EmailContents.DOMAIN_VERIFICATION_COMPLETED:
				body = content.getContent()
						.replace("$name", params.get("name"))
						.replace("$ucdomain", params.get("domainName"))
						.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
				subject = content.getSubject().replace("$ucdomain", params.get("domainName"));
				NXPMPService.body = body;
			break;
					
			case EmailContents.DOMAIN_SELFTEST:
				body = content.getContent()
						.replace("$name", params.get("name"))
						.replace("$ucdomain", params.get("domainName"))
						.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
				subject = content.getSubject().replace("$ucdomain",
						params.get("domainName"));
				NXPMPService.body = body;
				break;
				
			case EmailContents.DOMAIN_SELFTEST_PASSED:
				body = content
						.getContent()
						.replace("$name", params.get("name"))
						.replace("$ucdomain", params.get("domainName"))
						.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
				subject = content.getSubject().replace("$ucdomain",
						params.get("domainName"));
				NXPMPService.body = body;
				break;

			case EmailContents.DOMAIN_SELFTEST_FAILED:
				body = content.getContent()
						.replace("$name", params.get("name"))
						.replace("$ucdomain", params.get("domainName"))
						.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
				subject = content.getSubject().replace("$ucdomain",
						params.get("domainName"));
				NXPMPService.body = body;
				break;
				
			case EmailContents.NEWDOMAIN:
				body = content
						.getContent()
						.replace("$name", params.get("name"))
						.replace("$domainName", params.get("domainName"))
						.replace("$uctype", params.get("uctype"))
						.replace("$company", params.get("company"))
						.replace("$openfed", params.get("openfed"))
						.replace("$fqdn", params.get("fqdn"))
						.replace("$srvRecord", params.get("srvRecord"))
						.replace("$isPublic", params.get("isPublic"))
						.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
				subject = content.getSubject().replace("$domainName",
						params.get("domainName"));
				NXPMPService.body = body;
				break;

			case EmailContents.NOTIFY_UCX_DOMAIN:
			  	body =   content.getContent()
					.replace("$name", params.get("name"))
			  		.replace("$ucdomainName", params.get("domainName"))
			  		.replace("$openfed", params.get("openfed"))
			  		.replace("$uctype", params.get("uctype"))
			  		.replace("$fqdn", params.get("fqdn"))
			  		.replace("$srv", params.get("srvRecord"))
			  		.replace("$company", params.get("company"))
			  		.replace("$public", params.get("isPublic"))
			  		.replace("$url", params.get("url"))
					.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
			   	subject = content.getSubject().replace("$ucdomainName",params.get("domainName") );
			   	
			   	// these are used for zendesk body
			   	NXPMPService.body = nxpmprepo.getDName(ZendeskRef.UCX_DOMAIN_BODY)
			   			.replace("$ucdomainName", params.get("domainName"))
			   			.replace("$openfed", params.get("openfed"))
			   			.replace("$uctype", params.get("uctype"))
			   			.replace("$fqdn", params.get("fqdn"))
			   			.replace("$srv", params.get("srvRecord"))
			   			.replace("$company", params.get("company"))
			   			.replace("$public", params.get("isPublic"))
			   			.replace("$url", params.get("url"));
			  	break;
			  	
			case EmailContents.DOMAIN_ACTIVE:
				body = content
						.getContent()
						.replace("$name", params.get("name"))
						.replace("$domainName", params.get("domainName"))
						.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
				subject = content.getSubject().replace("$ucdomainName",
						params.get("domainName"));
				NXPMPService.body = body;
				break;

				// case for NOTIFY_UCX_FEERATION
				case EmailContents.NOTIFY_UC_FEDERATION_CREATED:
					body = content
							.getContent()
							.replace("$name", params.get("name"))
							.replace("$srcDomainName", params.get("srcDomainName"))
							.replace("$desDomainName", params.get("desDomainName"))
							.replace("$url", params.get("url"))
							.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
					NXPMPService.subject = content.getSubject()
							.replace("$srcDomainName",params.get("srcDomainName"))
							.replace("$desDomainName",params.get("desDomainName"));
					NXPMPService.body = body;
					break;
					
					
			// case for NOTIFY_UCX_FEERATION
			case EmailContents.NOTIFY_UCX_FEDERATION:
				body = content
						.getContent()
						.replace("$name", params.get("name"))
						.replace("$srcDomainName", params.get("srcDomainName"))
						.replace("$desDomainName", params.get("desDomainName"))
						.replace("$url", params.get("url"))
						.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
				NXPMPService.subject = content.getSubject()
						.replace("$srcDomainName",params.get("srcDomainName"))
						.replace("$desDomainName",params.get("desDomainName"));

			   	// these are used for zendesk body
			   	NXPMPService.body = nxpmprepo.getDName(ZendeskRef.NOTIFY_UCX_FEDERATION)
			   			.replace("$name", params.get("name"))
						.replace("$srcDomainName", params.get("srcDomainName"))
						.replace("$desDomainName", params.get("desDomainName"))
						.replace("$url", params.get("url"));
				break;

				// case for NOTIFY_UCX_FEERATION
				case EmailContents.FEDRATION_APPROVED:
					body = content
							.getContent()
							.replace("$name", params.get("name"))
							.replace("$srcDomainName", params.get("srcDomainName"))
							.replace("$desDomainName", params.get("desDomainName"))
							.replace("$url", params.get("url"))
							.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
					NXPMPService.subject = content.getSubject()
							.replace("$srcDomainName",params.get("srcDomainName"))
							.replace("$desDomainName",params.get("desDomainName"));
					NXPMPService.body = body;
					break;


					// case for NOTIFY_UCX_FEERATION
					case EmailContents.FEDERATION_CHECKLIST_DESTDOMAAIN:
						body = content
								.getContent()
								.replace("$name", params.get("name"))
								.replace("$srcDomainName", params.get("srcDomainName"))
								.replace("$desDomainName", params.get("desDomainName"))
								.replace("$url", params.get("url"))
								.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
						NXPMPService.subject = content.getSubject()
								.replace("$srcDomainName",params.get("srcDomainName"))
								.replace("$desDomainName",params.get("desDomainName"));
						NXPMPService.body = body;
						break;

						// case for NOTIFY_UCX_FEERATION
						case EmailContents.NOTIFY_UCX_REJECTED:
							body = content
									.getContent()
									.replace("$name", params.get("name"))
									.replace("$srcDomainName", params.get("srcDomainName"))
									.replace("$desDomainName", params.get("desDomainName"))
									.replace("$url", params.get("url"))
									.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
							NXPMPService.subject = content.getSubject()
									.replace("$srcDomainName", params.get("srcDomainName"))
									.replace("$desDomainName", params.get("desDomainName"));
							NXPMPService.body = body;
							break;
				
						// case for NOTIFY_UCX_FEERATION
						case EmailContents.NOTIFY_UC_CANCELLED:
							body = content
									.getContent()
									.replace("$name", params.get("name"))
									.replace("$srcDomainName", params.get("srcDomainName"))
									.replace("$desDomainName", params.get("desDomainName"))
									.replace("$url", params.get("url"))
									.replace("$supportemail", Constants.EmailContents.SUPPORTEMAIL);
							NXPMPService.subject = content.getSubject()
									.replace("$srcDomainName", params.get("srcDomainName"))
									.replace("$desDomainName", params.get("desDomainName"));
							NXPMPService.body = body;
							break;
			default:
				body = "";
			}
			sendMail(body, subject, params.get("email"));
	}

	public void sendMail(String msgBody, String msgSubject, String emailTo) {
		try {
			String MAILGUN_API_KEY = nxpmprepo.findByLname(MailGunConf.MAILGUN_API_KEY).getDname();
			String MAILGUN_HOST = nxpmprepo.findByLname(MailGunConf.MAILGUN_HOST).getDname();

			logger.info("Going to sent mail");
			String emailFrom = "";
			NXPMPReference repo = nxpmprepo
					.findByLname(EmailContents.EMAILFROM);
			if (repo != null) {
				emailFrom = repo.getDname();
			}
			
			// create the email template
			InputStream is = getClass().getResourceAsStream("../../../templates/commonEmail.html");
			String template = IOUtils.toString(is, "UTF-8");
			if (template != null) {
				template = template.replace("${emailBody}", msgBody);
			}
/*
			final MimeMessage mimeMessage = this.javaMailSender
					.createMimeMessage();
			final MimeMessageHelper mailMessage = new MimeMessageHelper(
					mimeMessage, "UTF-8");
			mailMessage.setFrom(emailFrom, "Nextplane");
			mailMessage.setTo(emailTo);
			mailMessage.setSubject(msgSubject);
			mailMessage.setText(template, true);

			javaMailSender.send(mimeMessage);*/
			
			Client client = Client.create();
		      client.addFilter(new HTTPBasicAuthFilter("api", MAILGUN_API_KEY));

		      WebResource webResource = client.resource("https://api.mailgun.net/v2/"
		          + MAILGUN_HOST + "/messages");

		      MultivaluedMapImpl formData = new MultivaluedMapImpl();
		      formData.add("from", emailFrom); // your host email address
		      formData.add("to", emailTo);
		      formData.add("subject", msgSubject);
		      formData.add("html", template);
		      formData.add("sender", emailFrom);

		      ClientResponse clientResponse = webResource.type(
		          MediaType.APPLICATION_FORM_URLENCODED).post(
		          ClientResponse.class, formData);
		      int status = clientResponse.getStatus();
		      if (status >= 400) {
		        System.out.println(clientResponse.getEntity(String.class));
		      }
		} catch (Exception e) {
			logger.error("Exception in sending email" + e.getMessage());
		}
	}

	static Pattern emailPattern = Pattern.compile("^[a-zA-Z0-9.!#$%&'*+\\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$");
    public boolean isValidEmail(String email) {
        return emailPattern.matcher(email).matches();
    }
    
    public void sendMailNotification(EmailParams emailParams) {
		String body = "";
			switch (emailParams.getSubjectName()) {
			case EmailContents.RESET_UCADMIN_PASSWORD:
				body = emailParams.getContent()
						.replace("$url", emailParams.getUrl())
						.replace("$email", emailParams.getEmailTo())
						.replace("$userName", emailParams.getUserName());
				subject = emailParams.getSubject();
				break;			
			default:
				body = "";
			}
			sendMail(body, subject, emailParams.getEmailTo());
	}
}

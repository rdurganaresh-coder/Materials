package com.nextplane.model;

/**
 * Module       : Task management
 * Class        : Task Records
 * 
 * Created Date : 27/07/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "task_records")
public class TaskRecords {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@OneToOne
	@JoinColumn (name="TaskId")
	private TaskType taskId;
	
	@OneToOne
	@JoinColumn (name="assignedTo")
	private User assignedTo;

	private String formKey;
	
	private Date timeAssigned;

	@OneToOne
	@JoinColumn (name="companyId")
	private Company companyId;
	
	@OneToOne
	@JoinColumn(name="srcDomainId")
	private UCDomain srcDomainId;

	@OneToOne
	@JoinColumn(name="destDomainId")
	private UCDomain destDomainId;	
	
	private String taskStatus;
	private Date timeCompleted;
	private Long commonTaskId;
	private int priority;

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public String getFormKey() {
		return formKey;
	}
	public void setFormKey(String formKey) {
		this.formKey = formKey;
	}
	public Date getTimeAssigned() {
		return timeAssigned;
	}
	public void setTimeAssigned(Date timeAssigned) {
		this.timeAssigned = timeAssigned;
	}	
	public UCDomain getSrcDomainId() {
		return srcDomainId;
	}
	public void setSrcDomainId(UCDomain srcDomainId) {
		this.srcDomainId = srcDomainId;
	}
	public UCDomain getDestDomainId() {
		return destDomainId;
	}
	public void setDestDomainId(UCDomain destDomainId) {
		this.destDomainId = destDomainId;
	}
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	public Date getTimeCompleted() {
		return timeCompleted;
	}
	public void setTimeCompleted(Date timeCompleted) {
		this.timeCompleted = timeCompleted;
	}
	public TaskType getTaskId() {
		return taskId;
	}
	public void setTaskId(TaskType taskId) {
		this.taskId = taskId;
	}
	public User getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(User assignedTo) {
		this.assignedTo = assignedTo;
	}
	public Company getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Company companyId) {
		this.companyId = companyId;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public Long getCommonTaskId() {
		return commonTaskId;
	}
	public void setCommonTaskId(Long commonTaskId) {
		this.commonTaskId = commonTaskId;
	}

	public String toString() {
		return "TaskRecords [id=" + id + ", taskId=" + taskId + ", assignedTo="
				+ assignedTo + ", formKey=" + formKey + ", timeAssigned="
				+ timeAssigned + ", companyId=" + companyId + ", srcDomainId="
				+ srcDomainId + ", destDomainId=" + destDomainId
				+ ", taskStatus=" + taskStatus + ", timeCompleted="
				+ timeCompleted + ", commonTaskId=" + commonTaskId
				+ ", priority=" + priority + "]";
	}
	TaskRecords(){
		
	}
	public TaskRecords(User assignedTo, String formKey,
			Date timeAssigned, Company companyId, UCDomain srcDomainId,
			UCDomain destDomainId, Date timeCompleted, Long commonTaskId) {
		super();
		this.assignedTo = assignedTo;
		this.formKey = formKey;
		this.timeAssigned = timeAssigned;
		this.companyId = companyId;
		this.srcDomainId = srcDomainId;
		this.destDomainId = destDomainId;
		this.timeCompleted = timeCompleted;
		this.commonTaskId = commonTaskId;
	}

	public TaskRecords(User assignedTo, String formKey,
			Date timeAssigned, Company companyId, UCDomain srcDomainId,
			UCDomain destDomainId, Date timeCompleted) {
		super();
		this.assignedTo = assignedTo;
		this.formKey = formKey;
		this.timeAssigned = new Date();
		this.companyId = companyId;
		this.srcDomainId = srcDomainId;
		this.destDomainId = destDomainId;
		this.timeCompleted = new Date();
	}
}

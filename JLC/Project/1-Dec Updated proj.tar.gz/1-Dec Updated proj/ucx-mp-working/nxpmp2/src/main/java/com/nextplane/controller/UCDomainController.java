package com.nextplane.controller;

/**
 * Module       : UCDomain
 * Class    	: UCDomainController
 * 
 * Created Date : 01/08/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nextplane.CommonUtils;
import com.nextplane.Constants.CheckListMessage;
import com.nextplane.Constants.DomainMessage;
import com.nextplane.Constants.EmailContents;
import com.nextplane.Constants.Lookups;
import com.nextplane.Constants.Project;
import com.nextplane.Constants.ResponseMessage;
import com.nextplane.Constants.ResponseStatus;
import com.nextplane.Constants.TaskPriority;
import com.nextplane.Constants.TasksResponseMessage;
import com.nextplane.model.CheckListInstance;
import com.nextplane.model.PageableNxp;
import com.nextplane.model.ResponseBean;
import com.nextplane.model.Runselftest_instance;
import com.nextplane.model.TaskRecords;
import com.nextplane.model.UCDomain;
import com.nextplane.model.UCPlatform;
import com.nextplane.model.User;
import com.nextplane.repository.NXPMPReferenceRepository;
import com.nextplane.service.CheckListService;
import com.nextplane.service.NXPMPService;
import com.nextplane.service.TaskRecordsService;
import com.nextplane.service.UCDomainService;
import com.nextplane.service.UserService;

@Controller
@RequestMapping(value = "/ucdomain")
public class UCDomainController {

	@Autowired
	private UCDomainService service;

	@Autowired
	private UserService userService;

	@Autowired
	private TaskRecordsService taskService;
	
	@Autowired
	private CheckListService checkListService;

	@Autowired
	private NXPMPReferenceRepository nXPMPReferenceRepository;

	@Value("${page}")
	private String page;
	@Value("${limit}")
	private String limit;
	@Value("${direction}")
	private String direction;
	@Value("${roles.3}")
	private String supperAdmin;

	Logger logger = LogManager.getLogger(UCDomainController.class);

	@RequestMapping(path = "/create", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public ResponseBean getUCDomains(HttpServletRequest request,
			HttpServletResponse response) {
		List<UCPlatform> uclists = null;
		try {

			uclists = service.getUCDomains();
			if (uclists == null)
				throw new Exception(DomainMessage.ERROR_UCLISTS_RETRIEVED);

		} catch (Exception e) {
			if (e.getMessage().contains(DomainMessage.ERROR_UCLISTS_RETRIEVED)) {
				logger.error(DomainMessage.ERROR_UCLISTS_RETRIEVED);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						DomainMessage.ERROR_UCLISTS_RETRIEVED);

			}

		}
		logger.info(DomainMessage.UCLISTS_RETRIEVED);
		return CommonUtils.getResponseBean(uclists, "");
	}

    @RequestMapping(path = "/domain",method = RequestMethod.POST,produces = "application/json")
   	@ResponseBody
   	public ResponseBean getUCDomain(HttpServletRequest request , HttpServletResponse response , @RequestBody UCPlatform ucType){
   		UCPlatform ucplatform = null;
   		try{
   			ucplatform = service.getUCDomainAndRule(ucType.getUpid());
   			
   			if(ucplatform == null ){
   				throw new Exception(DomainMessage.ERROR_UCLISTS_RETRIEVED);
   			}else if(ucplatform.getUcbaseruleid()!= null && ucplatform.getUcbaseruleid().getId() == 1){
   				return CommonUtils.getErrorResponseBean(ResponseStatus.UCTYPE_FAILURE,ucplatform); 
   			}else if(ucplatform.getUcbaseruleid()!= null && ucplatform.getUcbaseruleid().getId() == 2){
   				return CommonUtils.getErrorResponseBean(ResponseStatus.UCTYPE_FAILURE,ucplatform); 
   			}
   						
   		}catch (Exception e){
   			if(e.getMessage().contains(DomainMessage.ERROR_UCLISTS_RETRIEVED)){
   				logger.error(DomainMessage.ERROR_UCLISTS_RETRIEVED);
   				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, DomainMessage.ERROR_UCLISTS_RETRIEVED);			

   			}
   				
   		}
   		logger.info(DomainMessage.UCLISTS_RETRIEVED);
   		return CommonUtils.getResponseBean(ucplatform, "");
   	}

	@RequestMapping(path = "/save", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean saveDomain(HttpServletRequest request,
			HttpServletResponse response, @RequestBody UCDomain ucdomain) {

		UCDomain domain = new UCDomain();
		String userToken = ucdomain.getUserToken();
		try {

			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
		//		throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			// update the token time ..
			userService.updateAdminTokenTime(userToken);

			User user = userService.getUserFromToken(userToken);
			if (user != null) {
				ucdomain.setCompanyid(user.getCompanyId());
			} else {
				throw new Exception(ResponseMessage.USER_NOTFOUND);
			}
			// save the domain
			domain = service.saveUCDomain(ucdomain);

			if (domain == null) {
				throw new Exception(DomainMessage.ERROR_SAVE_DOMAIN);
			} else if (domain.isDomainExists()) {
				throw new Exception(DomainMessage.DOMAIN_EXISTS);
			} else if (!domain.isDomainStatus()) {
				throw new Exception(DomainMessage.ERROR_SAVE_DOMAIN);
			} else {

				// send notification that domain is created
				Long commonTaskId = null;
				TaskRecords taskObj = new TaskRecords(
					user,
					TasksResponseMessage.DOMAIN_PROVISIONING,
					new Date(),
					domain.getCompanyid(), 
					domain, 
					null, 
					new Date()
				);
				if(!domain.isEdit())
					service.sendNotificationForNewDoman(domain,user,EmailContents.NEWDOMAIN, "");
				if(domain.getChangeRequestId() == null) {
					commonTaskId = taskService.createTask(domain, taskObj, Integer.parseInt(nXPMPReferenceRepository.findOneByLnameAndType(TaskPriority.ONE, TaskPriority.type).getDname()));
				}
				
				if (domain.getChangeRequestId() == null)
					domain = service.updateDomainWithCRId(domain, commonTaskId);

				if (domain.isAllChecked()) {
					TaskRecords taskRecords = taskService.updateTasks(domain.getChangeRequestId());
					commonTaskId = taskService.createTask(domain, taskObj, taskRecords.getPriority()+1);
					taskService.updateTaskHistory(
							taskService.getReferenceValueForHistory("DOMAIN"),
							user,
							domain.getId(),
							domain.getDomainName(),
							"",
							taskService.getReferenceValueForHistory(
									"CHECKLIST_COMPLETED").replace("$date",
									taskService.getDateString(new Date())), 0,
							new Date());
					service.sendNotificationForNewDoman(domain,user,EmailContents.DOMAIN_CHECKLIST_COMPLETED,"");
				}else{
					service.sendNotificationForNewDoman(domain,user,EmailContents.DOMAIN_CHECKLIST,"");
				}
					}
		} catch (Exception e) {

			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_INVALID)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_INVALID);

			} else if (e.getMessage().contains(ResponseMessage.USER_NOTFOUND)) {
				logger.info("Error in saving the domain !!! " + e.getMessage());
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.USER_NOTFOUND);

			} else if (e.getMessage().contains(DomainMessage.ERROR_SAVE_DOMAIN)) {
				logger.info("Error in saving the domain !!! " + e.getMessage());
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						DomainMessage.ERROR_SAVE_DOMAIN);
			} else if (e.getMessage().contains(DomainMessage.DOMAIN_EXISTS)) {
				logger.info("Domain already Exists !!! " + e.getMessage());
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						DomainMessage.DOMAIN_EXISTS);
			}
		}

		return CommonUtils.getResponseBean(ucdomain, DomainMessage.SAVE_DOMAIN);
	}

	@RequestMapping(path = "/view", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean viewDomain(HttpServletRequest request,
			HttpServletResponse response, @RequestBody UCDomain ucdomain) {

		UCDomain domain = new UCDomain();

		String userToken = ucdomain.getUserToken();

		try {

			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			// update the token time ..
			userService.updateAdminTokenTime(userToken);

			domain = service.viewDomain(userToken, ucdomain.getUcid());
				if (domain == null)
				throw new Exception(DomainMessage.ERROR_VIEW_DOMAIN);

		} catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_INVALID)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_INVALID);

			} else if (e.getMessage().contains(DomainMessage.ERROR_VIEW_DOMAIN)) {
				logger.info("Error in finding  the domain !!! "
						+ e.getMessage());
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						DomainMessage.ERROR_VIEW_DOMAIN);
			}
	}
		
		return CommonUtils.getResponseBean(domain, DomainMessage.VIEW_DOMAIN);
	}

	/**
	 * Returns the Country , Region, membershipType , ContractType, Entitlements
	 * , Sponsers
	 * 
	 * @returns : ResponseBean
	 * */
	@RequestMapping(path = "/test2", method = RequestMethod.GET, produces = "application/json")
	// @CrossOrigin(origins = "/**")
	@ResponseBody
	public ResponseBean createCompany(HttpServletRequest request,
			HttpServletResponse response) {

		try {
			System.out.println("In test 2");
		}

		catch (Exception e) {

		}

		return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
				ResponseMessage.ERROR_COMPANY_LOADREF);

	}

	/**
	 * Returns the Country , Region, membershipType , ContractType, Entitlements
	 * , Sponsers
	 * 
	 * @returns : ResponseBean
	 * */
	@RequestMapping(path = "/test3", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean testDate(HttpServletRequest request,
			HttpServletResponse response, @RequestBody UCDomain ucdomain) {

		UCDomain domain = new UCDomain();
		try {
			domain = service.getDomainDate(ucdomain.getUcid());
		}

		catch (Exception e) {

		}

		return CommonUtils.getResponseBean(domain, DomainMessage.VIEW_DOMAIN);
	}

	@RequestMapping(path = "/list", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean listDomains(HttpServletRequest request,
			HttpServletResponse response, @RequestBody UCDomain ucdomain) {
		PageRequest page1 = null;
		PageableNxp pageableNXP = ucdomain.getPageable();
		Page<UCDomain> domainList = null;

		// get the user token .
		String userToken = ucdomain.getUserToken();
		try {

			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}

			// update the token time ..

			userService.updateAdminTokenTime(userToken);

			if (ucdomain.getPageable() != null) {
				if (pageableNXP.getSort() == null)
					pageableNXP.setSort("domainName");
				if (pageableNXP.getSortOrder() == null)
					pageableNXP.setOrder(Direction.ASC);
				else {
					if (pageableNXP.getSortOrder().equals(direction))
						pageableNXP.setOrder(Direction.ASC);
					else
						pageableNXP.setOrder(Direction.DESC);

				}

			} else {
				pageableNXP.setSort("domainName");
				pageableNXP.setOrder(Direction.ASC);
				pageableNXP.setPage(new Integer(page));
				pageableNXP.setSize(new Integer(limit));
			}
			page1 = new PageRequest(pageableNXP.getPage(),
					pageableNXP.getSize(), pageableNXP.getOrder(),
					pageableNXP.getSort());

			// get the user from the userToken
			User user = userService.getUserFromToken(userToken);
			if (user != null) {
				// if sspadmin show all the domains
				if (userService.isSuperAdmin(userToken, supperAdmin)) {
					if (ucdomain.getDomainName() != null)
						domainList = service
								.searchDomainsByDomainNameAndStatus(null, "%"
										+ ucdomain.getDomainName() + "%",
										ucdomain.isActive(), page1);
					else
						domainList = service.showDomainsByStatus(null,
								ucdomain.getIsActive(), page1);
				}
				// if ucadmin show only the domains provisioned for the company
				else {
					if (ucdomain.getDomainName() != null)
						domainList = service
								.searchDomainsByDomainNameAndStatus(
										user.getCompanyId(),
										"%" + ucdomain.getDomainName() + "%",
										ucdomain.isActive(), page1);
					else
						domainList = service.showDomainsByStatus(
								user.getCompanyId(), ucdomain.getIsActive(),
								page1);
				}
			} else {
				throw new Exception(ResponseMessage.USER_NOTFOUND);
			}
		}

		catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_INVALID)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_INVALID);

			} else if (e.getMessage().contains(ResponseMessage.USER_NOTFOUND)) {
				logger.info("Error in saving the domain !!! " + e.getMessage());
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.USER_NOTFOUND);

			} else {
				logger.info("Error in listing  the domain !!! "
						+ e.getMessage());
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						DomainMessage.ERROR_LISTING_DOMAIN);

			}
		}

		return CommonUtils.getResponseBean(domainList,
				DomainMessage.DOMAIN_LIST);
	}

	@RequestMapping(path = "/getChecklistForDomain", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean getChecklistForDomain(HttpServletRequest request,
			HttpServletResponse response, @RequestBody UCDomain ucdomain) {

		List<CheckListInstance> checklists = null;
		// get the user token .
		String userToken = ucdomain.getUserToken();

		try {

			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}

			checklists = service.getChecklistsForDomain(ucdomain.getUcid());

		} catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else {
				logger.error(CheckListMessage.NO_CHECKLIST_INSTANCE_FOUND);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						CheckListMessage.LIST_CHECKLIST_INSTANCE);

			}
		}

		return CommonUtils.getResponseBean(checklists,
				CheckListMessage.LIST_CHECKLIST_INSTANCE);
	}

	@RequestMapping(path = "/runSelftest", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean runSelfTest(@RequestBody Runselftest_instance selftest, HttpServletRequest request,HttpServletResponse response, @RequestHeader(value = "uri") String uri) {
		// get the user token .
    	
    	UCDomain domain = null;
    	String userToken =selftest.getUserToken();
   
		try {
			if (userToken == null || (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			// get user from the token
			User user = userService.getUserFromToken(userToken);
			
		      // update the token time .. 
            userService.updateAdminTokenTime(userToken);
  	
            domain  = service.runSelfTests(selftest.isAddToContactList(),selftest.isConfirmAvailable(),selftest.isSendHello(),selftest.isComfirmResponse(), selftest.getUcdomain());

			// update tasks records
			if (domain.isRunSelfTest()) {
				
				TaskRecords taskRecords = taskService.updateTasks(domain.getChangeRequestId());
				taskRecords.setCompanyId(null);
				taskService.createTask(domain, taskRecords, taskRecords.getPriority()+1);
				
				taskService.updateTaskHistory(
						taskService.getReferenceValueForHistory("DOMAIN"),
						user,
						domain.getId(),
						domain.getDomainName(),
						"",
						taskService.getReferenceValueForHistory(
								"SELFTEST_PASSED").replace("$date",
								taskService.getDateString(new Date())), 0,
						new Date());

				service.sendNotificationForNewDoman(domain, user, EmailContents.DOMAIN_SELFTEST_PASSED, "");
				// Get the email for UCX admin
				String url =  uri + nXPMPReferenceRepository.findByDname(Project.PROJECTNAME).getLname() + "/domain/approve/"+selftest.getUcdomain();
				service.sendNotificationForNewDoman(domain, user, EmailContents.NOTIFY_UCX_DOMAIN, url);
				
				// create zendesk ticket				
				service.createZendeskTicket(NXPMPService.subject, NXPMPService.body);
			} else {
				taskService.updateTaskHistory(
						taskService.getReferenceValueForHistory("DOMAIN"),
						user,
						domain.getId(),
						domain.getDomainName(),
						"",
						taskService.getReferenceValueForHistory(
								"SELFTEST_FAILED").replace("$date",
								taskService.getDateString(new Date())), 0,
						new Date());
				service.sendNotificationForNewDoman(domain, user, EmailContents.DOMAIN_SELFTEST_FAILED, "");
			}
		} catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else {
				logger.error(CheckListMessage.NO_CHECKLIST_INSTANCE_FOUND);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						CheckListMessage.LIST_CHECKLIST_INSTANCE);

			}
		}

		return CommonUtils.getResponseBean(domain,
				CheckListMessage.LIST_CHECKLIST_INSTANCE);

	}

	@RequestMapping(path = "/approval", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean approvalSSPAdmin(@RequestBody UCDomain ucdomain) {
		// get the user token .
		UCDomain domain = null;
		String userToken = ucdomain.getUserToken();
		
		/*try {
			if (userToken == null || (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}*/

			// get user from the token
			User user = userService.getUserFromToken(userToken);
			domain = service.approveDomain(ucdomain.isApproved(), ucdomain.getUcid());


			TaskRecords taskRecords = taskService.updateTasks(domain.getChangeRequestId());
			taskService.createTask(domain, taskRecords, taskRecords.getPriority()+1);
			
			// update tasks records
			if (domain.isActive()) {
				taskService.updateTasks(domain.getChangeRequestId());
				taskService.updateTaskHistory(
						taskService.getReferenceValueForHistory("DOMAIN"),
						user,
						domain.getId(),
						domain.getDomainName(),
						"",
						taskService.getReferenceValueForHistory(
								"DOMAIN_PROVISIONED").replace("$date",
								taskService.getDateString(new Date())), 0,
						new Date());
				service.sendNotificationForNewDoman(domain,user,EmailContents.DOMAIN_ACTIVE,"");
				service.closeZendeskTicket(domain.getDomainName());
			}
/*
		} catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else {
				logger.error(CheckListMessage.NO_CHECKLIST_INSTANCE_FOUND);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						CheckListMessage.LIST_CHECKLIST_INSTANCE);

			}
		}*/

		return CommonUtils.getResponseBean(domain,
				CheckListMessage.LIST_CHECKLIST_INSTANCE);

	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param ucdomain
	 * @return
	 */
	@RequestMapping(path = "/delete", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean deleteDomain(HttpServletRequest request,
			HttpServletResponse response, @RequestBody UCDomain ucdomain) {
		UCDomain domain = null;
		// get the user token .
		String userToken = ucdomain.getUserToken();
		System.out.println("jjjjj" + userToken);
		try {
			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			// update the token time ..
			userService.updateAdminTokenTime(userToken);

			domain = service.deleteDomain(ucdomain.getUcid());
			if (domain == null)
				throw new Exception(DomainMessage.ERROR_DELETING_DOMAIN);
		} catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);
			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else {
				logger.error(DomainMessage.ERROR_DELETING_DOMAIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						DomainMessage.ERROR_DELETING_DOMAIN);
			}
		}
		return CommonUtils
				.getResponseBean(domain, DomainMessage.DOMIAN_DELETED);
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param ucdomain
	 * @return
	 */
	@RequestMapping(path = "/domaincount", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean getDomainCount(HttpServletRequest request, HttpServletResponse response, @RequestBody UCDomain ucdomain) {

		String userToken = ucdomain.getUserToken();
		Long domainCount = 0L;
		domainCount = service.getDomainCount(userService.getUserFromToken(userToken));
		return CommonUtils.getResponseBean(domainCount,	DomainMessage.DOMIAN_DELETED);
	}
	
	/**
	 * 
	 * @param ucdomain
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(path = "/verifyDomain", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean verifyDomain(@RequestBody UCDomain ucdomain) throws Exception {
		String userToken = ucdomain.getUserToken();
		try {
			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}

			ucdomain = checkListService.verifyDomain(ucdomain, userToken, ucdomain.isVerificationPending(), ucdomain.getUcid());

		} catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else {
				logger.error(CheckListMessage.NO_CHECKLIST_INSTANCE_FOUND);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						CheckListMessage.LIST_CHECKLIST_INSTANCE);

			}
		}
		return CommonUtils.getResponseBean(ucdomain, CheckListMessage.LIST_CHECKLIST_INSTANCE);
	}
	
	/**
	 * 
	 * @param ucdomain
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(path = "/sipPortOpenVerification", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean sipPortVerification(@RequestBody UCDomain ucdomain) throws Exception {
		String sipPortStatus = "null";
		String userToken = ucdomain.getUserToken();
		try {
			if (userToken == null || (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			sipPortStatus = checkListService.sipPortVerification(ucdomain, userToken, Lookups.SIP_PORT);
		} catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else {
				logger.error(CheckListMessage.NO_CHECKLIST_INSTANCE_FOUND);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						CheckListMessage.LIST_CHECKLIST_INSTANCE);
			}
		}
		if(sipPortStatus == Lookups.PASS)
			return CommonUtils.getResponseBean(sipPortStatus, ""+ResponseStatus.SUCCESS);
		else
			return CommonUtils.getResponseBean(sipPortStatus, ""+ResponseStatus.FAILURE);
	}
	

	/**
	 * 
	 * @param ucdomain
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(path = "/xmppPortOpenVerification", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean xmppPortVerification(@RequestBody UCDomain ucdomain) throws Exception {
		// get the user token .
		String sipPortStatus = null;
		String userToken = ucdomain.getUserToken();
		try {
			if (userToken == null || (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			sipPortStatus = checkListService.xmppPortVerification(ucdomain, userToken, Lookups.XMPP_PORT);
		} catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ERROR_NOT_ADMIN);
			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else {
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ADMIN_TOKEN_INVALID);
			}
		}
		if(sipPortStatus == Lookups.PASS)
			return CommonUtils.getResponseBean(sipPortStatus, ""+ResponseStatus.SUCCESS);
		else
			return CommonUtils.getResponseBean(sipPortStatus, ""+ResponseStatus.FAILURE);
	}
	

	/**
	 * 
	 * @param ucdomain
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(path = "/xmppSrvVerification", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean srvXmppVerification(@RequestBody UCDomain ucdomain) throws Exception {
		// get the user token .
		String sipPortStatus;
		String userToken = ucdomain.getUserToken();
		try {
			if (userToken == null || (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}

			sipPortStatus = checkListService.srvVerification(ucdomain, userToken, Lookups.XMPP);
	
		} catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ERROR_NOT_ADMIN);
			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else {
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ADMIN_TOKEN_INVALID);
			}
		}
		return CommonUtils.getResponseBean(sipPortStatus, ""+ResponseStatus.SUCCESS);
		
		
		
		
	}
	
	/**
	 * 
	 * @param ucdomain
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(path = "/sipSrvVerification", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean srvSipVerification(@RequestBody UCDomain ucdomain) throws Exception {
		// get the user token .
		String sipPortStatus;
		String userToken = ucdomain.getUserToken();
		try {
			if (userToken == null || (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			sipPortStatus = checkListService.srvVerification(ucdomain, userToken, Lookups.SIP);
		} catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ERROR_NOT_ADMIN);
			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else {
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ADMIN_TOKEN_INVALID);
			}
		}
		return CommonUtils.getResponseBean(sipPortStatus, ""+ResponseStatus.SUCCESS);
	}

	/**
	 * 
	 * @param ucdomain
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(path = "/srvXmppTargetVerification", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean srvXmppTargetVerification(@RequestBody UCDomain ucdomain) throws Exception {
		// get the user token .
		Map<String, String> sipTargetStatus;
		String userToken = ucdomain.getUserToken();
		try {
			if (userToken == null || (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			sipTargetStatus = checkListService.srvXmppTargetVerification(ucdomain, userToken, Lookups.XMPP);
		} catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ERROR_NOT_ADMIN);
			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else {
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ADMIN_TOKEN_INVALID);
			}
		}
		return CommonUtils.getResponseBean(sipTargetStatus, ""+ResponseStatus.SUCCESS);
	}
	

	/**
	 * 
	 * @param ucdomain
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(path = "/srvNxpTargetVerification", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean srvNxpTargetVerification(@RequestBody UCDomain ucdomain) throws Exception {
		// get the user token .
		Map<String, String> sipTargetStatus;
		String userToken = ucdomain.getUserToken();
		try {
			if (userToken == null || (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			sipTargetStatus = checkListService.srvNxpTargetVerification(ucdomain, userToken, Lookups.XMPP);
		} catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ERROR_NOT_ADMIN);
			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else {
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ADMIN_TOKEN_INVALID);
			}
		}
		return CommonUtils.getResponseBean(sipTargetStatus, ""+ResponseStatus.SUCCESS);
	}
	

	/**
	 * 
	 * @param ucdomain
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(path = "/srvXmppPortVerification", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean srvXmppPortVerification(@RequestBody UCDomain ucdomain) throws Exception {
		// get the user token .
		String sipPortStatus;
		String userToken = ucdomain.getUserToken();
		try {
			if (userToken == null || (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			sipPortStatus = checkListService.srvXmppPortVerification(ucdomain, userToken, Lookups.XMPP);
		} catch (Exception e) {
			if (e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ERROR_NOT_ADMIN);
			} else if (e.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else {
				logger.error(CheckListMessage.NO_CHECKLIST_INSTANCE_FOUND);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, CheckListMessage.LIST_CHECKLIST_INSTANCE);
			}
		}
		return CommonUtils.getResponseBean(sipPortStatus, ""+ResponseStatus.SUCCESS);
	}	
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param ucdomain
	 * @return
	 */
	@RequestMapping(path = "/domainCountBadge", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean getDomainCountBadge(HttpServletRequest request, HttpServletResponse response, @RequestBody UCDomain ucdomain) {
		  HashMap<String, Long> domainCount = new HashMap<String, Long>();
		  domainCount.put("activeDomainCount", service.getDomainCount(userService.getUserFromToken(ucdomain.getUserToken())));
		  domainCount.put("pendingDomainCount", service.getDomainCountBadge(userService.getUserFromToken(ucdomain.getUserToken())));
		return CommonUtils.getResponseBean(domainCount,	""+ResponseStatus.SUCCESS);
	}


	/**
	 * 
	 * @param request
	 * @param respons
	 * @param pageableNxp
	 * @return
	 */
    @RequestMapping(path = "/getDirectory", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public ResponseBean getAllDomainsAndCompany(HttpServletRequest request , HttpServletResponse respons, @RequestBody PageableNxp pageableNxp) {
		HashMap<String,List<UCDomain>> companies = null;
		companies = service.getAllDomainsAndCompany(pageableNxp);
		return CommonUtils.getResponseBean(companies, ""+ResponseStatus.SUCCESS);
    }
}
package com.nextplane.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.NXPMPReference;

import java.lang.String;
import java.util.List;

@Transactional
public interface NXPMPReferenceRepository extends CrudRepository<NXPMPReference, Long> {
		
		List<NXPMPReference> findByType(String type);
		
		@Query("select (d.dname) from NXPMPReference d where d.type = ?1")
		List<String> findReferenceName(String type);
		
		NXPMPReference findByLname(String lname);
		
		NXPMPReference findById(long id);
		
		@Query("select id  from NXPMPReference d where d.lname = ?1 ")
		long  getUCServiceType(String lname);
		
		NXPMPReference findOneByType(String type);
		
		NXPMPReference  findByDname(String dname);

		@Query("select dname from NXPMPReference where lname =?1")
		String getDName(String lname);

		NXPMPReference findOneByLnameAndType(String lname, String type);
}

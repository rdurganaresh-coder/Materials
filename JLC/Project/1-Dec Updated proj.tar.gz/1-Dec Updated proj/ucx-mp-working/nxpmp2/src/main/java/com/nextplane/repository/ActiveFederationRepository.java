package com.nextplane.repository;

/**
 * Module       : Active Federation management
 * Class        : ActiveFederationRepository
 * 
 * Created Date : 24/09/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nextplane.model.ActiveFederation;
import com.nextplane.model.Company;
import com.nextplane.model.FederationList;

public interface ActiveFederationRepository extends JpaRepository<ActiveFederation, Long> {

	@Query("select count(*) from ActiveFederation where srcCompany = ?1 or desCompany =?1")
	Long findActiveFederationCount(Company company);

	@Query("select count(*) from ActiveFederation where desCompany =?1")
	Long findIncommingRequest(Company company);

	@Query("select min(a.dateCreated) ,c, count(a.id) from Company c , ActiveFederation a where (c = a.srcCompany and a.desCompany = ?1) or ( c = a.desCompany and a.srcCompany = ?1) group by c.id")
	Page<FederationList> getActiveFederationsForcompany(Company company,Pageable page);

	@Query("select min(a.dateCreated) ,c, count(a.id) from Company c , ActiveFederation a where ((c = a.srcCompany and a.desCompany = ?1) or ( c = a.desCompany and a.srcCompany = ?1) ) and c.name like ?2 group by c.id")
	Page<FederationList> searchActiveFederationsForcompany(Company company ,String name,Pageable page);
	
	List<ActiveFederation> findBySrcCompanyOrDesCompany(Company company,Company company1);
	
	@Query("select af from ActiveFederation af where (srcCompany = ?1 and desCompany = ?2 )or (srcCompany = ?2 and desCompany = ?1)")
	List<ActiveFederation> findActiveFederationWithCompany(Company	thisCompany , Company otherCompany);

	@Query("select min(a.dateCreated) ,c, count(a.id) from Company c , ActiveFederation a where (c = a.srcCompany) or ( c = a.desCompany ) group by c.id")
	Page<FederationList> getActiveFederationsForcompanyForUCX(Pageable page);

	@Query("select min(a.dateCreated) ,c, count(a.id) from Company c , ActiveFederation a where ((c = a.srcCompany ) or ( c = a.desCompany) ) and c.name like ?1 group by c.id")
	Page<FederationList> searchActiveFederationsForcompanyForUCX(String name,Pageable page);

	@Query("select count(*) from ActiveFederation")
	Long findAllActiveFederationCount();
	
	@Query("select min(a.dateCreated) ,c, count(a.id) from Company c , ActiveFederation a group by c.id")
	Page<FederationList> getAllActiveFederationsForcompany(Pageable page);
	

	@Query("select af from ActiveFederation af where srcCompany = ?1 or desCompany = ?1")
	List<ActiveFederation> findAllActiveFederationWithCompanyUCX(Company	thisCompany);
}

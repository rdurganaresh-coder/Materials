package com.nextplane.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.Company;
import com.nextplane.model.NXPMPReference;
import com.nextplane.model.UserRoleMapping;
import com.nextplane.model.User;

public interface UserRoleMappingRepository extends CrudRepository<UserRoleMapping, Long>{
	
	UserRoleMapping findByUserAndRole(User user , NXPMPReference role);
	List<UserRoleMapping> findByUser(User user);
	String deleteAllByUser(User user);
	String deleteAllByUser(List<User> user);

	@Query("select role from UserRoleMapping where sec_user_id =?1 ")
	List<NXPMPReference> findRoleById(User id);
	
	@Query("select user from UserRoleMapping where sec_role_id =?1 ")
	List<User> findByRole(NXPMPReference role);
	
	@Query("SELECT user FROM UserRoleMapping AS urm WHERE urm.role =?1 AND urm.user.companyId = ?2")
	List<User> findUserByRoleAndCompany(NXPMPReference role, Company company);
}
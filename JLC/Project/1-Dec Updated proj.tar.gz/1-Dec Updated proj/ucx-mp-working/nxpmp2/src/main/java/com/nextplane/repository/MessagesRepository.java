package com.nextplane.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.Messages;

public interface MessagesRepository extends CrudRepository<Messages, Long> {

	@Query("select message from Messages where id =?1")
	String getmessage(Long msgid);
	
	@Query("select message from Messages where msgid =?1")
	String getmessage(String msgid);

	
}

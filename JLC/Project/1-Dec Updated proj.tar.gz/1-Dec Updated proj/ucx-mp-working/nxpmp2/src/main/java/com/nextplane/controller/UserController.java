package com.nextplane.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nextplane.CommonUtils;
import com.nextplane.Constants.ResponseMessage;
import com.nextplane.Constants.ResponseStatus;
import com.nextplane.model.ResponseBean;
import com.nextplane.model.User;
import com.nextplane.model.VerificationToken;
import com.nextplane.repository.CompanyRepository;
import com.nextplane.service.UserService;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value = "/user")
public class UserController {

	@Autowired
	private UserService _userService;

	@Autowired
	private CompanyRepository comprepo;

	@Value("${roles.3}")
	private String ROLE_SUPER_ADMIN;
	@Value("${page}")
	private String PAGE;
	@Value("${limit}")
	private String LIMIT;
	@Value("${direction}")
	private String DIRECTION;
	private static final Logger log = LoggerFactory
			.getLogger(UserController.class);

	/**
	 * 
	 * @param user
	 * @return message
	 * 
	 *         Retrieves the company and roles to create the user.
	 */
	@RequestMapping(value = "/create", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean create(HttpServletRequest request,
			@RequestBody User user, HttpServletResponse response) {
		HashMap<?, ?> userref = null;
		try {
			// get the user token to validate the user
			String userToken = user.getUserToken();

			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!_userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)) {
				throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
			} else if (!_userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			// get the user reference information to create the user
			userref = _userService.getReferencesForUsers();

		} catch (Exception exception) {
			if (exception.getMessage()
					.contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				log.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (exception.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				log.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else if (exception.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_INVALID)) {
				log.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_INVALID);

			} else {
				log.error(ResponseMessage.ERROR_USER_REF);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_USER_REF);
			}
		}

		log.info(ResponseMessage.GET_USER_REF);
		return CommonUtils.getResponseBean(userref,
				ResponseMessage.GET_USER_REF);
	}

	/**
	 * @param user
	 * @return message
	 * 
	 *         Saves the user details and the user and role mapping to the
	 *         database.Also saves a user token to maintain security
	 */
	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean save(HttpServletRequest request,
			@RequestBody User user, HttpServletResponse response) {

		try {
			// get the user token to valudate the user
			String userToken = user.getUserToken();
			System.out.println("User fofrom input .... " + user);
			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!_userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)) {
				throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
			} else if (!_userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			if (_userService.findUser(user.getEmail()) != null) {
				throw new Exception(ResponseMessage.ERROR_USER_EXISTS);
			} else {
				user.setUserToken(null);
				// save the user
				user = _userService.saveUser(user);

				if (!user.isUserStatus()) {
					// error in user creatuin throw exception
					throw new Exception(ResponseMessage.ERROR_USER_CREATE);
				} else {
					if (!_userService.sendEmail(user.getNxpmpUrl(), user)) {
						// error in sending email
						throw new Exception(ResponseMessage.ERROR_EMAIL_SEND);
					}
					// user saved and sent email
				}

			}

		} catch (Exception ex) {

			if (ex.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				log.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				log.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_INVALID)) {
				log.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_INVALID);

			} else if (ex.getMessage()
					.equals(ResponseMessage.ERROR_USER_EXISTS)) {
				log.error(ResponseMessage.ERROR_USER_EXISTS);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_USER_EXISTS);

			} else if (ex.getMessage().equals(ResponseMessage.ERROR_EMAIL_SEND)) {
				log.error(ResponseMessage.ERROR_EMAIL_SEND);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_EMAIL_SEND);
			} else {
				log.error(ResponseMessage.ERROR_USER_CREATE);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_USER_CREATE);
			}
		}
		log.info(ResponseMessage.USER_CREATED);
		return CommonUtils.getResponseBean(user, ResponseMessage.USER_CREATED);
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean login(HttpServletRequest request,
			@RequestBody User user, HttpServletResponse response) {

		try {

			// do login for the input
			user = _userService.doLogin(user);

			if (!user.isUserStatus()) {
				// error in logging in the user
				throw new Exception(ResponseMessage.ERROR_LOGIN_INVALID_USER);
			}

			// user = _userService.saveUser(user);
		} catch (Exception ex) {
			if (ex.getMessage().contains(
					ResponseMessage.ERROR_LOGIN_INVALID_USER)) {
				log.error(ResponseMessage.ERROR_LOGIN_INVALID_USER);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_LOGIN_INVALID_USER);

			}
			log.error(ResponseMessage.ERROR_LOGIN_INVALID_USER);
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
					ResponseMessage.ERROR_LOGIN_INVALID_USER);
		}
		log.info(ResponseMessage.USER_FOUND);
		return CommonUtils.getResponseBean(user, ResponseMessage.USER_FOUND);
	}

	/**
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/edit", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean update(@RequestBody User user,
			HttpServletRequest request, HttpServletResponse response) {
		try {
			// get ethe user token to validate the user
			String userToken = user.getUserToken();

			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!_userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)) {
				throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
			} else if (!_userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			} else if (_userService.findUser(user.getUserid()) == null) {
				throw new Exception(ResponseMessage.USER_NOTFOUND);
			}
			user.setUserToken(null);
			// update the user
			user = _userService.updateUser(user);
			if (!user.isUserStatus()) {
				throw new Exception(ResponseMessage.ERROR_USER_UPDATE);
			}

		} catch (Exception ex) {
			if (ex.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				log.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				log.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_INVALID)) {
				log.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_INVALID);

			} else if (ex.getMessage().contains(ResponseMessage.USER_NOTFOUND)) {
				log.error(ResponseMessage.USER_NOTFOUND);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.USER_NOTFOUND);

			} else
				System.out.println("Exception ...... " + ex.getMessage());
			log.error(ResponseMessage.ERROR_USER_UPDATE);
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
					ResponseMessage.ERROR_USER_UPDATE);
		}
		log.info(ResponseMessage.USER_UPDATED);
		return CommonUtils.getResponseBean(user, ResponseMessage.USER_UPDATED);
	}

	/**
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/list", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean view(HttpServletRequest request,
			HttpServletResponse response) {
		PageRequest page1 = null;
		Page<User> users = null;

		JSONObject jsonObject = null;
		try {
			// get the json input from the user
			jsonObject = _userService.getJsonInputFromRequest(request);
			// get the usertoken to valudate the user
			String userToken = jsonObject.has("userToken") ? jsonObject
					.getString("userToken") : "";

			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!_userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)) {
				throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
			} else if (!_userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}

			// get the pagination parameters
			int pageNumber = jsonObject.has("page") ? Integer
					.parseInt(jsonObject.getString("page")) : Integer
					.valueOf(PAGE);
			int limit = jsonObject.has("limit") ? Integer.parseInt(jsonObject
					.getString("limit")) : Integer.valueOf(LIMIT);
			String field = jsonObject.has("sort") ? jsonObject
					.getString("sort") : "";
			String direction = jsonObject.has("dir") ? jsonObject
					.getString("dir") : DIRECTION;

			if (jsonObject.has("rel")) {
				if (jsonObject.getString("rel").equals("next"))
					pageNumber = pageNumber + 1;
				else if (jsonObject.getString("rel").equals("previous"))
					pageNumber = pageNumber - 1;

			}
			if (field.isEmpty()) {
				page1 = new PageRequest(pageNumber, limit);
			} else if (!field.isEmpty() && direction.equals("desc")) {
				page1 = new PageRequest(pageNumber, limit, Direction.DESC,
						field);
			} else {
				page1 = new PageRequest(pageNumber, limit, Direction.ASC, field);
			}
			System.out.println("field" + field);
			System.out.println("Page .... " + page1);

			// get the list of users
			users = _userService.view(page1);
		} catch (Exception ex) {
			if (ex.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				log.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				log.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_INVALID)) {
				log.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_INVALID);

			} else {
				log.error(ResponseMessage.ERROR_LIST_USER);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_LIST_USER);

			}

		}
		log.info(ResponseMessage.LIST_USER);
		return CommonUtils.getResponseBean(users, ResponseMessage.LIST_USER);

	}

	/**
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean delete(@RequestBody User user,
			HttpServletRequest request, HttpServletResponse response) {
		String resp = "";
		log.debug("the user id ..  " + user.getId());
		try {
			// get the usertoken to validate the user
			String userToken = user.getUserToken();

			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!_userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)) {
				throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
			} else if (!_userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);

			}

			// find the user and throw exception if not present
			user = _userService.findUser(user.getId());
			if (user == null) {
				throw new Exception(ResponseMessage.ERROR_USER_NOT_FOUND);

			} else {
				// delete the user
				resp = _userService.deleteUser(user.getId());

			}

		} catch (Exception ex) {
			if (ex.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				log.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				log.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_INVALID)) {
				log.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_INVALID);

			} else if (ex.getMessage().contains(
					ResponseMessage.ERROR_USER_NOT_FOUND)) {
				log.error(ResponseMessage.ERROR_USER_NOT_FOUND);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_USER_NOT_FOUND);
			} else {
				System.out.println(ex.getMessage());
				log.error(ResponseMessage.ERROR_USER_NOT_DELETED);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_USER_NOT_DELETED);
			}
		}
		log.info(ResponseMessage.USER_DELETED);
		return CommonUtils.getResponseBean(user, ResponseMessage.USER_DELETED);
	}

	/**
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/view", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean findUser(@RequestBody User obj,
			HttpServletRequest request, HttpServletResponse response) {
		User user = null;

		try {
			// get the user token to validate the user
			String userToken = obj.getUserToken();

			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!_userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)) {
				throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
			} else if (!_userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			// view the user
			user = _userService.findUser(obj.getUserid());
			if (user == null)
				throw new Exception("User not found");
		} catch (Exception ex) {
			if (ex.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				log.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				log.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_INVALID)) {
				log.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_INVALID);

			} else {
				log.error(ResponseMessage.ERROR_USER_NOT_FOUND);
				System.out.println(ex.getMessage());
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_USER_NOT_FOUND);
			}
		}

		log.info(ResponseMessage.USER_FOUND);
		return CommonUtils.getResponseBean(user, ResponseMessage.USER_FOUND);
	}

	/**
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/search", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean searchUser(HttpServletRequest request,
			HttpServletResponse response) {
		PageRequest page1 = null;
		Page<User> userList = null;

		JSONObject jsonObject = null;
		try {
			// get the json input from the user
			jsonObject = _userService.getJsonInputFromRequest(request);
			// get the usertoken to valudate the user
			String userToken = jsonObject.has("userToken") ? jsonObject
					.getString("userToken") : "";
			String name = jsonObject.has("name") ? jsonObject.getString("name")
					: "";
			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!_userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)) {
				throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
			} else if (!_userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}

			// get the pagination parameters
			int pageNumber = jsonObject.has("page") ? Integer
					.parseInt(jsonObject.getString("page")) : Integer
					.valueOf(PAGE);
			int limit = jsonObject.has("limit") ? Integer.parseInt(jsonObject
					.getString("limit")) : Integer.valueOf(LIMIT);
			String field = jsonObject.has("sort") ? jsonObject
					.getString("sort") : "";
			String direction = jsonObject.has("dir") ? jsonObject
					.getString("dir") : DIRECTION;

			if (jsonObject.has("rel")) {
				if (jsonObject.getString("rel").equals("next"))
					pageNumber = pageNumber + 1;
				else if (jsonObject.getString("rel").equals("previous"))
					pageNumber = pageNumber - 1;

			}
			if (field.isEmpty()) {
				page1 = new PageRequest(pageNumber, limit);
			} else if (!field.isEmpty() && direction.equals("desc")) {
				page1 = new PageRequest(pageNumber, limit, Direction.DESC,
						field);
			} else {
				page1 = new PageRequest(pageNumber, limit, Direction.ASC, field);
			}

			// get the users with the name
			userList = _userService.findUserByName(name, page1);
		} catch (Exception ex) {
			if (ex.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				log.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				log.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_INVALID)) {
				log.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_INVALID);

			} else {
				log.error(ResponseMessage.ERROR_USER_NOT_FOUND);
				System.out.println(ex.getMessage());
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_USER_NOT_FOUND);
			}
		}
		if (userList != null && !userList.hasContent()) {
			return CommonUtils.getResponseBean(userList,
					ResponseMessage.ERROR_USER_NOT_FOUND);
		}

		log.info(ResponseMessage.USER_FOUND);
		return CommonUtils
				.getResponseBean(userList, ResponseMessage.USER_FOUND);
	}

	/*
	 * find users by company
	 * 
	 * @param user - company
	 */
	@RequestMapping(value = "/findby", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean searchByCompany(@RequestBody User obj,
			HttpServletRequest request, HttpServletResponse response) {
		List<User> userList = null;

		try {// get teh suer token to validate the user
			String userToken = obj.getUserToken();

			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!_userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)) {
				throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
			} else if (!_userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}
			// filter the users w.r.to the company
			userList = _userService.filterByCompany(obj.getCompanyId());
		} catch (Exception ex) {
			if (ex.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				log.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				log.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_INVALID)) {
				log.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_INVALID);

			} else {
				log.error(ResponseMessage.ERROR_USER_NOT_FOUND);
				System.out.println(ex.getMessage());
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_USER_NOT_FOUND);
			}
		}

		log.info(ResponseMessage.USER_FOUND);
		return CommonUtils
				.getResponseBean(userList, ResponseMessage.USER_FOUND);
	}

	/**
	 * 
	 * @param user
	 * @return message
	 */
	@RequestMapping(value = "/checkPasswordtoken", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean checkPasswordtoken(HttpServletRequest request,
			@RequestBody VerificationToken verToken,
			HttpServletResponse response) {

		try {
			// check if the verification token is valid
			verToken = _userService.checkVerificationToken(verToken);
			if (verToken.isTimeout()) {
				// exeption if timeout
				throw new Exception(ResponseMessage.ERROR_EMAIL_TOKEN_EXPIRED);
			} else if (!verToken.isVerified()) {
				// exception if invalid
				throw new Exception(ResponseMessage.ERROR_EMAIL_TOKEN_INVALID);
			}

			// user = _userService.saveUser(user);
		} catch (Exception ex) {
			if (ex.getMessage().contains(
					ResponseMessage.ERROR_EMAIL_TOKEN_EXPIRED)) {
				log.error(ResponseMessage.ERROR_EMAIL_TOKEN_EXPIRED);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_EMAIL_TOKEN_EXPIRED);

			} else if (ex.getMessage().contains(
					ResponseMessage.ERROR_EMAIL_TOKEN_INVALID)) {
				log.error(ResponseMessage.ERROR_EMAIL_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_EMAIL_TOKEN_INVALID);

			}

			log.error(ResponseMessage.ERROR_USER_CREATE);
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
					ResponseMessage.ERROR_USER_CREATE);
		}
		log.info(ResponseMessage.ERROR_EMAIL_TOKEN_VALID);
		return CommonUtils.getResponseBean(verToken,
				ResponseMessage.ERROR_EMAIL_TOKEN_VALID);
	}

	/**
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/savepassword", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean savePassword(HttpServletRequest request, HttpServletResponse response, @RequestBody User user) throws Exception {
		if(_userService.validatePassword(user.getPassword())) {	    	
		// save the password
			user = _userService.savePassword(user.getVerificationToken(), user.getPassword());
			if (user == null) {
				throw new Exception(ResponseMessage.ERROR_SAVE_PASSWORD);
			}
			return CommonUtils.getResponseBean(ResponseStatus.SUCCESS, ResponseMessage.SAVE_PASSWORD);
	    } else
	    	return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.INVALID_PASSWORD_FORMAT);
	}

	/**
	 * set the password token
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/setpassword", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public ResponseBean setPasswordToken(HttpServletRequest request,
			HttpServletResponse response) {
		VerificationToken token = new VerificationToken();
		try {

			token = _userService.verifyTokenForSignup(request
					.getParameter("code"));
			System.out.println("tokn   " + token.isVerified());
			if (token == null)
				throw new Exception(ResponseMessage.TOKEN_SINGNUP_INVALID);
			else if (token.isTimeout())
				throw new Exception(ResponseMessage.TOKEN_SINGNUP_TIMEOUT);
			else if (!token.isVerified())
				throw new Exception(ResponseMessage.TOKEN_SINGNUP_INVALID);

		} catch (Exception ex) {
			if (ex.getMessage().contains(ResponseMessage.TOKEN_SINGNUP_TIMEOUT)) {
				log.error(ResponseMessage.TOKEN_SINGNUP_TIMEOUT);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.TOKEN_SINGNUP_TIMEOUT);

			} else if (ex.getMessage().contains(
					ResponseMessage.TOKEN_SINGNUP_INVALID)) {
				log.error(ResponseMessage.TOKEN_SINGNUP_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.TOKEN_SINGNUP_INVALID);

			}

		}
		return CommonUtils.getResponseBean(ResponseStatus.SUCCESS, ResponseMessage.TOKEN_SINGNUP_VALID);
	}

	/**
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/resendemail", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean resendEmail(HttpServletRequest request,
			HttpServletResponse response, @RequestBody User obj) {

		User user = new User();
		try {

			String userToken = obj.getUserToken();

			if (userToken == null
					|| (userToken != null && userToken.equals(""))) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
			} else if (!_userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)) {
				throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
			} else if (!_userService.checkAdminToken(userToken)) {
				throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			}

			if (!_userService.sendEmail(user.getNxpmpUrl(), user)) {
				throw new Exception(ResponseMessage.ERROR_EMAIL_SEND);
			}

		} catch (Exception ex) {
			if (ex.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)) {
				log.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ERROR_NOT_ADMIN);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_EMPTY)) {
				log.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_EMPTY);

			} else if (ex.getMessage().contains(
					ResponseMessage.ADMIN_TOKEN_INVALID)) {
				log.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(
						ResponseStatus.ADMIN_INVALID,
						ResponseMessage.ADMIN_TOKEN_INVALID);

			} else if (ex.getMessage().contains(
					ResponseMessage.ERROR_EMAIL_SEND)) {
				log.error(ResponseMessage.ERROR_EMAIL_SEND);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE,
						ResponseMessage.ERROR_EMAIL_SEND);

			}

		}
		return CommonUtils.getResponseBean(obj, ResponseMessage.EMAIL_SEND);
	}
	

	/**
	 * for manage user display 12/10/2016
	 * @param request
	 * @param response
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "/getManageUser", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean getManageUser(HttpServletRequest request,	HttpServletResponse response, @RequestBody User user) {
		user = _userService.getUserFromToken(user.getUserToken());
		if(user == null)
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_USER_NOT_FOUND);
		else
			return CommonUtils.getResponseBean(user, ResponseMessage.USER_FOUND);
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "/updateManageUser", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean updateManageUser(HttpServletRequest request,	HttpServletResponse response, @RequestBody User user) {
		user = _userService.updateManageUser(user);
		if(user == null)
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_USER_NOT_FOUND);
		else
			return CommonUtils.getResponseBean(user, ResponseMessage.USER_FOUND);
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "/forgotPassword", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean forgotPassword(HttpServletRequest request,	HttpServletResponse response, @RequestBody User user) {
		String nxpmpUrl = user.getNxpmpUrl();
		user = _userService.findByEmail(user.getEmail());
		user.setNxpmpUrl(nxpmpUrl);
		Boolean flag = false;
		
		if(user != null) 
			flag = _userService.sendPasswordToken(user);
		
		if(flag == false)
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_RESET_PASSWORD);
		else
			return CommonUtils.getResponseBean(ResponseStatus.SUCCESS, ResponseMessage.RESET_PASSWORD_SUCCESS);
}

	/**
	 * 
	 * @param request
	 * @param response
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "/resetUserPassword", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean resetUserPassword(HttpServletRequest request,	HttpServletResponse response, @RequestBody User user) {
		String nxpmpUrl = user.getNxpmpUrl();
		user = _userService.findOne(user.getUserid());
		user.setNxpmpUrl(nxpmpUrl);
		Boolean flag = false;
		
		if(user != null)
			flag = _userService.sendPasswordToken(user);
		
		if(flag == false)
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_RESET_PASSWORD);
		else
			return CommonUtils.getResponseBean(ResponseStatus.SUCCESS, ResponseMessage.RESET_PASSWORD_SUCCESS);
	}
}
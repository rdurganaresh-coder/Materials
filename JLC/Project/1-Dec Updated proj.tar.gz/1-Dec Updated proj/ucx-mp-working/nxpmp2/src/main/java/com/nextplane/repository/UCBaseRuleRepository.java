package com.nextplane.repository;

import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.UCBaseRule;

public interface UCBaseRuleRepository extends CrudRepository<UCBaseRule, Long> {

	
}

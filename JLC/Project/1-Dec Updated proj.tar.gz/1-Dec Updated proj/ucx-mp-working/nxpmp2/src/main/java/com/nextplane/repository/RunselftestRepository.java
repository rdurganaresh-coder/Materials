package com.nextplane.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.nextplane.model.Runselftest_instance;
import com.nextplane.model.UCDomain;

public interface RunselftestRepository  extends CrudRepository<Runselftest_instance, Long>{
	
	Runselftest_instance findByUcdomain(Long domain);
	
	@Transactional
	long deleteByUcdomain(Long id);

}

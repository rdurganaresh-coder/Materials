package com.nextplane;

/**
 * Module       : Task management
 * Class        : Task Controller
 * 
 * Created Date : 27/07/2016
 * Created By   : SVCIT NXPMP3
 */

import com.nextplane.model.ErrorObjectResponse;
import com.nextplane.model.ErrorResponse;
import com.nextplane.model.SuccessResponse;

public class CommonUtils {
	public static SuccessResponse getResponseBean(Object result, String message) {
		SuccessResponse responseBean = new SuccessResponse();
		responseBean.setObjResponse(result, message);
		return responseBean;
	}
	/*public static ErrorResponse getErrorResponseBean(String status, String errMsg) {
		ErrorResponse errorResponseBean = new ErrorResponse(status, errMsg);
		return errorResponseBean;
	}*/
	public static ErrorResponse getErrorResponseBean(int status, String errMsg) {
		ErrorResponse errorResponseBean = new ErrorResponse(status, errMsg);
		return errorResponseBean;
	}
	
	public static ErrorObjectResponse getErrorResponseBean(int status, Object errMsg) {
		ErrorObjectResponse errorResponseBean = new ErrorObjectResponse(status, errMsg);
		return errorResponseBean;
	}
}
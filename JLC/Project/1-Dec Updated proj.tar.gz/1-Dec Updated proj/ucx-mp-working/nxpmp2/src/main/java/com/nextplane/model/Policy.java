package com.nextplane.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

/**
 * Module       : Policy management
 * Class        : Policy
 * 
 * Created Date : 14/11/2016
 * Created By   : SVCIT NXPMP3
 */

@Entity
@Table(name="policy")
public class Policy {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	@Version
	private int version;
	
}

package com.nextplane.model;

/**
 * Module       : Task management
 * Class        : Task Controller
 * 
 * Created Date : 27/07/2016
 * Created By   : SVCIT NXPMP3
 */

public abstract class ResponseBean {
	
	private final int status;

	public ResponseBean(int status) {
		this.status = status;
	}
	
	public int getStatus() {
		return status;
	}	
}

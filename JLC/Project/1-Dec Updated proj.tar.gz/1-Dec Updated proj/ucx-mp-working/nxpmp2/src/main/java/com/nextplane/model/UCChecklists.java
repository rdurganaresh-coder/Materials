package com.nextplane.model;

/**
 * Module       : Check List management
 * Table		: uc_checklists
 * Class        : UCChecklists
 * 
 * Created Date : 10/08/2016
 * Created By   : SVCIT NXPMP3
 */

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="uc_checklists")
public class UCChecklists {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;	
	private String checklistId;	
	private String description;
	private String apiUrl;
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getChecklistId() {
		return checklistId;
	}

	public void setChecklistId(String checklistId) {
		this.checklistId = checklistId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
		
	public String getApiUrl() {
		return apiUrl;
	}

	@Override
	public String toString() {
		return "UCChecklists [id=" + id + ", checklistId=" + checklistId
				+ ", description=" + description + ", apiUrl=" + apiUrl + "]";
	}

	public void setApiUrl(String apiUrl) {
		this.apiUrl = apiUrl;
	}

}

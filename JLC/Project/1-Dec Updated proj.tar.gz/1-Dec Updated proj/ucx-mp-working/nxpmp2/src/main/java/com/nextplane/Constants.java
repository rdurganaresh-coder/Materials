package com.nextplane;

/**
 * Module       : Constants management
 * Interface    : Constants
 * 
 * Created Date : 01/07/2016
 * Created By   : SVCIT NXPMP3
 */

public interface Constants {
	
	public interface Project {
		public static final String PROJECTNAME = "PROJECTNAME";
	}
	public interface ResponseStatus {		
		public static final int  SUCCESS = 200;
		public static final int FAILURE = 404;
		public static final int DOMAIN_FAILURE = 502;
		public static final int ADMIN_INVALID = 503;
		public static final int UCTYPE_FAILURE = 504;
		public static final int FED_SAVE_FAILURE = 505;
		public static final int FED_VIEW_FAILURE = 506;
				
		public static final String FAILED = "failed";
		public static final String APPROVED = "approved";
		public static final String ERR_CODE_ID = "code";
		public static final String ERR_MSG_ID = "msg";
		public static final String ZERO_RESULTS = "zero_results";
	}	

	public interface ResponseMessage {		
		public static final String ADMIN_TOKEN_EMPTY = "The admin token is empty !!!";
		public static final String ADMIN_TOKEN_INVALID = "The admin token is invalid !!!";
		public static final String ERROR_NOT_ADMIN = " You are not previleged !!!";
		public static final String RESET_PASSWORD_SUCCESS = "Please login and update password";
		public static final String ERROR_RESET_PASSWORD = "Error in reset password";
		
		public static final String ERROR_COMPANY_CREATE_INVALID_DATA = "Please check the details entered !!!";
		public static final String COMPANY_CREATE = "Created Company !";
		public static final String COMPANY_LOADREF = "Got details for creating company !";
		public static final String ERROR_COMPANY_LOADREF = "ERror in getting details for creating company !";
		public static final String ERROR_COMPANY_EXISTS = "Company already exists !!!";
		public static final String ERROR_COMPANY = "Error in creating company !";
		
		public static final String ERROR_COMPANY_DOESNT_EXISTS = "Company doesnot exist !!!";
		public static final String ERROR_EDIT_COMPANY = "Error in editing the company !";
		public static final String EDIT_COMPANY = "Successfullyedited the company !";
		
		public static final String USER_CREATED = "User created successfully!";
		public static final String ERROR_USER_CREATE = "Unable to save user details!!!";
		public static final String ERROR_USER_EXISTS = "User already exists !!!";		
		
		public static final String USER_UPDATED = "User updated successfully!";
		public static final String USER_NOTFOUND = "User not found !!!";
		public static final String ERROR_USER_UPDATE = "Unable to update user details!!!";
		
		public static final String GET_USER_REF = "Got the references for User!";
		public static final String ERROR_USER_REF = "Unable to get references for User!!!";
		
		public static final String LIST_USER = "Successfully listed the users !!";
		public static final String ERROR_LIST_USER = "Error in listing the users !!!";
		
		public static final String LOGIN_DONE = "Successfully logged in ! ";
		public static final String ERROR_LOGIN = "Unable to login !!!";
		public static final String ERROR_LOGIN_INVALID_USER = "Invalid User !!!";		
		
		public static final String USER_FOUND = "Found User . ";
		public static final String ERROR_USER_NOT_FOUND = "User not Found !!!";
		
		public static final String USER_DELETED= "Deleted the  User . ";
		public static final String ERROR_USER_NOT_DELETED = "User not Deleted !!!";

		public static final String EMAIL_SEND = "Successfully sent email !!!";
		public static final String ERROR_EMAIL_SEND = "Email not send !!!";
		public static final String ERROR_EMAIL_TOKEN_VALID = "Email Verification token valid  !!!";
		public static final String ERROR_EMAIL_TOKEN_EXPIRED = "Email Verification token expired !!!";
		public static final String ERROR_EMAIL_TOKEN_INVALID = "Email Verification token invalid !!!";
		
		public static final String SHOW_COMPANIES ="Successfully Listed Companies ";
		public static final String ERROR_SHOW_COMPANIES ="Error Listing Companies ";
		
		public static final String SEARCH_COMPANIES ="Successfully searched the company ";
		public static final String ERROR_SEARCH_COMPANIES ="Error searching the company ";
		
		public static final String VIEW_COMPANY ="Successfully showed the company ";
		public static final String ERROR_VIEW_COMPANY ="Error viewing the company ";		
		
		public static final String SAVE_PASSWORD ="Successfully saved the password";
		public static final String INVALID_PASSWORD_FORMAT ="Invalid password format";
		public static final String ERROR_SAVE_PASSWORD ="Error saving  the password ";
		
		public static final String TOKEN_SINGNUP_TIMEOUT ="Time expired to set paassword ";
		public static final String TOKEN_SINGNUP_VALID ="Successfully verified token ";
		public static final String TOKEN_SINGNUP_INVALID ="The verificcation token is invalid";
		public static final String DELETE_COMPANY ="Successfully deleted  the company ";
		public static final String ERROR_DELETE_COMPANY ="Error deleting the company ";
		
		public static final String UCLISTS_RETRIEVED =" Got the UClists for creating the domain ";
		public static final String ERROR_UCLISTS_RETRIEVED =" Error retrieving UCLists for creating the domain";

		public static final String SAVE_DOMAIN =" Domain save sucess !! ";
		public static final String ERROR_SAVE_DOMAIN =" Error saving the domain !!";
		
		public static final String ERROR_VIEW_DOMAIN =" Error in finding the domain !!";
		public static final String VIEW_DOMAIN =" Successfully found the domain !!";
	}	
	
	public interface TasksResponseMessage {	
		public static final String DOMAIN_PROVISIONING = "Domain_Provisioning";
		
		public static final String ERROR_TASK_CREATE ="Error in creating Task";
		public static final String TASK_CREATED ="Task Created Successfully";

		public static final String NO_PENDING_TASK = "No Pending Task Found";
		public static final String LIST_PENDING_TASK = "List of Pending Tasks";
		public static final String TASK_UPDATED = "Task updated";
		
		public static final String COMMON_TASK_ID = "Common_Task_Id";	
		public static final String GET_TASKS = "Requested Task";
	}	

	public interface TaskStatus {		
		public static final String PENDING = "Pending";
		public static final String COMPLETED = "Completed";
		public static final String FEDERATION = "FEDERATION";
		public static final String FEDERATATED = "Federated with $domain";
		
		//For create task History
		public static final String FED_CREATED = "FED_CREATED";
		public static final String FED_APPROVED = "FED_APPROVED";
		public static final String FED_REJECTED = "FED_REJECTED";
		public static final String FED_REQMOREINFO = "FED_REQMOREINFO";
		public static final String FED_CHECKLISTCOMPLETED = "FED_CHECKLISTCOMPLETED";
		public static final String FED_CHECKLISTCREATED = "FED_CHECKLISTCREATED";		
		public static final String FED_CANCEL = "FED_CANCELLED";
		public static final String FED_UCXAPPROVED = "FED_UCXAPPROVED";
		public static final String FED_UCXREJECTED = "FED_UCXREJECTED";
		
		
	}

	public interface EmailContents {		
		public static final String REQ_MORE_INFO = "REQ_MORE_INFO";
		public static final String DOMAIN_VALIDATION ="DOMAIN_VALIDATION";
		public static final String FED_REQUEST ="FED_REQUEST";
		public static final String REQ_MORE_INFO_FROM_DEST = "REQ_MORE_INFO_FROM_DEST";
		public static final String REQ_MORE_INFO_UCX ="REQ_MORE_INFO_UCX";
		public static final String DOMAIN_CHECKLIST ="DOMAIN_CHECKLIST";
		public static final String DOMAIN_CHECKLIST_COMPLETED ="DOMAIN_CHECKLIST_COMPLETED";
		public static final String DOMAIN_SELFTEST = "DOMAIN_SELFTEST";
		public static final String DOMAIN_SELFTEST_PASSED ="DOMAIN_SELFTEST_PASSED";
		public static final String FEDERATION_CHECKLIST_SRCDOMAIN ="FEDERATION_CHECKLIST_SRCOOMAIN";
		public static final String FEDERATION_CHECKLIST_DESTDOMAAIN = "FEDERATION_CHECKLIST_DESTDOMAAIN";
		public static final String NOTIFY_UCX_FEDERATION ="NOTIFY_UCX_FEDERATION";
		public static final String NOTIFY_UCX_DOMAIN ="NOTIFY_UCX_DOMAIN";
		public static final String NOTIFY_UCX_TESTFAILED = "NOTIFY_UCX_TESTFAILED";
		public static final String NOTIFY_UCX_RMI ="NOTIFY_UCX_RMI";
		public static final String NOTIFY_UC_FEDERATION_CREATED ="NOTIFY_UC_FEDERATION_CREATED";
		public static final String FEDRATION_APPROVED ="FEDRATION_APPROVED";
		public static final String NOTIFY_UCX_REJECTED = "NOTIFY_UCX_REJECTED";
		public static final String NOTIFY_UCX_COMPLETED ="NOTIFY_UCX_COMPLETED";
		public static final String NOTIFY_UC_COMPLETED ="NOTIFY_UC_COMPLETED";
		public static final String NOTIFY_UCX_CANCELLED = "NOTIFY_UCX_CANCELLED";
		public static final String NOTIFY_UC_CANCELLED ="NOTIFY_UC_CANCELLED";
		public static final String DOMAIN_ACTIVE ="DOMAIN_ACTIVE";
		public static final String SERVICE_ACTIVE = "SERVICE_ACTIVE";
		public static final String SELF_TEST_RESULT ="SELF_TEST_RESULT";
		public static final String NOTIFY_UCX_TO_CONTACTSALES ="NOTIFY_UCX_TO_CONTACTSALES";
		public static final String INPUT_SERVICE_UCADMIN = "INPUT_SERVICE_UCADMIN";
		public static final String SERVICE_SELFTEST ="SERVICE_SELFTEST";
		public static final String SERVICE_SELFTEST_PASSED ="SERVICE_SELFTEST_PASSED";
		public static final String INPUT_SERVICE_UCX = "INPUT_SERVICE_UCX";
		public static final String SERVICE_REQ_MORE_INFO ="SERVICE_REQ_MORE_INFO";
		public static final String NOTIFY_UCX_SELFTEST_FAILURE ="NOTIFY_UCX_SELFTEST_FAILURE";
		public static final String NOTIFY_UCX_SERVICE_USERLIST_PROVISION = "NOTIFY_UCX_SERVICE_USERLIST_PROVISION";
		public static final String NOTIFY_ADHOC_TASK ="NOTIFY_ADHOC_TASK";
		public static final String NOTIFY_ADHOC_TASK_RESOLUTION ="NOTIFY_ADHOC_TASK_RESOLUTION";
		public static final String SERVICE_USERLIST_ACTIVE = "SERVICE_USERLIST_ACTIVE";
		public static final String SUPPORTEMAIL = "support@nextplane.net";
		public static final String NEWDOMAIN = "NEWDOMAIN";
		public static final String VERIFICATION = "VERIFICATION";
		public static final String DOMAIN_SELFTEST_FAILED = "DOMAIN_SELFTEST_FAILED";
		public static final String EMAILFROM = "EMAILFROM";
		public static final String UCXEMAIL = "UCXEMAIL";
		public static final String FEDERATION_CHECKLIST_COMPLETED ="Federation Checklist Completed";
		public static final String DOMAIN_VERIFICATION_COMPLETED ="DOMAIN_VERIFICATION_COMPLETED";		
		public static final String BRANDNAME = "BRANDNAME";
		public static final String RESET_UCADMIN_PASSWORD = "RESET_UCADMIN_PASSWORD";
		public static final String FORGOT_UCADMIN_PASSWORD = "FORGOT_UCADMIN_PASSWORD";
		
	}	

	public interface CheckListMessage {		
		public static final String CHECKLIST_CREATED = "Check List Created";
		public static final String ERROR_CHECKLIST_CREATE = "Error Check List Create";
		public static final String LIST_CHECKLIST = "All Check List";
		public static final String NO_CHECKLIST_FOUND = "Check List Not Found";
		public static final String ERROR_CHECKLIST_UPDATED = "Error Check List Update";
		public static final String CHECKLIST_UPDATED = "Check List Updated";
		public static final String GET_CHECKLIST = "Current Check List";

		public static final String CHECKLIST_INSTANCE_CREATED = "Check List Instance Created";
		public static final String ERROR_CHECKLIST_INSTANCE_CREATE = "Error Check List Instance Create";
		public static final String LIST_CHECKLIST_INSTANCE = "All Check List Instance";
		public static final String NO_CHECKLIST_INSTANCE_FOUND = "Check List Instance Not Found";
		public static final String ERROR_CHECKLIST_INSTANCE_UPDATED = "Error Check List Instance Update";
		public static final String CHECKLIST_INSTANCE_UPDATED = "Check List Instance Updated";
		public static final String GET_CHECKLIST_INSTANCE = "Current Check List Instance";
	}
	
	public interface Lookups {	

		public static final String PASS = "Pass";
		public static final String FAIL = "Fail";
		
		public static final String AUTHORIZATION = "authorization";	
		public static final String SRV_RECORD_FOUND = "SRV Record";	
		public static final String DOMAIN_NOT_FOUND = "No New Domain Exist For Verification";	
		public static final String NO_PORT_OPEN_STAUS_CHECK = "Port open status checking not requested";
		public static final String NOT_REQUESTED_SRV = "SRV checking not requested";
		public static final String SIP_PORT = "$sipPort";
		public static final String XMPP_PORT = "$xmppPort";
		public static final String VERIFICATION_COMPLETED = "Verification completed on $date";
		public static final String VERIFICATION_FAILED = "Verification Failed on $date";
		public static final String NXPFS_SERVER = "$target";
		public static final String NXPFS_FQDN = "$nxp.fqdn";
		
		public static final String VERIFY_EXTERNAL_SIP_PORT = "Verify port $port is open on your perimeter firewall.";
		public static final String VERIFY_EXTERNAL_XMPP = "Verify external XMPP SRV Record has been published";
		public static final String VERIFY_EXTERNAL_XMPP_TARGET = "Verify external XMPP SRV Record hostname ($target) is correct";
		public static final String VERIFY_EXTERNAL_XMPP_PORT = "Verify external XMPP SRV Record port number $port is correct";
		
		public static final String SIP = "SIP";
		public static final String XMPP = "XMPP";
		public static final String SIP_XMPP = "SIP_XMPP";
		public static final String CHECK_LIST_VALUES = "checklist_values";
		public static final String EDGE_NAME = "${edgeName}";
		public static final String DOMAIN1_NAME = "${domain1.domain}";
		public static final String DOMAIN2_NAME = "${domain2.domain}";
		public static final String CUSER_FQDN = "${user.fqdn}";		
		public static final String CHECK_LIST = "check_list";		
		public static final String SRV_VERIFICATION = "srv_verification";	
		public static final String SRV_VALUES = "srv_values";
		public static final String USER_FQDN = "user_fqdn";
		public static final String TARGET = "$target";
		public static final String DOMAIN_NAME = "$DomianName";
		public static final String MXTOOLBOXAPI = "MXTOOLBOXAPI";
	}
	
	public interface DomainMessage {
		
		public static final String DOMAIN_NOT_FOUND =" The domain not found";
		public static final String DOMAIN_EXISTS =" Domain already exists";		
		
		public static final String UCLISTS_RETRIEVED =" Got the UClists for creating the domain ";
		public static final String ERROR_UCLISTS_RETRIEVED =" Error retrieving UCLists for creating the domain";
		
		public static final String SAVE_DOMAIN =" Domain save sucess !! ";
		public static final String ERROR_SAVE_DOMAIN =" Error saving the domain !!";
		
		public static final String ERROR_VIEW_DOMAIN =" Error in finding the domain !!";
		public static final String VIEW_DOMAIN =" Successfully found the domain !!";
		
		public static final String ERROR_LISTING_DOMAIN =" Error in listing the domains !!";
		public static final String DOMAIN_LIST =" Successfully listed  the domains !!";		
		public static final String ERROR_DELETING_DOMAIN =" Error in deleting the domain !!";
		public static final String DOMIAN_DELETED =" Successfully deleted  the domains !!";
	}
	
	public interface RuleMessaage {	

		public static final String MSGID1 = "MSGID1";
		public static final String MSGID2 = "MSGID2";		
		public static final String MSGID4 = "MSGID4";
		public static final String MSGID5 = "MSGID5";
		public static final String MSGID6 = "MSGID6";	
	}
	
	public interface RunSelftests {
		
		public static final String RUNSELFTEST = "runSelftest";
	}
	
	public interface UCID {
		
		public static final String UCID5 = "UCID5";
		public static final String UCID13 = "UCID13";
	}
	
	public interface ZendeskRef {
		
		public static final String REQUESTER = "REQUESTER";
		public static final String REQUESTER_PASSWORD = "REQUESTER_PASSWORD";
		public static final String TOKEN = "TOKEN";
		public static final String URL = "URL";
		public static final String ASSIGNEE = "ASSIGNEE";
		public static final String UCX_DOMAIN_BODY = "UCX_DOMAIN_BODY";
		public static final String TICKET_TYPE = "TICKET_TYPE";
		public static final String TASK = "TASK";
		public static final String PROBLEM = "PROBLEM";
		public static final String INCIDENT = "INCIDENT";
		public static final String QUESTION = "QUESTION";
		public static final String TICKET_PRIORITY = "TICKET_PRIORITY";
		public static final String URGENT = "URGENT";
		public static final String HIGH = "HIGH";
		public static final String NORMAL = "NORMAL";
		public static final String LOW = "LOW";
		public static final String NOTIFY_UCX_FEDERATION = "NOTIFY_UCX_FEDERATION";
	}
	
	public interface Federation{
		
		public static final String FEDERATION = "FEDERATION";	
		public static final String DESCHECKLIST = "DESCHECKLIST";
		public static final String ACTIVEFED = "1";
		public static final String PENDINDFED = "3";
		public static final String INCOMINGFED = "2";
	}
	
	public interface UCFederationMessage{
		
		public static String LIST_DOMAINS = "Successfully listed the domains";
		public static String ERROR_LIST_DOMAINS = "Error listing the domains";
		public static String ERROR_LIST_COMPANIES = "Error listing the destination companies";
		public static String LIST_COMPANIES = "Successfully  listed the destination companies";
		public static String VIEW_FED = "View Federation Successfull";
		public static String ERROR_VIEW_FED = "Error showing the Federation";
		public static String ERROR_REC_APPROVE_FED = "Error receiver approve Federation";
		public static String LIST_FED_LOGIC = "Succesfully listed the federation logic ";
		public static String ERROR_LIST_FED_LOGIC = "Error listing the federation logic ";
		public static String SAVE_FED_LOGIC = "Succesfully saved the federation ";
		public static String SAVE_FED_LOGIC1 = "No Federation saved ";
		public static String ERROR_SAVE_FED_LOGIC = "Error saving the federation ";
		public static String EXCEPTION_SAVE_FED_LOGIC = "Exception  saving the federation ";
		public static String FEDCOOUNT = "Federation count -";
		public static String PENDING_COMPANYLIST = "Successfully listed the pending companies";
		public static String INCOMING_COMPANYLIST = "Successfully listed the incoming companies";
		public static String ACTIVE_COMPANYLIST = "Successfully listed the active companies";
		
		public static String ERROR_PENDING_COMPANYLIST = "Error listing the pending companies";
		public static String ERROR_INCOMING_COMPANYLIST = "Error listing the incoming companies";
		public static String ERROR_ACTIVE_COMPANYLIST = "Error listing the active companies";
		
		public static String ERROR_PF_NULL =  "Pending Federation is null";
		public static String ERROR_CR_NULL =  "Change request is null";

		public static String REC_APPROVE_FED = "Reciever approved Federation Successfull";
		public static String REC_REJECTED_FED = "Reciever rejected Federation Successfull";
		public static String REC_CANCEL_FED = "Reciever canceled Federation Successfull";
		public static String FEDERATIONALLOWED = "Federation Allowed";
		public static String FEDERATIONNOTALLOWED = "Federation Not allowed";
}
	
	public interface PFStatus{
		
		public static String DRAFT = "DRAFT";
		public static String SUBMITTED = "SUBMITTED";
	}
	public interface DecisionStatus{
		
		public static String APPROVED = "APPROVED";
		public static String REJECTED = "REJECTED";
		public static String REQMOREINFO = "REQMOREINFO";
		public static String CHECKLISTCOMPLETED = "CHECKLISTCOMPLETED";
		public static String CHECKLISTCREATED = "CHECKLISTCREATED";		
		public static String CANCEL = "CANCELLED";
		public static String UCXAPPROVED = "UCXAPPROVED";
		public static String UCXREJECTED = "UCXREJECTED";
		
	}
	
	public interface CRStatus	{
		
		public static String CR_NEW = "CR_NEW";
		public static String CR_ACTIVE = "CR_ACTIVE";
		public static String CR_COMPLETE = "CR_COMPLETE";
		public static String CR_CANCELLED = "CR_CANCELLED";
		public static String CR_REJECTED = "CR_REJECTED";
	}
	
	public interface CRFed	{
		
		public static String IM_FEDERATION = "IM_FEDERATION";
		public static String AV_FEDERATION = "AV_FEDERATION";
		public static String SERVICE_USERLIST = "SERVICE_USERLIST";
		public static String INVITE_DOMAIN = "INVITE_DOMAIN";
		public static String DOMAIN_PROVISION = "DOMAIN_PROVISION";
		public static String SERVICE_PROVISION = "SERVICE_PROVISION";
	}	
	
	public interface MailGunConf{
		
		public static String MAILGUN_API_KEY = "MAILGUN_API_KEY";
		public static String MAILGUN_HOST ="MAILGUN_HOST";		
	}
	
	public interface FederationType{
		
		public static String CHAT = "CHAT";
		public static String VOICE = "VOICE";
		public static String VIDEO = "VIDEO";	
	}	

	public interface Roles {			
		
		public static final String ROLE_USER = "ROLE_USER";
		public static final String ROLE_SALES = "ROLE_SALES";
		public static final String ROLE_ADMIN = "ROLE_ADMIN";
		public static final String ROLE_SUPER_ADMIN = "ROLE_SUPER_ADMIN";
		public static final String ROLE_ADMIN_SRC = "ROLE_ADMIN_SRC";
		public static final String ROLE_ADMIN_DESC = "ROLE_ADMIN_DESC";
	}	
	
	public interface TaskPriority {

		public static final String type = "taskPriority";
		public static final String ZERO = "ZERO";
		public static final String ONE = "ONE";
		public static final String TWO = "TWO";
		public static final String THREE = "THREE";
		public static final String FOUR = "FOUR";
		public static final String FIVE = "FIVE";
	}

	public interface CompanyType {

		public static final String PUBLIC = "PUBLIC";
		public static final String NON_PROFIT = "NON_PROFIT";
		public static final String EDUCATION = "EDUCATION";
		public static final String PRIVATE = "PRIVATE";
		public static final String GOVERNMENT = "GOVERNMENT";
	}

	public interface Policy {

		public static final String PROCESS_ID = "PROCESS_ID";
		
	}
	public interface PolicyMessage {

		public static final String FILE_EMPTY = "You failed to upload the file, because the file was empty.";
		public static final String FILE_UPLOADED = "You successfully uploaded file.";
		
	}
}
package com.nextplane.repository;

/**
 * Module       : Check List management
 * Class        : UCChecklistGroupRepository
 * 
 * Created Date : 10/08/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.UCChecklistGroup;

public interface UCChecklistGroupRepository extends CrudRepository<UCChecklistGroup	,Long>{

	List<UCChecklistGroup> findByGroupTypeAndTypeOrderById(String groupType, String type);

	List<UCChecklistGroup> findByGroupTypeAndTypeAndSrvShowOrderByChecklistId(String groupType, String type, Boolean srvShow);
 
}

package com.nextplane.repository;

import java.util.HashMap;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.UCPlatform;

public interface UCPlarformRepository extends CrudRepository<UCPlatform	,Long>{
	
	@Query("select id, ucname  from UCPlatform ")
	List<UCPlatform> getUCnames();
	
	@Query("select id, ucname  from UCPlatform ")
	HashMap<Long,String> getUCDomainLists();

	List<UCPlatform> findAll();
	
	UCPlatform findById(long id);

	@Query(" from UCPlatform order by ucname asc")
	List<UCPlatform> findUCTypes();
}

package com.nextplane.model;

/**
 * Module       : Check List management
 * Table		: uc_checllist_group
 * Class        : UCChecklistGroup
 * 
 * Created Date : 10/08/2016
 * Created By   : SVCIT NXPMP3
 */

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "uc_checllist_group")
public class UCChecklistGroup {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@OneToOne
	@JoinColumn(name = "checklistId")
	private UCChecklists checklistId;
	
	private String groupType;
	private String type;	
	private Boolean srvShow;
	
	@OneToOne
	@JoinColumn(name = "srvYes")
	private UCChecklists srvYes;
	
	@OneToOne
	@JoinColumn(name = "srvNo")
	private UCChecklists srvNo;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public UCChecklists getChecklistId() {
		return checklistId;
	}

	public void setChecklistId(UCChecklists checklistId) {
		this.checklistId = checklistId;
	}

	public String getGroupType() {
		return groupType;
	}

	public void setGroupType(String groupType) {
		this.groupType = groupType;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Boolean getSrvShow() {
		return srvShow;
	}

	public void setSrvShow(Boolean srvShow) {
		this.srvShow = srvShow;
	}

	public UCChecklists getSrvYes() {
		return srvYes;
	}

	public void setSrvYes(UCChecklists srvYes) {
		this.srvYes = srvYes;
	}

	public UCChecklists getSrvNo() {
		return srvNo;
	}

	public void setSrvNo(UCChecklists srvNo) {
		this.srvNo = srvNo;
	}

	@Override
	public String toString() {
		return "UCChecklistGroup [id=" + id + ", checklistId=" + checklistId
				+ ", groupType=" + groupType + ", type=" + type + ", srvShow="
				+ srvShow + ", srvYes=" + srvYes + ", srvNo=" + srvNo + "]";
	}
}

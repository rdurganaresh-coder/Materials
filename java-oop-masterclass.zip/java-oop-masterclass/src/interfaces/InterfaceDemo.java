package interfaces;

import java.util.*;

// ── Functional Interface ─────────────────────────────────────────
@FunctionalInterface
interface Validator<T> {
    boolean validate(T value);

    default Validator<T> and(Validator<T> other) {
        return value -> this.validate(value) && other.validate(value);
    }

    default Validator<T> or(Validator<T> other) {
        return value -> this.validate(value) || other.validate(value);
    }

    default Validator<T> negate() {
        return value -> !this.validate(value);
    }
}

// ── Observer Interface ────────────────────────────────────────────
interface OrderListener {
    void onOrderPlaced(String orderId, double amount);
    void onOrderCancelled(String orderId);
}

// ── Main Demo ─────────────────────────────────────────────────────
public class InterfaceDemo {

    public static void main(String[] args) {
        // Functional interface with lambdas
        Validator<String> notEmpty    = s -> s != null && !s.isBlank();
        Validator<String> notTooLong  = s -> s.length() <= 50;
        Validator<String> hasAtSign   = s -> s.contains("@");
        Validator<String> emailValid  = notEmpty.and(notTooLong).and(hasAtSign);

        String[] emails = {"alice@example.com", "", "invalid-email", "a".repeat(60) + "@x.com"};
        for (String e : emails)
            System.out.printf("%-35s valid=%s%n", e.length() > 25 ? e.substring(0,25)+"..." : e,
                    emailValid.validate(e));

        System.out.println();

        // Observer pattern with lambdas
        List<OrderListener> listeners = new ArrayList<>();
        listeners.add((id, amt) -> System.out.printf("[EMAIL] Order %s placed for ₹%.2f%n", id, amt));
        listeners.add((id, amt) -> System.out.printf("[SMS]   Order %s placed for ₹%.2f%n", id, amt));
        listeners.add(new OrderListener() {
            @Override public void onOrderPlaced(String id, double amt) {
                System.out.printf("[AUDIT] Order %s: ₹%.2f logged%n", id, amt);
            }
            @Override public void onOrderCancelled(String id) {
                System.out.printf("[AUDIT] Order %s cancelled%n", id);
            }
        });

        // Notify all listeners
        listeners.forEach(l -> l.onOrderPlaced("ORD-001", 1500.0));
    }
}

package com.nextplane.repository;

/**
 * Module       : Check List management
 * Class        : UCChecklistRuleRepository
 * 
 * Created Date : 10/08/2016
 * Created By   : SVCIT NXPMP3
 */

import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.UCChecklistRules;
import com.nextplane.model.UCPlatform;

public interface UCChecklistRuleRepository extends CrudRepository<UCChecklistRules, Long> {

	UCChecklistRules findByUcplatformIdAndOpenFed(UCPlatform checklistId, Boolean openFed);

}

package encapsulation;

/**
 * Demonstrates: Encapsulation, access modifiers, immutability, validation
 */
public final class Money {

    private final double amount;
    private final String currency;

    public Money(double amount, String currency) {
        if (amount < 0) throw new IllegalArgumentException("Amount cannot be negative: " + amount);
        if (currency == null || currency.length() != 3)
            throw new IllegalArgumentException("Currency must be a 3-letter code: " + currency);
        this.amount   = amount;
        this.currency = currency.toUpperCase();
    }

    public double getAmount()   { return amount; }
    public String getCurrency() { return currency; }

    // Operations return NEW Money — never mutate (immutable)
    public Money add(Money other) {
        requireSameCurrency(other);
        return new Money(this.amount + other.amount, this.currency);
    }

    public Money subtract(Money other) {
        requireSameCurrency(other);
        if (other.amount > this.amount)
            throw new IllegalArgumentException("Result would be negative");
        return new Money(this.amount - other.amount, this.currency);
    }

    public Money multiply(double factor) {
        if (factor < 0) throw new IllegalArgumentException("Factor cannot be negative");
        return new Money(this.amount * factor, this.currency);
    }

    private void requireSameCurrency(Money other) {
        if (!this.currency.equals(other.currency))
            throw new IllegalArgumentException("Currency mismatch: " + currency + " vs " + other.currency);
    }

    @Override
    public String toString() { return String.format("%s %.2f", currency, amount); }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Money m)) return false;
        return Double.compare(amount, m.amount) == 0 && currency.equals(m.currency);
    }

    @Override
    public int hashCode() { return java.util.Objects.hash(amount, currency); }

    public static void main(String[] args) {
        Money price = new Money(100.0, "INR");
        Money tax   = price.multiply(0.18);
        Money total = price.add(tax);
        System.out.println("Price: " + price);
        System.out.println("Tax:   " + tax);
        System.out.println("Total: " + total);
        System.out.println("Equal: " + price.equals(total));
    }
}

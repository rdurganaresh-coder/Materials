package com.nextplane.service;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.nextplane.model.UCDomain;
import com.nextplane.model.UCPlatform;

public class UCDomainServiceTest {

	@Autowired
	private UCDomain uCDomain;

	@Autowired
	private UCPlatform ucType;
	
	@Autowired
	private UCDomainService UCDomainServiceTest;
	
	@Before
	public void createObjects() throws Exception {
		//ucType
		ucType.setId(11);
		System.out.println("@Before"+uCDomain);		
	}
	
	@Test
	public void saveUCDomain() {
		uCDomain.setDomainName("google.com");
		uCDomain.setOpenFed(null);
		uCDomain.setSrvRecord(true);
		uCDomain.setUcType(ucType);
		UCDomainServiceTest.saveUCDomain(uCDomain);
	}
	
	@After
	public void deleteObjects() throws Exception {
		System.out.println("@After");
	}
	
}
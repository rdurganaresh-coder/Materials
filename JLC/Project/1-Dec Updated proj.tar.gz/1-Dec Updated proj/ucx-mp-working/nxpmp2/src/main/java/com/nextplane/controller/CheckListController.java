package com.nextplane.controller;

/**
 * Module       : Check List management
 * Class        : CheckListController
 * 
 * Created Date : 10/08/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestClientException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;

import com.nextplane.CommonUtils;
import com.nextplane.Constants.CheckListMessage;
import com.nextplane.Constants.DomainMessage;
import com.nextplane.Constants.Lookups;
import com.nextplane.Constants.ResponseStatus;
import com.nextplane.model.CheckListInstance;
import com.nextplane.model.PageableNxp;
import com.nextplane.model.ResponseBean;
import com.nextplane.model.SearchValue;
import com.nextplane.model.UCChecklistGroup;
import com.nextplane.model.UCChecklists;
import com.nextplane.model.UCDomain;
import com.nextplane.model.UCPlatform;
import com.nextplane.service.CheckListService;
import com.nextplane.service.UCDomainService;

@Controller
@RequestMapping(value = "/checkList")
public class CheckListController {

	private static final Logger LOGGGER = LoggerFactory.getLogger(CheckListController.class);
	
	@Autowired
	private CheckListService checkListService;

	@Autowired
	private UCDomainService ucDomainService;
	
	/**
	 * 
	 * @param checkList
	 * @return
	 */
	@RequestMapping(value = "/create",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean createCheckList(@RequestBody UCChecklists checkList){
		try {
			checkListService.createCheckList(checkList);
		} catch (Exception ex) {
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, CheckListMessage.ERROR_CHECKLIST_CREATE);
		}
		LOGGGER.info(CheckListMessage.CHECKLIST_CREATED);
		return CommonUtils.getResponseBean(checkList, CheckListMessage.CHECKLIST_CREATED);
	}	

	/**
	 * 
	 * @param checkList
	 * @return
	 */
	@RequestMapping(value = "/updateChekList",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean updateCheckList(@RequestBody UCChecklists checkList) {
		checkListService.updateTasks(checkList);
		if(checkList != null) {
			return CommonUtils.getResponseBean(checkList, CheckListMessage.CHECKLIST_UPDATED);
		}else {
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, CheckListMessage.ERROR_CHECKLIST_UPDATED);
		}
	}
	
	/**
	 * 
	 * @param PageableNxp
	 * @return
	 */
	@RequestMapping(value = "/list",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean list(@RequestBody PageableNxp pageableTask) {		
		pageableTask.setPageable();	
		Page<UCChecklists> uCChecklists = checkListService.list(pageableTask);
		if(uCChecklists == null)
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, CheckListMessage.NO_CHECKLIST_FOUND);	
		else
			return CommonUtils.getResponseBean(uCChecklists, CheckListMessage.GET_CHECKLIST);
	}

	/**
	 * 
	 * @param searchValue
	 * @return
	 */
	@RequestMapping(value = "/getCheckList",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean getCheckList(@RequestBody SearchValue searchValue) {
		UCPlatform ucplatform = null;
   		try{
   			//Check Uc platform validation
   			ucplatform = ucDomainService.getUCDomainAndRule(searchValue.getUcId());   			
   			if(ucplatform == null ){
   				throw new Exception(DomainMessage.ERROR_UCLISTS_RETRIEVED);
   			}else if(ucplatform.getUcbaseruleid()!= null && ucplatform.getUcbaseruleid().getId() == 1){
   				return CommonUtils.getErrorResponseBean(ResponseStatus.UCTYPE_FAILURE,ucplatform); 
   			}else if(ucplatform.getUcbaseruleid()!= null && ucplatform.getUcbaseruleid().getId() == 2){
   				return CommonUtils.getErrorResponseBean(ResponseStatus.UCTYPE_FAILURE,ucplatform); 
   			}   			

   			// Getting check list Details
   			List <UCChecklistGroup> uCChecklistGroup = checkListService.findByChecklistId(searchValue.getDomainId(), searchValue.getDomainName(),  searchValue.getEdgeName(), searchValue.getUcId(), searchValue.isOpenFed());
   			if(uCChecklistGroup == null)
   				return CommonUtils.getErrorResponseBean(ResponseStatus.DOMAIN_FAILURE, DomainMessage.DOMAIN_EXISTS);
   			else
   				return CommonUtils.getResponseBean(uCChecklistGroup, CheckListMessage.GET_CHECKLIST);		
   		}catch (Exception e){
   			if(e.getMessage().contains(DomainMessage.ERROR_UCLISTS_RETRIEVED)){
   				LOGGGER.error(DomainMessage.ERROR_UCLISTS_RETRIEVED);
   				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, DomainMessage.ERROR_UCLISTS_RETRIEVED);			
   			}   				
   		}
   		LOGGGER.info(DomainMessage.UCLISTS_RETRIEVED);
   		return CommonUtils.getResponseBean(ucplatform, "");   			
	}
	
	/**
	 * 
	 * @param checkListInstance
	 * @return
	 */
	@RequestMapping(value = "/saveCheckListInstance",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean saveCheckListInstance(@RequestBody long ucId) {
		boolean openFed = false;
		long domainId = 1;
		String scope = "Domain";
		String checker = "1";
		String refId1 = null;
		String refId2 = null;
		long version = 0;
		
		ArrayList<Long> checkedId = new ArrayList<Long>();
		checkedId.add((long) 10);
		checkedId.add((long) 16);
		checkedId.add((long) 18);
		
		long checkListInstance;
		try {
			
			checkListInstance = checkListService.saveCheckListInstance(ucId, openFed, 
					domainId, scope, checker, refId1, refId2, version, checkedId) ;
		} catch (Exception ex) {
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, CheckListMessage.ERROR_CHECKLIST_INSTANCE_CREATE);
		}
		LOGGGER.info(CheckListMessage.CHECKLIST_INSTANCE_CREATED);
		return CommonUtils.getResponseBean(checkListInstance, CheckListMessage.CHECKLIST_INSTANCE_CREATED);
	}
	
	/**
	 * 
	 * @param PageableNxp
	 * @return
	 */
	@RequestMapping(value = "/listCheckListInstance",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean listCheckListInstance(@RequestBody PageableNxp pageableTask) {		
		pageableTask.setPageable();	
		Page<CheckListInstance> checkListInstance = checkListService.listCheckListInstance(pageableTask);
		if(checkListInstance == null)
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, CheckListMessage.NO_CHECKLIST_INSTANCE_FOUND);	
		else
			return CommonUtils.getResponseBean(checkListInstance, CheckListMessage.GET_CHECKLIST_INSTANCE);
	}

	/**
	 * 
	 * @return
	 * @throws RestClientException
	 * @throws JSONException
	 * @throws ParseException
	 */
	@RequestMapping(value = "/domainVerification",method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public String getSRVRecord() {
		//String domainName = "svcof.com";
		String srvRecord = null;//checkListService.getSRVLookUps();		
		return srvRecord;
	}

	/**
	 * 
	 * @param searchValue
	 * @return
	 */
	@RequestMapping(value = "/checkPortOpen",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean checkPortOpen(@RequestBody  SearchValue searchValue) {
		//String domainName = "svcof.com";
		String srvRecord = checkListService.getTCPLookUps(searchValue.getDomainName(), searchValue.getUcId(), searchValue.isOpenFed(), searchValue.getPort());
		if(srvRecord == null)
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseStatus.FAILED);
		return CommonUtils.getResponseBean(srvRecord, Lookups.SRV_RECORD_FOUND);
	}
	
	/**
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getTodoVerifyDomain",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean getTodoVerifyDomain() {	
		List<UCDomain> ucDomin = checkListService.getTodoVerifyDomain();
		if(ucDomin == null)
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, CheckListMessage.NO_CHECKLIST_INSTANCE_FOUND);	
		else
			return CommonUtils.getResponseBean(ucDomin, CheckListMessage.GET_CHECKLIST_INSTANCE);
	}
}
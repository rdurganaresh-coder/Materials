package com.nextplane.service;

/**
 * Module       : Fed Check List management
 * Class        : FedCheckListService
 * 
 * Created Date : 20/09/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestHeader;

import com.nextplane.Constants.DecisionStatus;
import com.nextplane.Constants.EmailContents;
import com.nextplane.Constants.Federation;
import com.nextplane.Constants.Lookups;
import com.nextplane.Constants.Project;
import com.nextplane.Constants.TaskStatus;
import com.nextplane.model.ChangeRequest;
import com.nextplane.model.CheckListInstance;
import com.nextplane.model.FedBaseRule;
import com.nextplane.model.FedCheckListGroup;
import com.nextplane.model.NXPMPReference;
import com.nextplane.model.PendingFederation;
import com.nextplane.model.SearchValue;
import com.nextplane.model.TaskRecords;
import com.nextplane.model.UCChecklists;
import com.nextplane.model.UCDomain;
import com.nextplane.model.UCPlatform;
import com.nextplane.model.User;
import com.nextplane.repository.ActiveFederationRepository;
import com.nextplane.repository.ChangeRequestRepository;
import com.nextplane.repository.ChecklistInstanceRepository;
import com.nextplane.repository.FedBaseRuleRepository;
import com.nextplane.repository.FedCheckListGroupRepository;
import com.nextplane.repository.NXPMPReferenceRepository;
import com.nextplane.repository.PendingFederationRepository;
import com.nextplane.repository.TaskRecordsRepository;
import com.nextplane.repository.UCDomainRepository;
import com.nextplane.repository.UCPlarformRepository;
import com.nextplane.repository.UserRepository;

@Service
public class FedCheckListService {

	@Autowired
	private FedCheckListGroupRepository fedCheckListGroupRepository;
	
	@Autowired
	private FedBaseRuleRepository fedBaseRuleRepository;

	@Autowired
	private UCPlarformRepository uCPlarformRepository;

	@Autowired 
	private UCDomainRepository ucDomainRepository;
	
	@Autowired
	private ChecklistInstanceRepository checklistInstanceRepository;
	
	@Autowired
	private TaskRecordsService taskRecordsService;

	@Autowired
	private UserService userService;

	@Autowired
	private PendingFederationRepository pendingFederationRepository;
	
	@Autowired
	private ActiveFederationRepository activeFederationRepository;

	@Autowired
	private NXPMPReferenceRepository nXPMPReferenceRepository;
	
	@Autowired
	private UCDomainService uCDomainService;
	
	@Autowired
	private NXPMPService nXPMPService;
	
	@Autowired
	private ChangeRequestRepository changeRequestRepository;

	@Autowired
	private TaskRecordsService taskrecordsService;
	
	@Autowired
	private PendingFederationService pendingFederationService;

	@Autowired
	private TaskRecordsRepository tRecordsRepository;
	
	@Autowired 
	private UserRepository userRepository;
	
	/**
	 * 
	 * @param pendingFederation
	 * @return
	 */
	public List<FedCheckListGroup> getCheckLists(Long pendingFederation) {
		
		PendingFederation pendingFed = pendingFederationRepository.findById(pendingFederation);
		
		Long senderId = pendingFed.getSrcDomain().getId();
		Long receiverId = pendingFed.getDestDomain().getId();
		
		UCDomain senderUcDomain = ucDomainRepository.findById(senderId);		
		UCPlatform senderUCPlatform = uCPlarformRepository.findOne(senderUcDomain.getUcType().getId());
		
		UCDomain receiverUcDomain = ucDomainRepository.findById(receiverId);		
		UCPlatform receiverUCPlatform = uCPlarformRepository.findOne(receiverUcDomain.getUcType().getId());
				
		FedBaseRule fedBaseRule = null;
		
		// Find the baserule logic	
			if(senderUcDomain.getOpenFed() != null && receiverUcDomain.getOpenFed() == null)
				fedBaseRule = fedBaseRuleRepository.findReceiverFedBaserule
					(senderUCPlatform.getUcprotocol(), senderUcDomain.getOpenFed(), senderUcDomain.getUcType().getId()
							, receiverUCPlatform.getUcprotocol(), receiverUcDomain.getUcType().getId());
			else if(senderUcDomain.getOpenFed() == null && receiverUcDomain.getOpenFed() != null)
				fedBaseRule = fedBaseRuleRepository.findSenderFedBaserule
				(senderUCPlatform.getUcprotocol(), senderUcDomain.getUcType().getId()
						, receiverUCPlatform.getUcprotocol(), receiverUcDomain.getOpenFed(), receiverUcDomain.getUcType().getId());
			else if(senderUcDomain.getOpenFed() != null && receiverUcDomain.getOpenFed() != null)
				fedBaseRule = fedBaseRuleRepository.findTop1FedBaserule
				(senderUCPlatform.getUcprotocol(), senderUcDomain.getOpenFed(), senderUcDomain.getUcType().getId()
						, receiverUCPlatform.getUcprotocol(), receiverUcDomain.getOpenFed(), receiverUcDomain.getUcType().getId());
		
		if(fedBaseRule == null)
			fedBaseRule =  fedBaseRuleRepository.findFedBaserule(
					senderUCPlatform.getUcprotocol(), senderUcDomain.getUcType().getId(), 
					receiverUCPlatform.getUcprotocol(), receiverUcDomain.getUcType().getId());
		
		List<FedCheckListGroup> fedCheckListGroup = fedCheckListGroupRepository.findAllByGroupType(fedBaseRule.getSenderChecklist());
				
		return fedCheckListGroup;
	}

	/**
	 * 
	 * @param pendingFederation
	 * @param user
	 * @return
	 */
	public List<FedCheckListGroup> createCheckLists(PendingFederation pendingFederation, User user) {
		
		UCDomain senderUcDomain = ucDomainRepository.findById(pendingFederation.getSrcDomain().getId());		
		UCPlatform senderUCPlatform = uCPlarformRepository.findOne(senderUcDomain.getUcType().getId());
		
		UCDomain receiverUcDomain = ucDomainRepository.findById(pendingFederation.getDestDomain().getId());		
		UCPlatform receiverUCPlatform = uCPlarformRepository.findOne(receiverUcDomain.getUcType().getId());
		
		FedBaseRule fedBaseRule = null;
		
		// Find the baserule logic	
			if(senderUcDomain.getOpenFed() != null && receiverUcDomain.getOpenFed() == null)
				fedBaseRule = fedBaseRuleRepository.findReceiverFedBaserule
					(senderUCPlatform.getUcprotocol(), senderUcDomain.getOpenFed(), senderUcDomain.getUcType().getId()
							, receiverUCPlatform.getUcprotocol(), receiverUcDomain.getUcType().getId());
			else if(senderUcDomain.getOpenFed() == null && receiverUcDomain.getOpenFed() != null)
				fedBaseRule = fedBaseRuleRepository.findSenderFedBaserule
				(senderUCPlatform.getUcprotocol(), senderUcDomain.getUcType().getId()
						, receiverUCPlatform.getUcprotocol(), receiverUcDomain.getOpenFed(), receiverUcDomain.getUcType().getId());
			else if(senderUcDomain.getOpenFed() != null && receiverUcDomain.getOpenFed() != null)
				fedBaseRule = fedBaseRuleRepository.findTop1FedBaserule
				(senderUCPlatform.getUcprotocol(), senderUcDomain.getOpenFed(), senderUcDomain.getUcType().getId()
						, receiverUCPlatform.getUcprotocol(), receiverUcDomain.getOpenFed(), receiverUcDomain.getUcType().getId());
		
		if(fedBaseRule == null)
			fedBaseRule =  fedBaseRuleRepository.findFedBaserule(
					senderUCPlatform.getUcprotocol(), senderUcDomain.getUcType().getId(), 
					receiverUCPlatform.getUcprotocol(), receiverUcDomain.getUcType().getId());
		TaskRecords taskLastRecords = tRecordsRepository.findLastTask(pendingFederation.getCommonTaskId());
		
		taskRecordsService.updateCurrentTasks(taskLastRecords.getId());		
		TaskRecords taskObj = new TaskRecords(
				user, Federation.FEDERATION, new Date(), 
				null, pendingFederation.getSrcDomain(),  
				pendingFederation.getDestDomain(),  new Date());
	
		List<FedCheckListGroup> fedSenderCheckListGroup = fedCheckListGroupRepository.findAllByGroupType(fedBaseRule.getSenderChecklist());
		if(fedSenderCheckListGroup.size() > 0) {
			taskRecordsService.createFederationTask(taskObj, pendingFederation, taskLastRecords.getPriority()+1);		
			saveCheckListInstance(fedSenderCheckListGroup, senderUcDomain, senderUCPlatform, fedBaseRule, pendingFederation, 
					Federation.FEDERATION, "", null, null, new Long(senderUcDomain.getVersion()));
		} else 
			pendingFederation.setSrcCheckList(nXPMPReferenceRepository.findByLname(DecisionStatus.CHECKLISTCOMPLETED));
			
		List<FedCheckListGroup> fedReceiverCheckListGroup = fedCheckListGroupRepository.findAllByGroupType(fedBaseRule.getReceiverChecklist());
		if(fedReceiverCheckListGroup.size() > 0) {
			taskLastRecords = tRecordsRepository.findLastTask(pendingFederation.getCommonTaskId());		
			taskRecordsService.createFederationTask(taskObj, pendingFederation, taskLastRecords.getPriority()+1);
			saveCheckListInstance(fedReceiverCheckListGroup, receiverUcDomain, receiverUCPlatform, fedBaseRule, pendingFederation, 
					Federation.FEDERATION, "", null, null, new Long(receiverUcDomain.getVersion()));
		} else
			pendingFederation.setDesCheckList(nXPMPReferenceRepository.findByLname(DecisionStatus.CHECKLISTCOMPLETED));
		
		return fedReceiverCheckListGroup;
	}
	
	/**
	 * 
	 * @param federCheckListGroup
	 * @param ucDomain
	 * @param uCPlatform
	 * @param fedBaseRule
	 * @param pendingFederation
	 * @param scope
	 * @param checker
	 * @param refId1
	 * @param refId2
	 * @param version
	 * @return
	 */
	public long saveCheckListInstance(List<FedCheckListGroup> federCheckListGroup, UCDomain ucDomain, 
			UCPlatform uCPlatform, FedBaseRule fedBaseRule, PendingFederation pendingFederation, 
			String scope, String checker, String refId1, String refId2, long version) {
		try{			
			List<String> checkedId = new ArrayList<String>();
			for (Iterator<FedCheckListGroup> iterator = federCheckListGroup.iterator(); iterator.hasNext();) {
				FedCheckListGroup fedCheckList = (FedCheckListGroup) iterator.next();
				checkedId.add(""+fedCheckList.getFedChecklistId().getId());
			}
			
			for (Iterator<FedCheckListGroup> iterator = federCheckListGroup.iterator(); iterator.hasNext();) {
				FedCheckListGroup ucChecklistGroup2 = (FedCheckListGroup) iterator.next();		
				CheckListInstance checkListInstance = new CheckListInstance(
						checkedId.contains(ucChecklistGroup2.getFedChecklistId().getId()), checker, 
						ucDomain.getId(), 
						String.valueOf(fedBaseRule.getId()), pendingFederation.getChangeRequestId().getId(),
						refId2, scope, uCPlatform.getUcprotocol(), version,ucChecklistGroup2.getFedChecklistId());
				checklistInstanceRepository.save(checkListInstance);				
			}
			if(federCheckListGroup.size() > 0) {
				if(ucDomain.getId() == pendingFederation.getSrcDomain().getId())
					pendingFederation.setSrcCheckList(nXPMPReferenceRepository.findByLname(DecisionStatus.CHECKLISTCREATED));
				else
					pendingFederation.setDesCheckList(nXPMPReferenceRepository.findByLname(DecisionStatus.CHECKLISTCREATED));
				pendingFederationRepository.save(pendingFederation);					
			}
		}catch(Exception ex){
			ex.getMessage();
		}
		return ucDomain.getId();
	}
	
	/**
	 * 
	 * @param searchValue
	 * @param request
	 * @param response
	 * @return
	 */
	public PendingFederation updateCheckLists(SearchValue searchValue, String uri) {	
		
		Long refId = null;
		PendingFederation pendingFederaton = null;
		
		for (Iterator<Long> iterator = searchValue.getCheckedId().iterator(); iterator.hasNext();) {
			Long  checkListID = (Long) iterator.next();			
			CheckListInstance checkListInstance = checklistInstanceRepository.findOne(checkListID);
			checkListInstance.setChecked(true);
			checklistInstanceRepository.save(checkListInstance);
			refId = checkListInstance.getRefId1();			
		}
		
		ChangeRequest changeRequest = changeRequestRepository.findTop1ById(refId);
		pendingFederaton = pendingFederationRepository.findByChangeRequestId(changeRequest);

		User user = userService.getUserFromToken(searchValue.getUserToken());
		UCDomain domainId = null, destdomainId = null;
		if(searchValue.getFedType() == 2) {
			domainId = pendingFederaton.getDestDomain();
			destdomainId = domainId;
		} else if(searchValue.getFedType() == 3) {
			domainId = pendingFederaton.getSrcDomain();
		}
		
		List<CheckListInstance> pendingCheckListInstance = checklistInstanceRepository.findAllByRefId1AndDomainId(refId, domainId.getId());
		if(pendingCheckListInstance.size() == searchValue.getCheckedId().size()){
			//taskRecordsService.updateCurrentTasks(pendingFederaton.getFedId());
			if(destdomainId != null)
				pendingFederaton.setDesCheckList(nXPMPReferenceRepository.findByLname(DecisionStatus.CHECKLISTCOMPLETED));
			else
				pendingFederaton.setSrcCheckList(nXPMPReferenceRepository.findByLname(DecisionStatus.CHECKLISTCOMPLETED));
			pendingFederationRepository.save(pendingFederaton);

			TaskRecords taskRecords = tRecordsRepository.findByOneCompany(pendingFederaton.getCommonTaskId(), TaskStatus.PENDING, user.getCompanyId());
			if(taskRecords != null)
				taskRecordsService.updateCurrentTasks(taskRecords.getId());

			// Get the email for UCX admin
			if((pendingFederaton.getSrcCheckList() == nXPMPReferenceRepository.findByLname(DecisionStatus.CHECKLISTCOMPLETED)) && (pendingFederaton.getDesCheckList() == nXPMPReferenceRepository.findByLname(DecisionStatus.CHECKLISTCOMPLETED))) {

				TaskRecords taskObj = new TaskRecords(
						user, Federation.FEDERATION, new Date(), 
						user.getCompanyId(), pendingFederaton.getSrcDomain(),  
						pendingFederaton.getDestDomain(),  new Date());

				TaskRecords taskLastRecords = tRecordsRepository.findLastTask(pendingFederaton.getCommonTaskId());	
				taskRecordsService.createFederationTask(taskObj, pendingFederaton, taskLastRecords.getPriority()+1);		
				
				String fromEmail = "\"";				
				List<User> allSrcUser = userRepository.findByCompanyId(pendingFederaton.getSrcCompany());
				fromEmail = "\"";
				for (Iterator<User> iterator = allSrcUser.iterator(); iterator.hasNext();) {
					User user2 = (User) iterator.next();
					if(fromEmail.equalsIgnoreCase(""))
						fromEmail = "\"";
					else
						fromEmail = fromEmail+"\", \"";
					fromEmail = fromEmail+ user2.getEmail();
				}
				
				// Mail send to uc admin
				String url = uri + nXPMPReferenceRepository.findByDname(Project.PROJECTNAME).getLname()+"/federaton/approve/"+pendingFederaton.getId();
				sendFederationNotification(pendingFederaton, user, EmailContents.NOTIFY_UCX_FEDERATION, url, fromEmail+"\"");
				
				// create zendesk ticket				
				uCDomainService.createZendeskTicket(NXPMPService.subject, NXPMPService.body);
			}
			if(searchValue.getFedType() == 2)
				pendingFederationService.createTaskHistory(pendingFederaton.getId(), "", pendingFederaton.getDestDomain().getDomainName(), user, TaskStatus.FED_CHECKLISTCOMPLETED);
			else if(searchValue.getFedType() == 3)
				pendingFederationService.createTaskHistory(pendingFederaton.getId(), pendingFederaton.getSrcDomain().getDomainName(), "", user, TaskStatus.FED_CHECKLISTCOMPLETED);
		}
		return pendingFederaton;
	}
	

	/**
	 * 
	 * @param searchValue
	 * @return
	 */
	public List<CheckListInstance> getPendingCheckLists(SearchValue searchValue) {	
		PendingFederation pendingFed = pendingFederationRepository.findById(searchValue.getpendingFederationId());
		
		Long domainId = null;
		if(searchValue.getFedType() == 2)
			domainId = pendingFed.getDestDomain().getId();
		else if(searchValue.getFedType() == 3)
			domainId = pendingFed.getSrcDomain().getId();

		List<CheckListInstance> checkListInstance = checklistInstanceRepository.findAllByRefId1AndDomainId(pendingFed.getChangeRequestId().getId(), domainId);
		List<NXPMPReference> nXPMPReference = nXPMPReferenceRepository.findByType(Lookups.CHECK_LIST_VALUES);
		if(checkListInstance != null)
			for (Iterator<CheckListInstance> iterator = checkListInstance.iterator(); iterator.hasNext();) {
				CheckListInstance ucChecklistInstance = (CheckListInstance) iterator.next();
				UCChecklists UCChecklists = ucChecklistInstance.getChecklistId();			
				for (Iterator<NXPMPReference> iterator2 = nXPMPReference.iterator(); iterator2.hasNext();) {
					NXPMPReference nxpmpReference = (NXPMPReference) iterator2.next();				
					if(UCChecklists.getDescription().contains(nxpmpReference.getDname())) {
						String replaceVal = "";
						if(nxpmpReference.getDname().equalsIgnoreCase(Lookups.EDGE_NAME))
							replaceVal = pendingFed.getSrcDomain().getUcType().getEdgename();
						else if(nxpmpReference.getDname().equalsIgnoreCase(Lookups.DOMAIN1_NAME))
							replaceVal = pendingFed.getSrcDomain().getDomainName();					
						else if(nxpmpReference.getDname().equalsIgnoreCase(Lookups.DOMAIN2_NAME))
							replaceVal = pendingFed.getDestDomain().getDomainName();
						else
							replaceVal = nxpmpReference.getLname();
						UCChecklists.setDescription(UCChecklists.getDescription().replace(nxpmpReference.getDname(), replaceVal));
					}
					if(UCChecklists.getDescription().contains(Lookups.CUSER_FQDN)) {
						UCChecklists.setDescription(UCChecklists.getDescription().replace(Lookups.CUSER_FQDN, pendingFed.getSrcDomain().getFqdn()));
					}
				}
			}
		return checkListInstance;
	}
	
	/**
	 * 
	 * @param pendingFederaton
	 * @param user
	 * @param type
	 * @param url
	 */
	public void sendFederationNotification(PendingFederation pendingFederaton, User user, String type, String url, String emailTo){		
		HashMap<String, String> params = new HashMap<String, String>();
				if(pendingFederaton.getSrcDomain() != null)
				   params.put("srcDomainName", pendingFederaton.getSrcDomain().getDomainName());
			   else 
				   params.put("srcDomainName", "NULL");
			   
			   if(pendingFederaton.getDestDomain() != null) 
				   params.put("desDomainName", pendingFederaton.getDestDomain().getDomainName());
			   else
				   params.put("desDomainName" ,"NULL");
			   
			   if(emailTo != null)
				   params.put("email", emailTo);
			   else
				   params.put("email", "test@svcloudit.com");
			   
			   if(user.getCompanyId() != null)
				   params.put("name", user.getCompanyId().getName());
			   else
				   params.put("name", "");
			   
			   if(url != null && !url.equals("") || url.length() != 0){
				   params.put("url",url);
			   	   params.put("email", uCDomainService.getUCXEmail());
			   }else{
				   params.put("url","");
			   }
			   
		   	   params.put("${brandInfo.brandName}", nXPMPReferenceRepository.findByLname(EmailContents.BRANDNAME).getDname());
			  			   
			   nXPMPService.sendNotification(params, type);		
	}
}
package com.nextplane.model;

/**
 * Module       : Task management
 * Class        : Task Records History
 * 
 * Created Date : 24/08/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name ="task_records_history")
public class TaskRecordsHistory {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@NotNull
	private long id;

	private String type;
	private long dfId;
	private String description;
	
	@OneToOne
	@JoinColumn (name="createdBy")
	private User createdBy;
	
	@JsonFormat(pattern="MM/dd/yyyy, hh:mm a")
	private Date createdTime;
	private String srcDomain;
	private String destDomain;
	private int srvPort;
	private int xmppPort;
	private Boolean srvPortStaus;
	private Boolean xmppPortStaus;

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public long getDfId() {
		return dfId;
	}
	public void setDfId(long dfId) {
		this.dfId = dfId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public User getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public String getSrcDomain() {
		return srcDomain;
	}
	public String getDestDomain() {
		return destDomain;
	}
	public void setSrcDomain(String srcDomain) {
		this.srcDomain = srcDomain;
	}
	public void setDestDomain(String destDomain) {
		this.destDomain = destDomain;
	}
	public int getSrvPort() {
		return srvPort;
	}
	public void setSrvPort(int srvPort) {
		this.srvPort = srvPort;
	}
	
    public int getXmppPort() {
		return xmppPort;
	}
	public void setXmppPort(int xmppPort) {
		this.xmppPort = xmppPort;
	}
	public Boolean getSrvPortStaus() {
		return srvPortStaus;
	}
	public void setSrvPortStaus(Boolean srvPortStaus) {
		this.srvPortStaus = srvPortStaus;
	}
	public Boolean getXmppPortStaus() {
		return xmppPortStaus;
	}
	public void setXmppPortStaus(Boolean xmppPortStaus) {
		this.xmppPortStaus = xmppPortStaus;
	}
	public TaskRecordsHistory(){}
	
	public TaskRecordsHistory(String type , User createdBy , Long dfid , String srcDomain, String destDomain, String description , Date createdTime){
		this.createdBy = createdBy;
		this.type = type;
		this.dfId = dfid;
		this.srcDomain = srcDomain;
		this.destDomain = destDomain;
		this.description = description;
		this.createdTime = createdTime;		
	}
	
	public TaskRecordsHistory(String type , User createdBy , Long dfid , String srcDomain, String destDomain, String description, int srvPort , Date createdTime){
		this.createdBy = createdBy;
		this.type = type;
		this.dfId = dfid;
		this.srcDomain = srcDomain;
		this.destDomain = destDomain;
		this.description = description;
		this.srvPort = srvPort;
		this.createdTime = createdTime;		
	}
	
	public TaskRecordsHistory(String type , User createdBy , Long dfid , String srcDomain, 
			String destDomain, String description, int srvPort ,  int xmppPort, 
			 Boolean srvPortStaus, Boolean xmppPortStaus, Date createdTime){
		this.createdBy = createdBy;
		this.type = type;
		this.dfId = dfid;
		this.srcDomain = srcDomain;
		this.destDomain = destDomain;
		this.description = description;
		this.srvPort = srvPort;
		this.xmppPort = xmppPort;
		this.srvPortStaus = srvPortStaus;
		this.xmppPortStaus = xmppPortStaus;
		this.createdTime = createdTime;		
	}
}

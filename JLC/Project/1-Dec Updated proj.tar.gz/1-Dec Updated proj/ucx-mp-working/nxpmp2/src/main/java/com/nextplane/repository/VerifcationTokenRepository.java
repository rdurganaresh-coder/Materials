package com.nextplane.repository;

import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.User;
import com.nextplane.model.VerificationToken;

public interface VerifcationTokenRepository extends CrudRepository<VerificationToken, Long> {

	VerificationToken findByToken(String token);
	VerificationToken findByUser(User user);	
	String deleteByUser(User user);
	String deleteById(Long id);
}

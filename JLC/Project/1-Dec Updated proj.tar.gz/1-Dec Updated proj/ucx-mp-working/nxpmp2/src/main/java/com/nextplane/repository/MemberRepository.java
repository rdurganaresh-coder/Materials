package com.nextplane.repository;

import javax.transaction.Transactional;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.nextplane.model.Member;

@Transactional
public interface MemberRepository extends PagingAndSortingRepository<Member, Long> {	
}
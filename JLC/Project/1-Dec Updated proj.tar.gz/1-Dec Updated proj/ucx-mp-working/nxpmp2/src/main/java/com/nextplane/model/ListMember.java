package com.nextplane.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * Module       : Policy management
 * Class        : ListMember
 * 
 * Created Date : 15/11/2016
 * Created By   : SVCIT NXPMP3
 */

@Entity
@Table(name = "list_member")
public class ListMember {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;

	@OneToOne
	@JoinColumn(name = "member_id")
	private Member memberId;
	
	@OneToOne
	@JoinColumn(name = "policy_list_id")
	PolicyList policyListId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Member getMemberId() {
		return memberId;
	}

	public void setMemberId(Member memberId) {
		this.memberId = memberId;
	}

	public PolicyList getPolicyListId() {
		return policyListId;
	}

	public void setPolicyListId(PolicyList policyListId) {
		this.policyListId = policyListId;
	}

	@Override
	public String toString() {
		return "ListMember [id=" + id + ", memberId=" + memberId
				+ ", policyListId=" + policyListId + "]";
	}	
}
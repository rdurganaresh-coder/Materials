package com.nextplane.model;

import java.util.ArrayList;
import java.util.List;

public class ErrorResponse extends ResponseBean {

	private final List<String> response;

	public ErrorResponse(int status, List<String> response) {
		super(status);
		this.response = response;
	}

	public ErrorResponse(int status, String errMsg) {
		super(status);
		List<String> errorList = new ArrayList<String>();
		errorList.add(errMsg);
		this.response = errorList;
	}

	
	
	public List<String> getResponse() {
		return response;
	}
	
}

package com.nextplane.service;

/**
 * Module       : Check List management
 * Class        : CheckListRepository
 * 
 * Created Date : 10/08/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.nextplane.Constants.EmailContents;
import com.nextplane.Constants.Lookups;
import com.nextplane.Constants.ResponseStatus;
import com.nextplane.model.SRVRecords;
import com.nextplane.model.TaskRecords;
import com.nextplane.model.TaskRecordsHistory;
import com.nextplane.model.UCDomain;
import com.nextplane.model.CheckListInstance;
import com.nextplane.model.NXPMPReference;
import com.nextplane.model.PageableNxp;
import com.nextplane.model.UCChecklistGroup;
import com.nextplane.model.UCChecklistRules;
import com.nextplane.model.UCChecklists;
import com.nextplane.model.UCPlatform;
import com.nextplane.model.User;
import com.nextplane.repository.CheckListRepository;
import com.nextplane.repository.ChecklistInstanceRepository;
import com.nextplane.repository.NXPMPReferenceRepository;
import com.nextplane.repository.SRVRecordsRepository;
import com.nextplane.repository.UCChecklistGroupRepository;
import com.nextplane.repository.UCChecklistRuleRepository;
import com.nextplane.repository.UCDomainRepository;
import com.nextplane.repository.UCPlarformRepository;

@Service
public class CheckListService {

	@Autowired
	private CheckListRepository checkListRepository;
	
	@Autowired
	private UCChecklistRuleRepository ucCheckListRuleRepository; 
	
	@Autowired
	private UCChecklistRuleRepository uCChecklistRuleRepository;
	
	@Autowired
	private UCPlarformRepository uCPlarformRepository;
	
	@Autowired
	private UCChecklistGroupRepository uCChecklistGroupRepository;
	
	@Autowired
	private ChecklistInstanceRepository checklistInstanceRepository;

	@Autowired
	private NXPMPReferenceRepository nXPMPReferenceRepository;
	
	@Autowired 
	private UCDomainRepository ucDomainRepository;
	
	@Autowired
	private TaskRecordsService taskRecordsService;

	@Autowired
	private UserService userService;
	
	@Autowired
	private SRVRecordsRepository sRVRecordsRepository;
	
	@Autowired
	private UCDomainService ucDomainService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CheckListService.class);
	
	@Value("${skype}")
	private String SKYPE;

	@Value("${cisco}")
	private String CISCO;
	
	/**
	 * 
	 * @param ucCheckLists
	 * @return
	 */
	public UCChecklists createCheckList(UCChecklists ucCheckLists) {
		return checkListRepository.save(ucCheckLists);
	}

	/**
	 * 
	 * @param ucCheckLists
	 * @return
	 */
	public UCChecklists updateTasks(UCChecklists ucCheckLists) {
		UCChecklists ucCheckList = checkListRepository.findOne(ucCheckLists.getId());		
		if(ucCheckList != null) {
			ucCheckList.setDescription(ucCheckLists.getDescription());
			return checkListRepository.save(ucCheckList);
		} 
		else
			return ucCheckList;
	}

	/**
	 * 
	 * @param pageable
	 * @return
	 */
	public Page<UCChecklists> list(PageableNxp pageable) {
		return checkListRepository.findAll(pageable.getPageable());
	}

	/**
	 * 
	 * @param checklistId
	 * @param openFed
	 * @return
	 */
	public List <UCChecklistGroup> findByChecklistId(Long domainId, String domainName, String edgeName, long ucId, boolean openFed) {

		UCDomain ucDomain = null;
		
		if (domainId != null) {
			ucDomain = ucDomainRepository.findByDomainNameAndDeactivateAndIdNot(domainName, false, domainId);
			if (ucDomain != null)
				return null;
		} else {
			ucDomain = ucDomainRepository.findByDomainNameAndDeactivate(domainName, false);
			if (ucDomain != null)
				return null;
		}
		
			UCPlatform uCPlatform = uCPlarformRepository.findOne(ucId);
			UCChecklistRules uCChecklistRules = uCChecklistRuleRepository.findByUcplatformIdAndOpenFed(uCPlatform, openFed);
			List <UCChecklistGroup> uCChecklistGroup = uCChecklistGroupRepository.findByGroupTypeAndTypeOrderById(String.valueOf(uCChecklistRules.getChecklistGroup()), Lookups.CHECK_LIST);
			List<NXPMPReference> nXPMPReference = nXPMPReferenceRepository.findByType(Lookups.CHECK_LIST_VALUES);
			if(uCChecklistGroup != null)
				for (Iterator<UCChecklistGroup> iterator = uCChecklistGroup.iterator(); iterator.hasNext();) {
					UCChecklistGroup ucChecklistGroup2 = (UCChecklistGroup) iterator.next();
					UCChecklists UCChecklists = ucChecklistGroup2.getChecklistId();			
					for (Iterator<NXPMPReference> iterator2 = nXPMPReference.iterator(); iterator2.hasNext();) {
						NXPMPReference nxpmpReference = (NXPMPReference) iterator2.next();				
						if(UCChecklists.getDescription().contains(nxpmpReference.getDname())) {
							String replaceVal = "";
							if(nxpmpReference.getDname().equalsIgnoreCase(Lookups.EDGE_NAME))
								replaceVal = uCPlatform.getEdgename();
							else if(nxpmpReference.getDname().equalsIgnoreCase(Lookups.DOMAIN1_NAME))
								replaceVal = domainName;					
							else if(nxpmpReference.getDname().equalsIgnoreCase(Lookups.DOMAIN2_NAME))
								replaceVal = domainName;
							else
								replaceVal = nxpmpReference.getLname();
							UCChecklists.setDescription(UCChecklists.getDescription().replace(nxpmpReference.getDname(), replaceVal));
						}
						if(UCChecklists.getDescription().contains(Lookups.CUSER_FQDN)) {
							UCChecklists.setDescription(UCChecklists.getDescription().replace(Lookups.CUSER_FQDN, edgeName));
						}
					}
				}
			return uCChecklistGroup;	
				
	}

	/**
	 * 
	 * @param ucId
	 * @param openFed
	 * @param domainId
	 * @param scope
	 * @param checker
	 * @param refId1
	 * @param refId2
	 * @param version
	 * @param checkedId
	 * @return
	 */
	public long saveCheckListInstance(long ucId, boolean openFed, 
			long domainId, String scope, String checker,
			String refId1, String refId2, long version, List<Long> checkedId) {
		try{
			UCPlatform uCPlatform = uCPlarformRepository.findOne(ucId);
			UCChecklistRules uCChecklistRules = uCChecklistRuleRepository.findByUcplatformIdAndOpenFed(uCPlatform, openFed);
			List <UCChecklistGroup> uCChecklistGroup = uCChecklistGroupRepository.findByGroupTypeAndTypeOrderById(String.valueOf(uCChecklistRules.getChecklistGroup()), Lookups.CHECK_LIST);

			for (Iterator<UCChecklistGroup> iterator = uCChecklistGroup.iterator(); iterator.hasNext();) {
				UCChecklistGroup ucChecklistGroup2 = (UCChecklistGroup) iterator.next();		
				CheckListInstance checkListInstance = new CheckListInstance(
						checkedId.contains(ucChecklistGroup2.getChecklistId().getId()), checker, 
						domainId, 
						String.valueOf(uCChecklistRules.getId()), null,
						refId2, scope, uCPlatform.getUcprotocol(), version,ucChecklistGroup2.getChecklistId());			
				checklistInstanceRepository.save(checkListInstance);
			}
		}catch(Exception ex){
			ex.getMessage();
		}
		return ucId;
	}

	/**
	 * 
	 * @param pageableNxp
	 * @return
	 */
	public Page<CheckListInstance> listCheckListInstance(PageableNxp pageableNxp) {
		return checklistInstanceRepository.findAll(pageableNxp.getPageable());
	}

	/**
	 * 
	 * @param ucDomain
	 * @param user
	 * @return
	 * @throws JSONException
	 */
	public TaskRecordsHistory getSRVLookUps(UCDomain ucDomain, User user) throws JSONException {
		String commandSRV = "srv", domainNameHead = "", strTarget = "";		
		String command = "tcp";
		String strDomain = "", srvMessages = "", portMessage = "", xmppPort = "", srvPortcmd = "", srvPort = "", nxpTarget = "";
		Boolean srvPortStaus = true, xmppPortStaus = true;
		int checkingFlag = 0;
		TaskRecordsHistory tasks = null;
		try {
			if(ucDomain.getDomainName() != null) {
				NXPMPReference authorizationKey = nXPMPReferenceRepository.findOneByType(Lookups.AUTHORIZATION);
					srvPortcmd = null;
			    	String search = null;
					UCPlatform uCPlatform = uCPlarformRepository.findOne(ucDomain.getUcType().getId());

				if (uCPlatform.getUcprotocol().equalsIgnoreCase(Lookups.XMPP)) {
					checkingFlag = 1;
					domainNameHead = "_xmpp-server._tcp.";
					srvPortcmd = nXPMPReferenceRepository.findByDname(Lookups.XMPP_PORT).getLname();
				} else if (uCPlatform.getUcprotocol().equalsIgnoreCase(Lookups.SIP)) {
					checkingFlag = 1;
					domainNameHead = "_sipfederationtls._tcp.";
					srvPortcmd = nXPMPReferenceRepository.findByDname(Lookups.SIP_PORT).getLname();
					xmppPort=srvPortcmd;
				} else {
					checkingFlag = 2;
					domainNameHead = "_sipfederationtls._tcp.";
					srvPortcmd = nXPMPReferenceRepository.findByDname(Lookups.SIP_PORT).getLname();
					xmppPort = nXPMPReferenceRepository.findByDname(Lookups.XMPP_PORT).getLname();	
				}
				nxpTarget = nXPMPReferenceRepository.findByDname(Lookups.NXPFS_SERVER).getLname();
				
				srvPort = srvPortcmd;
				
				for (int i = 0; i < checkingFlag; i++) {
					strTarget = "";
					if(i == 1) {
						domainNameHead = "_xmpp-server._tcp.";
						srvPortcmd=xmppPort;					
					}
					boolean openFed = false;
					if (ucDomain.getOpenFed() != null)
						openFed = ucDomain.getOpenFed();
					
					UCChecklistRules uCChecklistRules = uCChecklistRuleRepository.findByUcplatformIdAndOpenFed(uCPlatform, openFed);
					if(uCChecklistRules.getSrv() == 1) {						
					    String srvUrlResult = getMXLookUps(commandSRV, domainNameHead+ucDomain.getDomainName(), authorizationKey.getLname(), "");
						JSONObject jsonObj = new JSONObject(srvUrlResult);
				    	String srvDomin = jsonObj.has("Information")?jsonObj.getString("Information"):"";
				    	JSONObject srvJsonObj = new JSONObject(srvUrlResult);		
						String srvError = srvJsonObj.has("Errors")?srvJsonObj.getString("Errors"):"";
					    if(srvError.equalsIgnoreCase("[]")) {
					    	if(!srvDomin.equalsIgnoreCase("[]")) {
								if (uCPlatform.getUcprotocol().equalsIgnoreCase(Lookups.XMPP) || uCPlatform.getUcprotocol().equalsIgnoreCase(Lookups.XMPP)) {
							    	srvDomin = srvDomin.replace("[", "");srvDomin = srvDomin.replace("]", "");
							    	
									JSONObject jsonObjTarget = new JSONObject(srvDomin);
									strTarget = jsonObjTarget.has("Target") ? jsonObjTarget.getString("Target") : "";
									
									System.out.println("target = "+strTarget);
									if(strTarget.equalsIgnoreCase(nxpTarget)) {
										srvMessages = "success";										
									}else
										srvMessages = "fail";
								}else {
									srvMessages = "success";
									strTarget = "";
								}
							} else
								srvMessages = "fail";
						} else {
							srvError = srvError.replace("[", "");
							srvError = srvError.replace("]", "");
							jsonObj = new JSONObject(srvError);
							srvMessages = jsonObj.has("Messages") ? jsonObj.getString("Messages") : "";
						}
					} else {
						srvMessages = Lookups.NOT_REQUESTED_SRV;
					}					

					if (uCChecklistRules.getPort() == 1) {
						search = "&port=" + srvPortcmd;
						String tcpString = getMXLookUps(command, ucDomain.getDomainName(), authorizationKey.getLname(), search);

						JSONObject tcpJsonObj = new JSONObject(tcpString);
						String tcpPort = tcpJsonObj.has("Passed") ? tcpJsonObj.getString("Passed") : "";
						if (tcpPort.contains("TCP Connect")) {
							portMessage = "success";
							if(xmppPort != "")
								xmppPortStaus = true;
							else
								srvPortStaus = true;
						} else {
							if(xmppPort != "") xmppPortStaus = false;
							else srvPortStaus = false;
							portMessage = "fail";
						}
					} else {	
						if(xmppPort != "") xmppPortStaus = null;
						else srvPortStaus = null;		
						portMessage = "fail";			
						//xmppPort = Lookups.NO_PORT_OPEN_STAUS_CHECK;
					}
					if(srvMessages.equalsIgnoreCase("fail") || portMessage.equalsIgnoreCase("fail")) {
						srvMessages = "fail";
						i=checkingFlag;
					}
				}
				if(srvMessages.equalsIgnoreCase("success") && srvPortStaus == true && xmppPortStaus == true) {
					VerifiedDomain(ucDomain, true, true, true);
					srvMessages = Lookups.VERIFICATION_COMPLETED.replace("$date",
							taskRecordsService.getDateString(new Date()));
				} else {
					srvMessages = Lookups.VERIFICATION_FAILED.replace("$date",
							taskRecordsService.getDateString(new Date()));					
				}

				tasks = taskRecordsService.updateDNSTaskHistory(
						taskRecordsService.getReferenceValueForHistory("DOMAIN"), 
						user, ucDomain.getId(), nxpTarget, strTarget,
						srvMessages, 
						Integer.parseInt(srvPort==""?null:srvPort), Integer.parseInt(xmppPort==""?null:xmppPort), 
						srvPortStaus, xmppPortStaus, new Date());
			}else
				strDomain = Lookups.DOMAIN_NOT_FOUND;			
			LOGGER.info(strDomain);
		}catch(Exception e){
			LOGGER.error(e.getMessage());
		}
	    return tasks;			
	}
	
	public void VerifiedDomain(UCDomain ucDomain, boolean verificationPending, boolean verification, boolean port) {
		ucDomain.setVerificationPending(verificationPending);
		ucDomain.setVerification(verification);
		ucDomain.setPortOpenStaus(port);
	    ucDomainRepository.save(ucDomain);
	}
	
	
	/**
	 * 
	 * @param command
	 * @param domainName
	 * @param authorizationKey
	 * @param search
	 * @return
	 */
	public String getMXLookUps(String command, String domainName, String authorizationKey, String search) {
		RestTemplate restTemplate = new RestTemplate();
		String url = nXPMPReferenceRepository.findByDname(Lookups.MXTOOLBOXAPI).getLname() + command +"/"+ domainName +"?Authorization="+ authorizationKey + search;
		System.out.println(url);
	    return restTemplate.getForObject(url, String.class);
	}
	
	
	/**
	 * 
	 * @param domainName
	 * @param ucId
	 * @param openFed
	 * @param port
	 * @return
	 */
	public String getTCPLookUps(String domainName, long ucId, boolean openFed, String port) {
		String result = null, command = "tcp";
		UCPlatform uCPlatform = uCPlarformRepository.findOne(ucId);
		UCChecklistRules uCChecklistRules = uCChecklistRuleRepository.findByUcplatformIdAndOpenFed(uCPlatform, openFed);
		if(uCChecklistRules.getPort() == 1) {	
			NXPMPReference authorizationKey = nXPMPReferenceRepository.findOneByType(Lookups.AUTHORIZATION);
		    final String url = nXPMPReferenceRepository.findByDname(Lookups.MXTOOLBOXAPI).getLname() + command +"/"+ domainName +"?Authorization="+ authorizationKey.getLname() +"&port="+ port;
			RestTemplate restTemplate = new RestTemplate();
			System.out.println(url);
			result = restTemplate.getForObject(url, String.class);	    
		}
	    return result;		
	}
	
	/**
	 * 
	 * @param domainId
	 * @param checked
	 * @return
	 */
	public Long getUnCheckedCount(long domainId, boolean checked){
		Long count = null;
		try {
			 count = checklistInstanceRepository.countByDomainIdAndChecked(domainId, checked);
		} catch (Exception e) {
			// TODO: handle exception
			count = null;
		}
		return count;
	}

	public List<UCDomain> getTodoVerifyDomain() {
		List<UCDomain> ucDomain = ucDomainRepository.findByVerificationPendingAndVerification(true, false);
		System.out.println("ucDomain"+ucDomain.size());
		return ucDomain;
	}

	/**
	 * 
	 * @param ucDomain
	 * @param userToken
	 * @return
	 * not using
	 */
	public String portVerification(UCDomain ucDomain, String userToken, String portType) {
		String portMessage = "", tcpPort ="";
		Long ucId = ucDomain.getUcid();
		ucDomain = ucDomainRepository.findById(ucDomain.getUcid());			
		String targetName = "";
		
		System.out.println("FQDN = "+ucDomain.getFqdn());
			ucDomain.setUcid(ucId);
			Map<String, String> srvSetup;
			if(Lookups.XMPP_PORT.equalsIgnoreCase(portType)) {
				if (ucDomain.getFqdn() == null) {
					srvSetup = old_srvVerification(ucDomain, userToken, Lookups.XMPP);
					targetName = (String)srvSetup.get("strTarget");
				} else 
					targetName = ucDomain.getFqdn();
			} else {
				srvSetup = old_srvVerification(ucDomain, userToken, Lookups.SIP);
				targetName = (String)srvSetup.get("strTarget");
			}
			System.out.println("targetName = "+targetName);
		
			if(targetName != null) {
				NXPMPReference authorizationKey = nXPMPReferenceRepository.findOneByType(Lookups.AUTHORIZATION);
			
				String tcpString = getMXLookUps("tcp", targetName, authorizationKey.getLname(), "&port=" + nXPMPReferenceRepository.findByDname(portType).getLname());
				JSONObject tcpJsonObj;
				try {
					tcpJsonObj = new JSONObject(tcpString);
					tcpPort = tcpJsonObj.has("Passed") ? tcpJsonObj.getString("Passed") : "";
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (tcpPort.contains("TCP Connect")) {
					portMessage = Lookups.PASS;
				} else {
					portMessage = Lookups.FAIL;
				}
			}else
				portMessage = Lookups.FAIL;
	//	}
		return portMessage;
	}

	/**
	 * 
	 * not using
	 * @param ucDomain
	 * @param userToken
	 * @param srvType
	 * @return
	 */
	public Map<String, String> old_srvVerification(UCDomain ucDomain, String userToken, String srvType) {
		String commandSRV = "srv", srvStatus = "", domainNameHead = "", strTarget = "";	
		String nxpTarget = "", targetMessages = "", strPort = "", portMessages = "";
		Map<String, String> srvChecking = new HashMap<String, String>();
		
		ucDomain = ucDomainRepository.findById(ucDomain.getUcid());	
		if (!srvType.equalsIgnoreCase(Lookups.SIP))
			if(ucDomain.getFqdn() == null)
				nxpTarget = nXPMPReferenceRepository.findByDname(Lookups.NXPFS_SERVER).getLname();
			else
				nxpTarget = ucDomain.getFqdn();
		else
			if(ucDomain.getFqdn() == null)
				nxpTarget = nXPMPReferenceRepository.findByDname(Lookups.NXPFS_SERVER).getLname();
			else
				nxpTarget = ucDomain.getFqdn();
		
			if (srvType.equalsIgnoreCase(Lookups.SIP))
				domainNameHead = "_sipfederationtls._tcp.";
			else 
				domainNameHead = "_xmpp-server._tcp.";
			
			NXPMPReference authorizationKey = nXPMPReferenceRepository.findOneByType(Lookups.AUTHORIZATION);
		    String srvUrlResult = getMXLookUps(commandSRV, domainNameHead+ucDomain.getDomainName(), authorizationKey.getLname(), "");
			JSONObject jsonObj;
			try {
				jsonObj = new JSONObject(srvUrlResult);
				String srvDomin = jsonObj.has("Information")?jsonObj.getString("Information"):"";
		    	JSONObject srvJsonObj = new JSONObject(srvUrlResult);		
				String srvError = srvJsonObj.has("Errors")?srvJsonObj.getString("Errors"):"";
			    if(srvError.equalsIgnoreCase("[]")) {
			    	srvStatus = Lookups.PASS;
			    	if(!srvDomin.equalsIgnoreCase("[]")) {
			    		srvStatus = Lookups.PASS;

					    srvDomin = srvDomin.replace("[", "");srvDomin = srvDomin.replace("]", "");
						JSONObject jsonObjTarget = new JSONObject(srvDomin);
						strTarget = jsonObjTarget.has("Target") ? jsonObjTarget.getString("Target") : "";
						System.out.println("strTarget"+strTarget);
						if (srvType.equalsIgnoreCase(Lookups.XMPP)) {
							if(strTarget.equalsIgnoreCase(nxpTarget)) {
								targetMessages = Lookups.PASS;										
							}else
								targetMessages = Lookups.FAIL;
							
							String xmppPortStr = nXPMPReferenceRepository.findByDname(Lookups.XMPP_PORT).getLname();
							JSONObject jsonObjPort = new JSONObject(srvDomin);
							strPort = jsonObjPort.has("Port") ? jsonObjPort.getString("Port") : "";
							
							System.out.println(xmppPortStr + " = Port = "+strPort);
							if(strPort.equalsIgnoreCase(xmppPortStr)) {
								portMessages = Lookups.PASS;										
							}else
								portMessages = Lookups.FAIL;
						}
						/*if(ucDomain.getFqdn() == null) {
							ucDomain.setFqdn(strTarget);
						}*/
						ucDomain.setSrvRecord(true);
						ucDomainRepository.save(ucDomain);
					} else
						srvStatus = Lookups.FAIL;
				} else {
			    	srvStatus = Lookups.FAIL;
					strTarget = "";
				}			    
			    
			} catch (JSONException e) {
				e.printStackTrace();
			}
		srvChecking.put("srvMessages", srvStatus);
		if (srvStatus.equalsIgnoreCase(Lookups.PASS))
			srvChecking.put("srvStatus", "" + ResponseStatus.SUCCESS);
		else
			srvChecking.put("srvStatus", "" + ResponseStatus.FAILURE);

		srvChecking.put("strTarget", strTarget);
		if (targetMessages.equalsIgnoreCase(Lookups.PASS))
			srvChecking.put("targetStatus", "" + ResponseStatus.SUCCESS);
		else
			srvChecking.put("targetStatus", "" + ResponseStatus.FAILURE);

		srvChecking.put("strPort", strPort);
		if (portMessages.equalsIgnoreCase(Lookups.PASS))
			srvChecking.put("portStatus", "" + ResponseStatus.SUCCESS);
		else
			srvChecking.put("portStatus",""+ResponseStatus.FAILURE);		
						
		return srvChecking;
	}
/*
	public void saveTaskHistory(UCDomain ucDomain, Long domainId, User user) {
		String srvMessages = "", nxpTarget = "", sipPort = "", xmppPort = "";
		boolean status = true;

		System.out.println(ucDomain.getVerifySipUrl());
		System.out.println(ucDomain.getVerifyxmppurl());
		System.out.println(ucDomain.getVerifyXmppSrvPort());
		
		if(ucDomain.getVerifySipUrl() != null && ucDomain.getVerifySipUrl() == false)
			status = false;
			
		if(status == true && ucDomain.getVerifyxmppurl() != null && ucDomain.getVerifyxmppurl() == false)
			status = false;
	
		if(status == true && ucDomain.getVerifyXmppSrvPort() != null && ucDomain.getVerifyXmppSrvPort() == false)
			status = false;

		if(status == true && ucDomain.getVerifysipport() != null && ucDomain.getVerifysipport() == false)
			status = false;	
		
		if(status == true && ucDomain.getVerifyxmppport() != null && ucDomain.getVerifyxmppport() == false)
			status = false;
				
		nxpTarget = nXPMPReferenceRepository.findByDname(Lookups.NXPFS_SERVER).getLname();
		ucDomain = ucDomainRepository.findById(domainId);
		if(status == true) {
			sipPort = nXPMPReferenceRepository.findByDname(Lookups.SIP_PORT).getLname();
			taskRecordsService.updateTasks(ucDomain.getChangeRequestId());	
			VerifiedDomain(ucDomain, true, true, true);
			srvMessages = Lookups.VERIFICATION_COMPLETED.replace("$date", taskRecordsService.getDateString(new Date()));
		} else {
			sipPort = nXPMPReferenceRepository.findByDname(Lookups.SIP_PORT).getLname();
			xmppPort = nXPMPReferenceRepository.findByDname(Lookups.XMPP_PORT).getLname();
			VerifiedDomain(ucDomain, false, false, false);
			srvMessages = Lookups.VERIFICATION_FAILED.replace("$date", taskRecordsService.getDateString(new Date()));					
		}
		
		int sipPorts = 0;
		int xmppPorts = 0;
		
		if(!xmppPort.equalsIgnoreCase(""))
			xmppPorts = Integer.parseInt(xmppPort);
		if(!sipPort.equalsIgnoreCase(""))
			sipPorts = Integer.parseInt(sipPort);
				
		taskRecordsService.updateDNSTaskHistory(taskRecordsService.getReferenceValueForHistory("DOMAIN"), 
			user, ucDomain.getId(), 
			(ucDomain.getVerifyxmppurl() != null && ucDomain.getVerifyxmppurl() == true)?nxpTarget:"", 
			(ucDomain.getVerifyxmppurl() != null && ucDomain.getVerifyxmppurl() == true)?nxpTarget:"",
			srvMessages, sipPorts, xmppPorts, 
			ucDomain.getVerifysipport(), 
			ucDomain.getVerifyxmppport(), new Date());
	}
	*/
	
	/**
	 * For verification checklist process new changes done by 29/09/2016
	 * @param ucDomain
	 * @param userToken
	 * @return
	 * @throws JSONException 
	 */
	public String sipPortVerification(UCDomain ucDomain, String userToken, String portType) throws JSONException {
		String portMessage = "", tcpPort ="", targetName = null;		

		srvVerification(ucDomain, userToken, Lookups.SIP);
		ucDomain = ucDomainRepository.findById(ucDomain.getUcid());	
		SRVRecords srvRecord = sRVRecordsRepository.findByDomainId(ucDomain);
		if(srvRecord != null)
			if(srvRecord.getSipTarget()!= null)
				targetName = srvRecord.getSipTarget();
			else
				targetName = ucDomain.getFqdn();
			
			if(targetName != null) {
				NXPMPReference authorizationKey = nXPMPReferenceRepository.findOneByType(Lookups.AUTHORIZATION);
				String tcpString = getMXLookUps("tcp", targetName, authorizationKey.getLname(), "&port=" + nXPMPReferenceRepository.findByDname(portType).getLname());
				JSONObject tcpJsonObj;
				try {
					tcpJsonObj = new JSONObject(tcpString);
					tcpPort = tcpJsonObj.has("Passed") ? tcpJsonObj.getString("Passed") : "";
				} catch (JSONException e) {
					e.printStackTrace();
				}
				if (tcpPort.contains("TCP Connect")) {
					portMessage = Lookups.PASS;
				} else {
					portMessage = Lookups.FAIL;
				}
			} else
				portMessage = Lookups.FAIL;
		return portMessage;
	}
	

	/**
	 * 
	 * @param ucDomain
	 * @param userToken
	 * @return
	 * @throws JSONException 
	 */
	public String xmppPortVerification(UCDomain ucDomain, String userToken, String portType) throws JSONException {
		String portMessage = "", tcpPort ="", targetName = null;
			
			srvVerification(ucDomain, userToken, Lookups.XMPP);
			ucDomain = ucDomainRepository.findById(ucDomain.getUcid());	
			SRVRecords srvRecord = sRVRecordsRepository.findByDomainId(ucDomain);
			if(srvRecord != null) {
				if(srvRecord.getXmppTarget() != null)
					targetName = srvRecord.getXmppTarget();
			} else {			
				if (ucDomain.getFqdn() == null)
				targetName = ucDomain.getFqdn();	
			}
		
			if(targetName != null) {
				NXPMPReference authorizationKey = nXPMPReferenceRepository.findOneByType(Lookups.AUTHORIZATION);
				String tcpString = getMXLookUps("tcp", targetName, authorizationKey.getLname(), "&port=" + nXPMPReferenceRepository.findByDname(portType).getLname());
				JSONObject tcpJsonObj;
				try {
					tcpJsonObj = new JSONObject(tcpString);
					tcpPort = tcpJsonObj.has("Passed") ? tcpJsonObj.getString("Passed") : "";
				} catch (JSONException e) {
					e.printStackTrace();
				}
				if (tcpPort.contains("TCP Connect")) {
					portMessage = Lookups.PASS;
				} else {
					portMessage = Lookups.FAIL;
				}
			}else
				portMessage = Lookups.FAIL;
		return portMessage;
	}	

	public String srvVerification(UCDomain ucDomain, String userToken, String srvType) throws JSONException {
		String commandSRV = "srv", srvStatus = Lookups.FAIL, domainNameHead = "", strTarget = "", strPort = "";	
		ucDomain = ucDomainRepository.findById(ucDomain.getUcid());		
		if (srvType.equalsIgnoreCase(Lookups.SIP))
			domainNameHead = "_sipfederationtls._tcp.";
		else 
			domainNameHead = "_xmpp-server._tcp.";
			
			NXPMPReference authorizationKey = nXPMPReferenceRepository.findOneByType(Lookups.AUTHORIZATION);
		    String srvUrlResult = getMXLookUps(commandSRV, domainNameHead+ucDomain.getDomainName(), authorizationKey.getLname(), "");
			JSONObject jsonObj;
			try {
				jsonObj = new JSONObject(srvUrlResult);
				String srvDomin = jsonObj.has("Information")?jsonObj.getString("Information"):"";
		    	JSONObject srvJsonObj = new JSONObject(srvUrlResult);		
				String srvError = srvJsonObj.has("Errors")?srvJsonObj.getString("Errors"):"";
			    if(srvError.equalsIgnoreCase("[]")) {
			    	srvStatus = Lookups.PASS;
					SRVRecords srvRecord = sRVRecordsRepository.findByDomainId(ucDomain);
					if(srvRecord == null)
						srvRecord = new SRVRecords();
			    	if(!srvDomin.equalsIgnoreCase("[]")) {
					    srvDomin = srvDomin.replace("[", "");srvDomin = srvDomin.replace("]", "");
						JSONObject jsonObjTarget = new JSONObject(srvDomin);
						strTarget = jsonObjTarget.has("Target") ? jsonObjTarget.getString("Target") : "";
						
						JSONObject jsonObjPort = new JSONObject(srvDomin);
						strPort = jsonObjPort.has("Port") ? jsonObjPort.getString("Port") : "";

						srvRecord.setDomainId(ucDomain);
						if (srvType.equalsIgnoreCase(Lookups.SIP)){
							srvRecord.setSipTarget(strTarget);
							srvRecord.setSipSrvRecord(true);
							srvRecord.setSipSrvPort(strPort);
						}else {
							srvRecord.setXmppTarget(strTarget);
							srvRecord.setXmppSrvRecord(true);
							srvRecord.setXmppSrvPort(strPort);
						}			
						sRVRecordsRepository.save(srvRecord);
					} 
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
		return srvStatus;
	}
	
	public Map<String, String> srvXmppTargetVerification(UCDomain ucDomain, String userToken, String portType) throws JSONException {	
		String srvStatus = Lookups.FAIL;
		String srv = srvVerification(ucDomain, userToken, portType);
		Map<String, String> srvChecking = new HashMap<String, String>();
		if(srv.equalsIgnoreCase(Lookups.PASS)) {
			ucDomain = ucDomainRepository.findById(ucDomain.getUcid());	
			SRVRecords srvRecord = sRVRecordsRepository.findByDomainId(ucDomain);
			if(srvRecord != null)
				if(srvRecord.getXmppTarget() != null && srvRecord.getXmppTarget().equalsIgnoreCase(ucDomain.getFqdn())) {
					srvStatus = Lookups.PASS;
					srvChecking.put("strTarget", srvRecord.getXmppTarget());
				}
				else
					srvChecking.put("strTarget", "");	
		}else{
			srvChecking.put("strTarget", "");	
		}
		srvChecking.put("targetStatus", srvStatus);
		return srvChecking;
	}

	public Map<String, String> srvNxpTargetVerification(UCDomain ucDomain, String userToken, String portType) throws JSONException {	
		String srvStatus = Lookups.FAIL;
		String srv = srvVerification(ucDomain, userToken, portType);
		Map<String, String> srvChecking = new HashMap<String, String>();
		if(srv.equalsIgnoreCase(Lookups.PASS)) {
			ucDomain = ucDomainRepository.findById(ucDomain.getUcid());	
			SRVRecords srvRecord = sRVRecordsRepository.findByDomainId(ucDomain);
			//if(ucDomain.getFqdn() == null) {
				if(srvRecord != null)
					if(srvRecord.getXmppTarget() != null && srvRecord.getXmppTarget().equalsIgnoreCase(nXPMPReferenceRepository.findByDname(Lookups.NXPFS_FQDN).getLname()))
						srvStatus = Lookups.PASS;
			/*}else {
				if(ucDomain.getFqdn().equalsIgnoreCase(srvRecord.getXmppTarget()))
					srvStatus = Lookups.PASS;
			}*/
			srvChecking.put("strTarget", srvRecord.getXmppTarget());
		}else{
			srvChecking.put("strTarget", "");	
		}
		srvChecking.put("targetStatus", srvStatus);		

		return srvChecking;
	}

	public String srvXmppPortVerification(UCDomain ucDomain, String userToken, String portType) throws JSONException {	
		String srvStatus = Lookups.FAIL;
		String srv = srvVerification(ucDomain, userToken, portType);
		if(srv.equalsIgnoreCase(Lookups.PASS)) {
			ucDomain = ucDomainRepository.findById(ucDomain.getUcid());	
			SRVRecords srvRecord = sRVRecordsRepository.findByDomainId(ucDomain);
			if(srvRecord != null && srvRecord.getXmppSrvPort() != null)				
				if(srvRecord.getXmppSrvPort().equalsIgnoreCase(nXPMPReferenceRepository.findByDname(Lookups.XMPP_PORT).getLname()))
					srvStatus = Lookups.PASS;
		}
		return srvStatus;
	}

	public UCDomain verifyDomain(UCDomain ucDomain, String userToken, boolean verify, Long domainId) throws JSONException {
		try {
			String srvMessages = "";
			boolean status = ucDomain.getVerifyDomain();
			ucDomain = ucDomainRepository.findById(ucDomain.getUcid());	
			SRVRecords srvRecord = sRVRecordsRepository.findByDomainId(ucDomain);
			
			User user = userService.getUserFromToken(userToken);
			ucDomain = ucDomainRepository.findById(domainId);
			if(status == true) {
				
				TaskRecords taskRecords = taskRecordsService.updateTasks(ucDomain.getChangeRequestId());
				taskRecordsService.createTask(ucDomain, taskRecords, taskRecords.getPriority()+1);
				
				VerifiedDomain(ucDomain, true, true, true);
				srvMessages = Lookups.VERIFICATION_COMPLETED.replace("$date", taskRecordsService.getDateString(new Date()));
				ucDomainService.sendNotificationForNewDoman(ucDomain,user,EmailContents.DOMAIN_VERIFICATION_COMPLETED,"");
			} else {
				VerifiedDomain(ucDomain, false, false, false);
				srvMessages = Lookups.VERIFICATION_FAILED.replace("$date", taskRecordsService.getDateString(new Date()));					
			}
			
			int sipPorts = 0;
			int xmppPorts = 0;
			String target = "";
			if(srvRecord != null) {
				if(srvRecord.getXmppSrvPort() != null && !srvRecord.getXmppSrvPort().equalsIgnoreCase(""))
					xmppPorts = Integer.parseInt(srvRecord.getXmppSrvPort());
				if(srvRecord.getSipSrvPort() != null && !srvRecord.getSipSrvPort().equalsIgnoreCase(""))
					sipPorts = Integer.parseInt(srvRecord.getSipSrvPort());
				target = srvRecord.getXmppTarget();
			}
					
			taskRecordsService.updateDNSTaskHistory(taskRecordsService.getReferenceValueForHistory("DOMAIN"), 
				user, ucDomain.getId(), 
				ucDomain.getDomainName(), 
				target != null?target:"",
				srvMessages, sipPorts, xmppPorts, 
				status, 
				status, new Date());
			
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return ucDomain;
	}
	
}
package com.nextplane;

import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.nextplane.service.UserService;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class UserControllerTests1 {

	@Autowired
	private UserService userService;
	
	 @Autowired
	  @Qualifier("testDataSource")
	  DataSource testDataSource;
	 
	@Before
	public void preLoad() {
		System.out.println("---- Before ----");
	}
	
	@Test
	public void contextLoads() {
		System.out.println("Hello World!");
		assertNotNull("Hello World!");
	}

	@Test
	public void myName() {
		String x="123";
		System.out.println("Tittu Varghese");
		//assertThat(x.toString(), containsString("World"));
		assertNotNull(x);
	}
	
	@Test
	public void findUser1() {
		long id = 1;
		userService.findUser(id);		
	}
	
	@After
	public void postLoad() {
		System.out.println("---- After ----");
	}
}

package com.nextplane;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.nextplane.NXPMPApplication;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = NXPMPApplication.class)
@WebAppConfiguration
public class NXPMPApplicationTests {

	@Test
	public void contextLoads() {
	}

	

}

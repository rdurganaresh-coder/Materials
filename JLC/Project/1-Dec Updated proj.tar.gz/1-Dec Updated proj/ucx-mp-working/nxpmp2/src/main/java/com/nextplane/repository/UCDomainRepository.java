package com.nextplane.repository;

/**
 * Module       : UCDomain
 * Class    	: UCDomainRepository
 * 
 * Created Date : 01/08/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.nextplane.model.Company;
import com.nextplane.model.UCDomain;

public interface UCDomainRepository extends PagingAndSortingRepository<UCDomain, Long> {

	UCDomain findById(Long id);
	
	UCDomain findByIdAndDomainNameAndEnabled(Long id,String name, Boolean status);
	
	UCDomain findByDomainNameAndEnabled(String name, Boolean status);
	
	UCDomain findByIdAndEnabled(Long id , Boolean status);
	
	Page<UCDomain> findAllByCompanyidAndIsActive(Company company,boolean isActive,Pageable page);
	
	Page<UCDomain> findAllByIsActive(boolean isActive,Pageable page);

	@Query("select dateCreated from UCDomain where id =?1")
	Date getDomainDate(long id);

	List<UCDomain> findByVerificationPendingAndVerification(boolean verificationPending, boolean verification);
	
	List<UCDomain> findByDomainName(String domainName);
    
	Page<UCDomain> findAllByIsActiveAndDomainNameLike( boolean isActive,String domainName,Pageable page);
	
	Page<UCDomain> findAllByCompanyidAndIsActiveAndDomainNameLike(Company company, boolean isActive,String domainName,Pageable page);
	
	UCDomain findByDomainNameAndDeactivateAndIdNot(String name, boolean deactivate, Long id);
	UCDomain findByDomainNameAndDeactivate(String name, boolean deactivate);
	
	UCDomain findByIdAndIsActiveAndRunSelfTest(Long id , Boolean status,Boolean selftest);
	
	@Query("from Company where isDisabled = false and id in (select companyid from UCDomain d where d.isActive = true) and id != ?1")
	List<Company> findAllActiveCompanyWithActiveDomains(Long id);
  	
	@Query("select c from Company c  where c.isDisabled = false and c.id in (select d.companyid from UCDomain d where d.isActive = true) and c.id != ?1")
	Page<Company> findAllActiveCompanyWithActiveDomains(Long id,Pageable page);
	
	@Query("select c from Company c  where c.isDisabled = false and c.id in (select d.companyid from UCDomain d where d.isActive = true) and c.id != ?1 and c.name like ?2")
	Page<Company> searchAllActiveCompanyWithActiveDomains(Long id, String companyName , Pageable page);

	@Query("select count(*) from UCDomain where isActive = true")
	Long getCountOfAllDomains();
	
	@Query("select count(*) from UCDomain where companyid = ?1 and isActive = true")
	Long getCountOfDomains(Company company);	

	@Query("select count(*) from UCDomain where isActive != true")
	Long getDomainCountBadgeUCX();

	@Query("select count(*) from UCDomain where companyid = ?1 and isActive != true")
	Long getDomainCountBadge(Company company);

	List<UCDomain> findByCompanyidAndIsActiveOrderByDomainName(Company company, Boolean isActive);
 }
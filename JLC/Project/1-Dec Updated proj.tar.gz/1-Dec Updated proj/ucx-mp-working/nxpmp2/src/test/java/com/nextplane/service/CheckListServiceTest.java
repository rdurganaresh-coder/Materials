package com.nextplane.service;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.nextplane.model.UCChecklistGroup;

public class CheckListServiceTest {

	@Autowired
	private CheckListService checkListService;
	
	@Test
	public void getCheckList() {
		List <UCChecklistGroup> uCChecklistGroup = checkListService.findByChecklistId(
				Long.parseLong("46"), "svcof.com","sipfederationtls._tcp.accenture.com", 
				Long.parseLong("11"), true);
		//assertNotNull(uCChecklistGroup);
	}
}

package com.nextplane.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;

import com.nextplane.model.Company;
import com.nextplane.model.NXPMPReference;

//import org.springframework.beans.factory.annotation.Autowired;



public class AdministratorServiceTest {


	@Autowired
	private Company company;

	@Autowired
	private AdministratorService _adminservice;
	
	
	

	@Before
	public void createObjects() throws Exception {
		System.out.println("@Before"+company);
		
	}

	
	@Test
	public void getCompany() {
		company = new Company();
	//	company.setId(10);
		company.setName("abc.co");
		System.out.println("@Test");
		System.out.println(company.getId());
		System.out.println(company.getName());
		_adminservice = new AdministratorService();
		Company compDetails =_adminservice.getCompany(company.getName());
		//assertNotNull(compDetails);

	}
	@Test
	public void viewCompany() {
		company = new Company();
	//	company.setId(10);
		company.setName("abc.co");
		System.out.println("@Test");
		System.out.println(company.getId());
		System.out.println(company.getName());
		_adminservice = new AdministratorService();
		Company compDetails =_adminservice.viewCompany(company.getId());
		//assertNotNull(compDetails);

	}
	@Test
	public void searchCompany() {
		company = new Company();
	//	company.setId(10);
		company.setName("abc.co");
		System.out.println("@Test");
		System.out.println(company.getId());
		System.out.println(company.getName());
		_adminservice = new AdministratorService();
		Page<Company> compDetails =_adminservice.searchCompany(company.getName(), null);
		//assertNotNull(compDetails);

	}
	
	@Test
	public void getCompanyTypeUCX() {
		company = new Company();
	//	company.setId(10);
		company.setName("abc.co");
		System.out.println("@Test");
		System.out.println(company.getId());
		System.out.println(company.getName());
		_adminservice = new AdministratorService();
		NXPMPReference nxpmRef =_adminservice.getCompanyTypeUCX();
		//assertNotNull(nxpmRef);

	}
	
	@Test
	public void getServiceAVTestRequirement() {
		company = new Company();
	//	company.setId(10);
		company.setName("abc.co");
		Long serviceId =(long) 10;
		System.out.println("@Test");
		System.out.println(company.getId());
		System.out.println(company.getName());
		_adminservice = new AdministratorService();
		boolean result =_adminservice.getServiceAVTestRequirement(serviceId, company.getId());
		//assertTrue(result);

	}
	
	@After
	public void deleteObjects() throws Exception {
		System.out.println("@After");
	}
	
}
package com.nextplane.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="companyucsvc")
public class Companyucsvc {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@OneToOne
	@JoinColumn(name="companyid")
	private Company companyid;
	
	
	 @OneToOne
	 @JoinColumn(name="serviceId")
	 private UCSVC service;
	 

	 @OneToOne
	 @JoinColumn(name="callVolume")
	 private UCSVCDetails callVolume;

	 private int yahooUsercount;

	Date dateCreated;
	 boolean entitled;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Company getCompany() {
		return companyid;
	}
	public void setCompany(Company company) {
		this.companyid = company;
	}
	public UCSVC getService() {
		return service;
	}
	public void setService(UCSVC service) {
		this.service = service;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public boolean isEntitled() {
		return entitled;
	}
	public void setEntitled(boolean entitled) {
		this.entitled = entitled;
	}
	 
	 
	 public UCSVCDetails getCallVolume() {
		return callVolume;
	}
	public void setCallVolume(UCSVCDetails callVolume) {
		this.callVolume = callVolume;
	}
	public int getYahooUsercount() {
		return yahooUsercount;
	}
	public void setYahooUsercount(int yahooUsercount) {
		this.yahooUsercount = yahooUsercount;
	}

	 
	public Companyucsvc() {
		
	}
	
	public Companyucsvc(Company companyid, UCSVC service, Date dateCreated, boolean entitled,int yahooUsercount,UCSVCDetails callVolume){
		this.companyid = companyid;
		this.service = service;
		this.dateCreated = dateCreated;
		this.entitled = entitled;
		this.yahooUsercount = yahooUsercount;
		this.callVolume = callVolume;
	}

	public String toString(){
		return "Company ucsvc  id"+this.id+" company : "+this.companyid+" service  : "+this.service;
	}
}

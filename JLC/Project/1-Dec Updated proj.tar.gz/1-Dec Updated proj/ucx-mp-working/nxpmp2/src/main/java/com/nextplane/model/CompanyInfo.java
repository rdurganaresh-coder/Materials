package com.nextplane.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "company_info")
public class CompanyInfo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Version
	private long version;
	
	private String additionalContacts;
	private String address;
	private String address1;
	private String city;
	
	@OneToOne
	@JoinColumn(name = "companyid")
	private Company companyid;
	
	
	@OneToOne
	@JoinColumn(name = "companyType")
	private NXPMPReference companyType;
	
	@OneToOne
	@JoinColumn(name = "country")
	private NXPMPReference country;
	
	private Date dateCreated;
	
	private String description;
	private int employeeSize;
	
	private Date lastUpdated;
	
	private String state;
	private String website;
	private String zipcode;
	
	@OneToOne
	@JoinColumn(name = "region")
	private NXPMPReference region;
	
	
	
	public CompanyInfo(){
		
	}
	
	public CompanyInfo(Company companyId, NXPMPReference country,NXPMPReference companyType,NXPMPReference region){
		
		this.companyid = companyId;
		this.country = country;
		this.companyType = companyType;
		this.region = region;
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public String getAdditionalContacts() {
		return additionalContacts;
	}

	public void setAdditionalContacts(String additionalContacts) {
		this.additionalContacts = additionalContacts;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Company getCompanyid() {
		return companyid;
	}

	public void setCompanyid(Company companyId) {
		this.companyid = companyId;
	}

	public NXPMPReference getCompanyType() {
		return companyType;
	}

	public void setCompanyType(NXPMPReference companyType) {
		this.companyType = companyType;
	}

	public NXPMPReference getCountry() {
		return country;
	}

	public void setCountry(NXPMPReference country) {
		this.country = country;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getEmployeeSize() {
		return employeeSize;
	}

	public void setEmployeeSize(int employeeSize) {
		this.employeeSize = employeeSize;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public NXPMPReference getRegion() {
		return region;
	}

	public void setRegion(NXPMPReference region) {
		this.region = region;
	}
	
	
	public String toString(){
		return "Company Info  - id "+this.id+" company : "+this.companyid+"  country : "+this.country;
	}
	
}

package com.nextplane.controllersTest;

import static org.junit.Assert.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.nextplane.controller.UserController;
import com.nextplane.model.ResponseBean;
import com.nextplane.model.User;
import com.nextplane.service.UserService;

public class UCDomainControllerTest {

	private User user = null;

	@Autowired
	private UserController _userController;
	
	

	@Before
	public void createObjects() throws Exception {
		System.out.println("@Before"+user);
		//user.setId(Long.parseLong("1"));
		user= new User();
		user.setId(4);
		user.setEmail("test@test.com");

	}	
	@Test
	public void deleteUser() {
		System.out.println("delete user by id ");
		user= new User();
		user.setId(10);
		user.setEmail("test@test.com");
		System.out.println("@Test");
		System.out.println(user.getId());
		System.out.println(user.getEmail());
		//_userService.findUser(user.getId());
		_userController = new UserController();
		HttpServletRequest request = null;
		HttpServletResponse response = null;
		ResponseBean result=_userController.delete(user, request, response);
		assertNotNull(result);

	}

	
	@Test
	public void findUser() {
		_userController = new UserController();
		System.out.println("find user by id ");
		HttpServletRequest request = null;
		HttpServletResponse response = null;
		ResponseBean result =_userController.findUser(user, request, response);
		System.out.println(user);
		String actual_result = "User Deleted for Id"+user.getId();
		System.out.println("**"+result);
		assertNotNull(result);

	}
	
	
//	@Test
//	public void updateUser() {
//		System.out.println("Update User ");
//		_userService = new UserService();
//		User user =_userService.updateUser(user);
//		System.out.println(user);
//		String actual_result = "User Deleted for Id"+user.getId();
//		if(! (result==actual_result)){
//			result = null;
//		}
//		System.out.println("****"+result);
//		assertNotNull(result);
//
//	}
	
	
	@Test
	public void saveUser() {
		System.out.println("Save user ");
		user= new User();
		_userController = new UserController();
		HttpServletResponse response;
		HttpServletRequest request;
		//ResponseBean user =_userController.save(request, user, response);
		//assertNotNull(result);

	}
	
	
	
	@After
	public void deleteObjects() throws Exception {
		System.out.println("@After");
	}

}

package com.nextplane.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * Module       : Policy management
 * Class        : PolicyList
 * 
 * Created Date : 15/11/2016
 * Created By   : SVCIT NXPMP3
 */

@Entity
@Table(name = "Policy_list")
public class PolicyList {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private String name;
	private String filename;
	private int linesProcessed;
	private int membersAdded;

	@OneToOne
	@JoinColumn(name = "l_type")
	private NXPMPReference lType;
	//DOMAIN(1, "Domain"),
	//USER(2, "User");

	@OneToOne
	@JoinColumn(name = "ownedBy")
	private Company ownedBy;	
	private Date dateCreated;
	private Date lastUpdated;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public int getLinesProcessed() {
		return linesProcessed;
	}
	public void setLinesProcessed(int linesProcessed) {
		this.linesProcessed = linesProcessed;
	}
	public int getMembersAdded() {
		return membersAdded;
	}
	public void setMembersAdded(int membersAdded) {
		this.membersAdded = membersAdded;
	}
	public NXPMPReference getlType() {
		return lType;
	}
	public void setlType(NXPMPReference lType) {
		this.lType = lType;
	}
	public Company getOwnedBy() {
		return ownedBy;
	}
	public void setOwnedBy(Company ownedBy) {
		this.ownedBy = ownedBy;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	
	@Override
	public String toString() {
		return "PolicyList [id=" + id + ", name=" + name + ", filename="
				+ filename + ", linesProcessed=" + linesProcessed
				+ ", membersAdded=" + membersAdded + ", lType=" + lType
				+ ", ownedBy=" + ownedBy + ", dateCreated=" + dateCreated
				+ ", lastUpdated=" + lastUpdated + "]";
	}
}
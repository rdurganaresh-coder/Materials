package com.nextplane.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "uc_base_rule")
public class UCBaseRule {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	private Boolean showSrv;
	private Boolean srvValue;
	private Boolean srvDefault;
	private Boolean showGateway;
	private Boolean gatewayRequired;
	private Boolean openFed;
	private Boolean openFedValue;
	private Boolean rejectProvision;
	
	@OneToOne
	@JoinColumn(name = "message_id")
	private NXPMPReference messageId;

	public String toString() {
		return "UC BaseRule   id: " + this.id;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public boolean isShowSrv() {
		return showSrv;
	}

	public void setShowSrv(Boolean showSrv) {
		this.showSrv = showSrv;
	}

	public Boolean isSrvValue() {
		return srvValue;
	}

	public void setSrvValue(Boolean srvValue) {
		this.srvValue = srvValue;
	}

	public Boolean isSrvDefault() {
		return srvDefault;
	}

	public void setSrvDefault(Boolean srvDefault) {
		this.srvDefault = srvDefault;
	}

	public Boolean isShowGateway() {
		return showGateway;
	}

	public void setShowGateway(Boolean showGateway) {
		this.showGateway = showGateway;
	}

	public Boolean isGatewayRequired() {
		return gatewayRequired;
	}

	public void setGatewayRequired(Boolean gatewayRequired) {
		this.gatewayRequired = gatewayRequired;
	}

	public Boolean isOpenFed() {
		return openFed;
	}

	public void setOpenFed(Boolean openFed) {
		this.openFed = openFed;
	}

	public Boolean isOpenFedValue() {
		return openFedValue;
	}

	public void setOpenFedValue(Boolean openFedValue) {
		this.openFedValue = openFedValue;
	}

	public Boolean isRejectProvision() {
		return rejectProvision;
	}

	public void setRejectProvision(Boolean rejectProvision) {
		this.rejectProvision = rejectProvision;
	}

	public NXPMPReference getMessageId() {
		return messageId;
	}

	public void setMessageId(NXPMPReference messageId) {
		this.messageId = messageId;
	}
}

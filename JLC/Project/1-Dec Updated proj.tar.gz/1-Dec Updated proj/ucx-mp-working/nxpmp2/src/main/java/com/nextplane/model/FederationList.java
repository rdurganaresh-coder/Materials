package com.nextplane.model;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;

public class FederationList {
	
	private Company company ;
	private Long federationPair;
	
	@JsonFormat(pattern= " MM/dd/yyyy")
	private Date fedSince;
	
	private String userToken;
	private Long companyId;	
	private Boolean isPending;	
	private int type;
	
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	public Long getFederationPair() {
		return federationPair;
	}
	public void setFederationPair(Long count) {
		this.federationPair = count;
	}
	public Date getFedSince() {
	
	    return fedSince;
	}
	public void setFedSince(Date fedSince) {
		this.fedSince = fedSince;
	}
	
	public String getUserToken() {
		return userToken;
	}
	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}
	public Long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
	public Boolean getIsPending() {
		return isPending;
	}
	public void setIsPending(Boolean isPending) {
		this.isPending = isPending;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
	public String toString(){
		return "Federation List - Company"+this.company+" Federation pair "+this.federationPair + " fed since "+this.fedSince;
	}
	
	public FederationList(){ }
	
	public FederationList(Company company , Long federationPair , Date fedSince ){
		this.company = company;
		this.federationPair = federationPair;
		this.fedSince = fedSince;
	}
}

package com.nextplane.model;

import javax.ws.rs.FormParam;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Reader;

@XmlRootElement
public class NXPMPFile {

    @FormParam("file")
    private Reader file;

	public Reader getFile() {
		return file;
	}

	public void setFile(Reader file) {
		this.file = file;
	}

	@Override
	public String toString() {
		return "NXPMPFile [file=" + file + "]";
	}

}
 
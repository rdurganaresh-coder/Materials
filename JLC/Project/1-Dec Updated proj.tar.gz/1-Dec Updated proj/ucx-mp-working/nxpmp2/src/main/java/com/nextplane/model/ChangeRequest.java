package com.nextplane.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "change_request")
public class ChangeRequest {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Version
	private Integer version;
	
	private String requestUser;
	
	private String processInstanceId;
	@OneToOne
	@JoinColumn(name="cr_type")
	private NXPMPReference crType;
	
	@OneToOne
	@JoinColumn(name="cr_status")
	private NXPMPReference crStatus;
	
	@OneToOne
	@JoinColumn(name="company")
	private Company company;
	
	@JsonFormat(pattern="MM/dd/yyyy, hh:mm a")
	private Date dateCreated;
	
	@JsonFormat(pattern="MM/dd/yyyy, hh:mm a")
	private Date lastUpdated;
	
	@OneToOne
	@JoinColumn(name="pending_domain_id")
	private UCDomain pendingDomainId;
	
	@OneToOne
	@JoinColumn(name="pending_service_id")
	private UCSVCInstance pendingServiceId;

	public Long getId() {
		return id;
	}

	public Integer getVersion() {
		return version;
	}

	public String getRequestUser() {
		return requestUser;
	}

	public String getProcessInstanceId() {
		return processInstanceId;
	}

	public NXPMPReference getCrType() {
		return crType;
	}

	public NXPMPReference getCrStatus() {
		return crStatus;
	}

	public Company getCompany() {
		return company;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public UCDomain getPendingDomainId() {
		return pendingDomainId;
	}

	public UCSVCInstance getPendingServiceId() {
		return pendingServiceId;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public void setRequestUser(String requestUser) {
		this.requestUser = requestUser;
	}

	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

	public void setCrType(NXPMPReference crType) {
		this.crType = crType;
	}

	public void setCrStatus(NXPMPReference crStatus) {
		this.crStatus = crStatus;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public void setPendingDomainId(UCDomain pendingDomainId) {
		this.pendingDomainId = pendingDomainId;
	}

	public void setPendingServiceId(UCSVCInstance pendingServiceId) {
		this.pendingServiceId = pendingServiceId;
	}
	
	public String toString(){
		return "Change Request   id : "+this.id ;
	}
	
	public ChangeRequest(){
		
	}
	
	public ChangeRequest(String requestUser, NXPMPReference crType, NXPMPReference crStatus, Company company ,Date dateCreated ,UCDomain pendingDomainId ){
		this.requestUser = requestUser;
		this.crType = crType;
		this.crStatus = crStatus;
		this.company = company;
		this.dateCreated = dateCreated;
		this.pendingDomainId = pendingDomainId;
				
	}
	

}
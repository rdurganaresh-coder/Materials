package inheritance;

import java.util.List;

// ── Abstract base ──────────────────────────────────────────────────
abstract class Employee {
    private final String empId;
    private final String name;
    private final String department;

    public Employee(String empId, String name, String department) {
        this.empId      = empId;
        this.name       = name;
        this.department = department;
    }

    public abstract double calculatePay();
    public abstract String getEmployeeType();

    public String getEmpId()      { return empId; }
    public String getName()       { return name; }
    public String getDepartment() { return department; }

    @Override
    public String toString() {
        return String.format("%-15s %-20s %-12s ₹%,.2f",
                getEmployeeType(), name, department, calculatePay());
    }
}

// ── Salaried Employee ──────────────────────────────────────────────
class SalariedEmployee extends Employee {
    private double annualSalary;

    public SalariedEmployee(String id, String name, String dept, double annualSalary) {
        super(id, name, dept);
        this.annualSalary = annualSalary;
    }

    @Override public double calculatePay()     { return annualSalary / 12; }
    @Override public String getEmployeeType()  { return "Salaried"; }
}

// ── Hourly Employee ────────────────────────────────────────────────
class HourlyEmployee extends Employee {
    private double hourlyRate;
    private int    hoursWorked;

    public HourlyEmployee(String id, String name, String dept, double rate, int hours) {
        super(id, name, dept);
        this.hourlyRate  = rate;
        this.hoursWorked = hours;
    }

    @Override
    public double calculatePay() {
        double regular  = Math.min(hoursWorked, 40) * hourlyRate;
        double overtime = Math.max(0, hoursWorked - 40) * hourlyRate * 1.5;
        return regular + overtime;
    }

    @Override public String getEmployeeType() { return "Hourly"; }
}

// ── Commission Employee ────────────────────────────────────────────
class CommissionEmployee extends SalariedEmployee {
    private double commissionRate;
    private double salesAmount;

    public CommissionEmployee(String id, String name, String dept,
                               double baseSalary, double commRate, double sales) {
        super(id, name, dept, baseSalary);
        this.commissionRate = commRate;
        this.salesAmount    = sales;
    }

    @Override
    public double calculatePay() {
        return super.calculatePay() + (commissionRate * salesAmount);
    }

    @Override public String getEmployeeType() { return "Commission"; }
}

// ── Payroll ────────────────────────────────────────────────────────
public class Payroll {
    public static void main(String[] args) {
        List<Employee> employees = List.of(
            new SalariedEmployee("E001", "Alice Sharma",  "Engineering", 1_200_000),
            new SalariedEmployee("E002", "Bob Kumar",     "HR",           900_000),
            new HourlyEmployee  ("E003", "Carol Singh",   "Support",  500, 45),
            new CommissionEmployee("E004", "Dave Patel",  "Sales", 600_000, 0.05, 800_000)
        );

        System.out.println("═".repeat(65));
        System.out.printf("%-15s %-20s %-12s %s%n", "Type", "Name", "Department", "Monthly Pay");
        System.out.println("─".repeat(65));

        // POLYMORPHISM — each calculatePay() dispatched to correct type at runtime
        employees.forEach(System.out::println);

        double total = employees.stream().mapToDouble(Employee::calculatePay).sum();
        System.out.println("─".repeat(65));
        System.out.printf("%-48s ₹%,.2f%n", "TOTAL PAYROLL", total);
        System.out.println("═".repeat(65));
    }
}

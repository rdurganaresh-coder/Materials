package com.nextplane.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.Company;
import com.nextplane.model.Companyucsvc;

public interface CompanyucsvcRepository  extends CrudRepository<Companyucsvc, Long>{

  void	deleteAllByCompanyid(Company id);
  
  List<Companyucsvc> findByCompanyid(Company company);
}
package com.nextplane;
import java.util.Comparator;

import com.nextplane.model.UCChecklists;

public class NXPMPComparator implements Comparator<UCChecklists> {
	@Override
	public int compare(UCChecklists tv1, UCChecklists tv2) {
		Long tv1Size = tv1.getId();
		Long tv2Size = tv2.getId();
 
		if (tv1Size > tv2Size) {
			return 1;
		} else if (tv1Size < tv2Size) {
			return -1;
		} else {
			return 0;
		}
	}
}
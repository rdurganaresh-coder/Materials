package com.nextplane.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "ucsvc")
public class UCSVC {
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getVersion() {
		return version;
	}
	public void setVersion(long version) {
		this.version = version;
	}
	public boolean isBot() {
		return bot;
	}
	public void setBot(boolean bot) {
		this.bot = bot;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public String getDefaultAddress() {
		return defaultAddress;
	}
	public void setDefaultAddress(String defaultAddress) {
		this.defaultAddress = defaultAddress;
	}
	public String getDefaultDomain() {
		return defaultDomain;
	}
	public void setDefaultDomain(String defaultDomain) {
		this.defaultDomain = defaultDomain;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFormFields() {
		return formFields;
	}
	public void setFormFields(String formFields) {
		this.formFields = formFields;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public int getUcServiceType() {
		return ucServiceType;
	}
	public void setUcServiceType(int ucServiceType) {
		this.ucServiceType = ucServiceType;
	}
	public boolean isRequiresProvision() {
		return requiresProvision;
	}
	public void setRequiresProvision(boolean requiresProvision) {
		this.requiresProvision = requiresProvision;
	}
	public boolean isEnabled() {
		return isEnabled;
	}
	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	public String getReportingDomains() {
		return reportingDomains;
	}
	public void setReportingDomains(String reportingDomains) {
		this.reportingDomains = reportingDomains;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Version
	private long version;
	
	private boolean bot;
	private Date dateCreated;
	private String defaultAddress;
	private String defaultDomain;
	private String description;
	private String formFields;
	private String name;
	private Date lastUpdated;
	private int ucServiceType;
	private boolean requiresProvision;
	private boolean isEnabled;
	private String reportingDomains;
	
	
	public UCSVC(){
		
	}


	public String toString(){
		return " UCSVC - id : "+this.id +" name   : "+this.name;
	}
}

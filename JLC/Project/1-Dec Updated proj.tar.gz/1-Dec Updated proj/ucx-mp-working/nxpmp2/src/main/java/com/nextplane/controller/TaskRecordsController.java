package com.nextplane.controller;

/**
 * Module       : Task management
 * Class        : Task Controller
 * 
 * Created Date : 27/07/2016
 * Created By   : SVCIT NXPMP3
 */

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nextplane.CommonUtils;
import com.nextplane.Constants.ResponseStatus;
import com.nextplane.Constants.TasksResponseMessage;
import com.nextplane.model.PageableNxp;
import com.nextplane.model.ResponseBean;
import com.nextplane.model.TaskRecords;
import com.nextplane.service.TaskRecordsService;

@Controller
@RequestMapping(value = "/taskRecords")
public class TaskRecordsController {

	private static final Logger LOG = LoggerFactory.getLogger(TaskRecordsController.class);
	
	@Autowired
	TaskRecordsService tRecordsService;
	
	/**
	 * 
	 * @param task
	 * @return
	 */
	@RequestMapping(value = "/create",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean createTask(@RequestBody TaskRecords taskRecords){
		try {
			//tRecordsService.createTask(taskRecords);
		} catch (Exception ex) {
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, TasksResponseMessage.ERROR_TASK_CREATE);
		}
		LOG.info(TasksResponseMessage.TASK_CREATED);
		return CommonUtils.getResponseBean(taskRecords, TasksResponseMessage.TASK_CREATED);
	}	

	/**
	 * 
	 * @param pageable
	 * @return
	 */
	@RequestMapping(value = "/list",method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public Page<TaskRecords> list(Pageable pageable) {		
		return tRecordsService.list(pageable);
	}
	
	/**
	 * 
	 * @param pageableTask
	 * @return
	 */
	@RequestMapping(value = "/pendingTasks",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean getPendingTask(@RequestBody PageableNxp pageableTask) {
		pageableTask.setPageable();		
		Page<TaskRecords> pendingTask = tRecordsService.findByTaskStatus(pageableTask);
		if(pendingTask != null)
			return CommonUtils.getResponseBean(pendingTask, TasksResponseMessage.LIST_PENDING_TASK);
		else
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, TasksResponseMessage.NO_PENDING_TASK);		
	}
	

	/**
	 * 
	 * @param taskRecordId
	 * @return
	 */
	@RequestMapping(value = "/updateTasks",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean updateTasks(@RequestBody long taskRecordId) {
		tRecordsService.updateTasks(taskRecordId);
		if(taskRecordId != 0)
			return CommonUtils.getResponseBean(taskRecordId, TasksResponseMessage.TASK_UPDATED);
		else
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, TasksResponseMessage.NO_PENDING_TASK);		
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/getTasks",method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean getTask(@RequestBody long id) {
		return CommonUtils.getResponseBean(tRecordsService.findById(id), TasksResponseMessage.GET_TASKS);
	}
}

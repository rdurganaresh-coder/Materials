package com.nextplane.utils;

import java.util.ArrayList;
import java.util.List;


public class ValidationUtil {

	
	
public static List<String> checkValues(String name, Object membershipType, Object contractType){
	List<String> nullValues = new ArrayList<String>();

	
	
	if(name == null || name.isEmpty())
		nullValues.add("Company name : "+name );
	if(membershipType == null)
		nullValues.add("membershiptype :"+membershipType);
	if(contractType == null)
		nullValues.add("contract type : "+contractType);
	
	return nullValues;
}
	
}

package com.nextplane.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "runselftest_instance")
public class Runselftest_instance {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private Long ucdomain;
	
	private boolean addToContactList;
	
	private boolean confirmAvailable;
	 
	private boolean sendHello;
	
	private boolean comfirmResponse;

	@Transient
	private String userToken;
	
	public Long getId() {
		return id;
	}

	public Long getUcdomain() {
		return ucdomain;
	}

	public boolean isAddToContactList() {
		return addToContactList;
	}

	public boolean isConfirmAvailable() {
		return confirmAvailable;
	}

	public boolean isSendHello() {
		return sendHello;
	}

	public boolean isComfirmResponse() {
		return comfirmResponse;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setUcdomain(Long ucdomain) {
		this.ucdomain = ucdomain;
	}

	public void setAddToContactList(boolean addToContactList) {
		this.addToContactList = addToContactList;
	}

	public void setConfirmAvailable(boolean confirmAvailable) {
		this.confirmAvailable = confirmAvailable;
	}

	public void setSendHello(boolean sendHello) {
		this.sendHello = sendHello;
	}

	public void setComfirmResponse(boolean comfirmResponse) {
		this.comfirmResponse = comfirmResponse;
	}

	public String getUserToken() {
		return userToken;
	}

	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}

	public Runselftest_instance(){
		
	}
	
	public Runselftest_instance(Long domain, boolean addToContactList ,
			boolean confirmAvailable ,boolean sendHello,boolean comfirmResponse ){
		this.setUcdomain(domain);
		this.setAddToContactList(addToContactList);
		this.setConfirmAvailable(confirmAvailable);
		this.setSendHello(sendHello);
		this.setComfirmResponse(comfirmResponse);
	}
	
}

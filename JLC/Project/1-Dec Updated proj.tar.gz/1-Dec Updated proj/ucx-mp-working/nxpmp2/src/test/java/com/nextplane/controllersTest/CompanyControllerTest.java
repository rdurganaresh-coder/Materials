package com.nextplane.controllersTest;

import static org.junit.Assert.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.nextplane.controller.AdminController;
import com.nextplane.model.*;

public class CompanyControllerTest {

	private Company company = null;

	@Autowired
	private AdminController _adminController;

	@Before
	public void createObjects() throws Exception {
		// System.out.println("@Before"+company);
		// user.setId(Long.parseLong("1"));
		company = new Company();
		//company.setId(4);
		company.setName("test@test.com");
	}

	@Test
	public void searchCompany() {
		System.out.println("delete user by id ");
		company = new Company();
	//	company.setId(1);
		company.setName("test@test.com");
		System.out.println("@Test");
		// System.out.println(company.getId());
		// System.out.println(company.getName());
		// _userService.findUser(user.getId());
		_adminController = new AdminController();
		System.out.println("@Test1");
		HttpServletRequest request = null;
		HttpServletResponse response = null;
		ResponseBean result = _adminController.searchCompany(request);
		assertNotNull(result);

	}

	@Test
	public void viewCompany() {
		_adminController = new AdminController();
		System.out.println("find user by id ");
		HttpServletRequest request = null;
		HttpServletResponse response = null;
		ResponseBean result = _adminController.viewCompany(request);
		System.out.println(company);
		// String actual_result = "User Deleted for Id"+company.getId();
		assertNotNull(result);

	}

	@Test
	public void save() {
		System.out.println("save ");
		_adminController = new AdminController();
		HttpServletRequest request = null;
		HttpServletResponse response = null;
		ResponseBean result = _adminController.save(request, response);
		System.out.println(result);
		assertNotNull(result);

	}

	@After
	public void deleteObjects() throws Exception {
		System.out.println("@After");
	}

}

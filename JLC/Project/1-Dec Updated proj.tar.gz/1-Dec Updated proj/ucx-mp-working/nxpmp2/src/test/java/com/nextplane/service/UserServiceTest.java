package com.nextplane.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
/*import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;*/
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
/*import org.springframework.test.context.junit4.SpringRunner;*/

import com.nextplane.controller.UserController;
import com.nextplane.model.Company;
import com.nextplane.model.User;
import com.nextplane.repository.UserRepository;
import com.nextplane.repository.UserRoleMappingRepository;

/*@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc*/
public class UserServiceTest extends TestCase {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserController userController;

	@Autowired 
	UserRoleMappingRepository userRoleMappingRepository;

	User user = null;
	User newUser = null;

	Logger LOGGER = LogManager.getLogger(UserServiceTest.class);
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("@BeforeClass : setUpBeforeClass");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("@AfterClass : tearDownAfterClass");
	}

	@Before
	public void setUp() throws Exception {
		user = new User();
		user.setEmail("nextplane@svcloudit.com");
		user.setFirstname("NextPlane");
		user.setLastname("A");
		user.setPassword("test");
		user.setUsername("nextplane@svcloudit.com");
		user.setEnabled(true);
		user.setTokenTime(new Date());

		List<String> roles = new ArrayList<String>();
		roles.add(""+267);		
		user.setRoleIds(roles);
		
		user = userRepository.save(user);
		LOGGER.info("User SetUp Completed");
	}

	@After
	public void tearDown() throws Exception {
		userRoleMappingRepository.deleteAll();
		userRepository.deleteAll();
		LOGGER.info("Object Destroyed");
		System.out.println("--> Destroyed <--");
	}

	@Test
	public void testSaveUsers() {
		
		newUser = new User();
		newUser.setEmail("nextplaneOne@svcloudit.com");
		newUser.setFirstname("NextPlane");
		newUser.setLastname("One");
		newUser.setPassword("test");
		newUser.setUsername("nextplaneOne@svcloudit.com");
		newUser.setEnabled(true);
		newUser.setTokenTime(new Date());
		newUser.setCompanyId(new Company((long) 1));
		
		List<String> roles = new ArrayList<String>();
		roles.add(""+267);		
		newUser.setRoleIds(roles);		
		
		newUser = userService.saveUser(newUser);
		System.out.println("In Save User : " + newUser.toString());
		assertNotNull(newUser);
		assertEquals("nextplaneOne@svcloudit.com", newUser.getEmail());
		LOGGER.info("User Created");
	}
	
	@Test
	public void testFindUserSuccess() {
		user.setEmail("nextplane@svcloudit.com");
		User users = userService.findUser(user.getEmail());
		assertNotNull(users);
		assertEquals(user.getEmail(), users.getEmail());
		LOGGER.info("Find User");
	}

	@Test
	public void testFindUserFailure() {
		String email = "next@svcloudit.com";
		User users = userService.findUser(email);
		assertNull(users);
		LOGGER.info("Find Invalid User Failure");
	}

	@Test
	public void testFindUserByNameSuccess() {
		Pageable page = new PageRequest(0, 1);
		Page<User> userList = userService.findUserByName(user.getFirstname(), page);
		assertNotNull(userList);
		LOGGER.info("Find User By Name Success");
			
	}

	@Test
	public void testFindUserByNameFailure() {
		String name = "@x123@Cas";
		Pageable page = new PageRequest(0, 1);
		Page<User> userList = userService.findUserByName(name, page);
		assertEquals(userList.getContent().size(), 0);
		LOGGER.info("Find User By Name Failure");
	}

	@Test
	public void testViewSuccess() {
		PageRequest pageable = new PageRequest(0, 1);
		Page<User> users = userService.view(pageable);
		assertNotNull(users);
		LOGGER.info("View Success");
	}
	
	@Test
	public void testDeleteUserSuccess(){
		String response = userService.deleteUser(user.getId());
		assertNotNull(response);
		LOGGER.info("Delete User Success");		
	}
	
	@Test
	public void testFilterByCompanySuccess() {
		List<User> userlist = userService.filterByCompany(new Company((long) 1));
		assertNotNull(userlist);
		LOGGER.info("Filter By Company Success");
	}

	@Test
	public void testFilterByCompanyFailure() {
		List<User> userlist = userService.filterByCompany(new Company((long) 2));
		assertEquals(userlist.size(), 0);
		LOGGER.info("Filter By Company Failure");
	}	
}

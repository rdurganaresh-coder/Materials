package basics;

/**
 * Demonstrates: Classes, Objects, Constructors, this keyword, static members
 */
public class BankAccount {

    // Static field — shared across all instances
    private static int nextAccountId = 1000;
    private static int totalAccounts = 0;

    // Instance fields
    private final String accountNumber;
    private final String owner;
    private double balance;

    // Default constructor
    public BankAccount() {
        this("Unknown", 0.0);
    }

    // Parameterized constructor
    public BankAccount(String owner, double initialBalance) {
        this.accountNumber = "ACC-" + (nextAccountId++);
        this.owner         = owner;
        this.balance       = initialBalance;
        totalAccounts++;
    }

    // Copy constructor
    public BankAccount(BankAccount other) {
        this.accountNumber = "ACC-" + (nextAccountId++); // new account number
        this.owner         = other.owner;
        this.balance       = other.balance;
        totalAccounts++;
    }

    // Instance methods
    public void deposit(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
        balance += amount;
        System.out.printf("Deposited ₹%.2f → Balance: ₹%.2f%n", amount, balance);
    }

    public void withdraw(double amount) {
        if (amount <= 0)     throw new IllegalArgumentException("Amount must be positive");
        if (amount > balance) throw new IllegalStateException("Insufficient funds");
        balance -= amount;
        System.out.printf("Withdrew ₹%.2f → Balance: ₹%.2f%n", amount, balance);
    }

    // Fluent method — returns 'this' for chaining
    public BankAccount addInterest(double rate) {
        balance += balance * rate;
        return this;
    }

    // Static method
    public static int getTotalAccounts() { return totalAccounts; }

    // Getters
    public String getAccountNumber() { return accountNumber; }
    public String getOwner()         { return owner; }
    public double getBalance()       { return balance; }

    @Override
    public String toString() {
        return String.format("BankAccount{%s, owner='%s', balance=₹%.2f}",
                accountNumber, owner, balance);
    }

    // Entry point
    public static void main(String[] args) {
        BankAccount acc1 = new BankAccount("Alice", 5000);
        BankAccount acc2 = new BankAccount("Bob", 2000);
        BankAccount acc3 = new BankAccount(acc1); // copy

        acc1.deposit(1000);
        acc1.withdraw(500);
        acc1.addInterest(0.05).deposit(200); // method chaining

        System.out.println(acc1);
        System.out.println(acc2);
        System.out.println(acc3);
        System.out.println("Total accounts: " + BankAccount.getTotalAccounts());
    }
}

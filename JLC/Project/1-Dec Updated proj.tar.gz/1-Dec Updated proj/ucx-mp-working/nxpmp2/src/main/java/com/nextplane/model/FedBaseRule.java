package com.nextplane.model;

/**
 * Module       : Fed Base Rules management
 * Table		: fed_base_rules
 * Class        : FedBaseRule
 * 
 * Created Date : 20/09/2016
 * Created By   : SVCIT NXPMP3
 */

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "fed_base_rules")
public class FedBaseRule {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String fedRuleId;
	
	private String senderProtocol;
	private Boolean senderOpenFed;
	private long senderUcType;
	private String senderChecklist;

	private String receiverProtocol;
	private Boolean receiverOpenFed;
	private long receiverUcType;
	private String receiverChecklist;
	
	@OneToOne
	@JoinColumn(name = "message_id")
	private Messages errorMsg;
	private Boolean generateError;	
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFedRuleId() {
		return fedRuleId;
	}

	public void setFedRuleId(String fedRuleId) {
		this.fedRuleId = fedRuleId;
	}

	public String getSenderProtocol() {
		return senderProtocol;
	}

	public void setSenderProtocol(String senderProtocol) {
		this.senderProtocol = senderProtocol;
	}

	public Boolean getSenderOpenFed() {
		return senderOpenFed;
	}

	public void setSenderOpenFed(Boolean senderOpenFed) {
		this.senderOpenFed = senderOpenFed;
	}

	public long getSenderUcType() {
		return senderUcType;
	}

	public void setSenderUcType(long senderUcType) {
		this.senderUcType = senderUcType;
	}
	
	public String getSenderChecklist() {
		return senderChecklist;
	}

	public void setSenderChecklist(String senderChecklist) {
		this.senderChecklist = senderChecklist;
	}

	public String getReceiverProtocol() {
		return receiverProtocol;
	}

	public void setReceiverProtocol(String receiverProtocol) {
		this.receiverProtocol = receiverProtocol;
	}

	public Boolean getReceiverOpenFed() {
		return receiverOpenFed;
	}

	public void setReceiverOpenFed(Boolean receiverOpenFed) {
		this.receiverOpenFed = receiverOpenFed;
	}

	public long getReceiverUcType() {
		return receiverUcType;
	}

	public void setReceiverUcType(long receiverUcType) {
		this.receiverUcType = receiverUcType;
	}

	public String getReceiverChecklist() {
		return receiverChecklist;
	}

	public void setReceiverChecklist(String receiverChecklist) {
		this.receiverChecklist = receiverChecklist;
	}

	public Boolean getGenerateError() {
		return generateError;
	}

	public void setGenerateError(Boolean generateError) {
		this.generateError = generateError;
	}

	public Messages getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(Messages errorMsg) {
		this.errorMsg = errorMsg;
	}

	@Override
	public String toString() {
		return "FedBaseRule [id=" + id + ", fedRuleId=" + fedRuleId
				+ ", senderProtocol=" + senderProtocol + ", senderOpenFed="
				+ senderOpenFed + ", senderUcType=" + senderUcType
				+ ", senderChecklist=" + senderChecklist
				+ ", receiverProtocol=" + receiverProtocol
				+ ", receiverOpenFed=" + receiverOpenFed + ", receiverUcType="
				+ receiverUcType + ", receiverChecklist=" + receiverChecklist
				+ ", errorMsg=" + errorMsg + ", generateError=" + generateError
				+ "]";
	}

}

package com.nextplane.model;

/**
 * Module       : Fed Check List Group management
 * Table		: fed_checklist_group
 * Class        : FedCheckListGroup
 * 
 * Created Date : 20/09/2016
 * Created By   : SVCIT NXPMP3
 */

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "fed_checklist_group")
public class FedCheckListGroup {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@OneToOne
	@JoinColumn(name = "fedChecklistId")
	private UCChecklists fedChecklistId;
	private String groupType;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public UCChecklists getFedChecklistId() {
		return fedChecklistId;
	}

	public void setFedChecklistId(UCChecklists fedChecklistId) {
		this.fedChecklistId = fedChecklistId;
	}

	public String getGroupType() {
		return groupType;
	}

	public void setGroupType(String groupType) {
		this.groupType = groupType;
	}

	public String toString() {
		return "UCChecklistGroup - id" + this.id;
	}
}

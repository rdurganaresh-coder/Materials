package com.nextplane.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.beans.factory.annotation.Autowired;

import com.nextplane.Constants.Policy;
import com.nextplane.model.HashingMember;
import com.nextplane.model.Member;
import com.nextplane.model.NXPMPReference;
import com.nextplane.model.User;
import com.nextplane.repository.HashingMemberRepository;
import com.nextplane.repository.MemberRepository;
import com.nextplane.repository.NXPMPReferenceRepository;

/**
 * Module       : Policy management
 * Class        : PolicyService
 * 
 * Created Date : 14/11/2016
 * Created By   : SVCIT NXPMP3
 */

@Service
public class PolicyService {

	@Autowired
	private NXPMPService nXPMPService;
	
	@Autowired
	private MemberRepository memberRepository;
	
	@Autowired
	private HashingMemberRepository hashingMemberRepository;
	
	@Autowired
	private NXPMPReferenceRepository nXPMPReferenceRepository;

	@Autowired
	private FileManagementService fileManagementService;

	@Autowired
	private UserService userService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PolicyService.class);	

	/**
	 * 
	 * @param userToken
	 * @param file
	 * @param processId
	 * @return
	 * @throws IOException
	 */
	public HashingMember gethashMembers(String userToken, MultipartFile file, Long processId) throws IOException {
		User user = userService.getUserFromToken(userToken);		
		HashingMember HashingMember = new HashingMember();
		if(user != null) {
			String fileName = fileManagementService.uploadFileHandler(user.getCompanyId().toString(), String.valueOf(user.getId()), file);
			List<String> members = fileManagementService.readFileHandler(fileName);
	
			if(processId == null) {
				NXPMPReference newProcessId = nXPMPReferenceRepository.findOneByType(Policy.PROCESS_ID);
				newProcessId.setVersion(newProcessId.getVersion()+1);
				nXPMPReferenceRepository.save(newProcessId);
				processId = newProcessId.getVersion();
			}		
			
			List<String> invalidMembers = saveHashGetMembers(members, processId);
			HashingMember.setProcessId(processId);
			HashingMember.setListMembers(invalidMembers);
		}
		return HashingMember;
	}
	
	/**
	 * 
	 * @param newHashingMember
	 * @return
	 */
	public List<String> saveHashMembers(HashingMember newHashingMember) {		
		return saveHashGetMembers(newHashingMember.getListMembers(), newHashingMember.getProcessId());
	}

	/**
	 * 
	 * @param listMembers
	 * @param processId
	 * @return
	 */
	public List<String> saveHashGetMembers(List<String> listMembers, Long processId) {		
		List<String> invalidMembers = new ArrayList<String>();
		List<String> validMembers = hashingMemberRepository.getAllByprocessId(processId);
		String emailId = "", lastName = "", firstName = "";
		for (Iterator<String> iterator = listMembers.iterator(); iterator.hasNext();) {
			String currentMember = (String) iterator.next();
			emailId = ""; lastName = ""; firstName = "";
			if (currentMember != null) {
				String retval[] = currentMember.split(",");				
				firstName = retval[0];
				lastName  = retval[1];
				emailId = retval[2];
				Boolean validateEmail = nXPMPService.isValidEmail(emailId);
				HashingMember hashingMember = null;
				if (validateEmail == true && !firstName.equalsIgnoreCase("") && !lastName.equalsIgnoreCase("")) {
					hashingMember = new HashingMember(firstName, lastName, emailId, processId);
					if(!validMembers.contains(emailId))
						hashingMemberRepository.save(hashingMember);
					validMembers.add(emailId);
				} else
					invalidMembers.add(currentMember+","+validateEmail);
			}
		}
		return invalidMembers;
		
	}

	/**
	 * 
	 * @param processId
	 * @return
	 */
	public Boolean saveMembers(Long processId) {
		List<HashingMember> validMembers = hashingMemberRepository.findByProcessId(processId);		
		for (Iterator<HashingMember> iterator = validMembers.iterator(); iterator.hasNext();) {
			HashingMember hashingMember = (HashingMember) iterator.next();
			Member member = new Member(hashingMember.getFirstName(), hashingMember.getLastName(), hashingMember.getEmailId());
			memberRepository.save(member);
		}		
		Boolean flag = false;
		if(hashingMemberRepository.deleteByProcessId(processId) == 1)
			flag = true;
		return flag;
	}
}
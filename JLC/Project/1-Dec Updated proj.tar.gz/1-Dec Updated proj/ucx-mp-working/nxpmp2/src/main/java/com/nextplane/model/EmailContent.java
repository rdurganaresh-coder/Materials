package com.nextplane.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name="email_content")
public class EmailContent {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	@Version
	private int version;
	
	@OneToOne
	@JoinColumn(name="decisionStatus")
	NXPMPReference decisionStatus;
	
	private String subject;
	private String subjectName;
	private String content;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public NXPMPReference getDecisionStatus() {
		return decisionStatus;
	}
	public void setDecisionStatus(NXPMPReference decisionStatus) {
		this.decisionStatus = decisionStatus;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	
	public EmailContent(){
		
	}
	
	
	public String tosString(){
		return "Email Content "+this.subject;
	}
}

package com.nextplane.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="ucsvc_instance")
public class UCSVCInstance {

	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private long id;
	
	private String address;
	private String botDomain;
	
	//need to change to fK of Change Request 
	private long changeRequestId;
	
	@OneToOne
	@JoinColumn(name ="companyId")
	private Company companyId;
	
	private Date dateCreated;
	
	//need to change to fK of Doamin
	private long domainId;
	
	private Date lastUpdated;
	
	@OneToOne
	@JoinColumn(name = "serviceId")
	private UCSVC serviceId;
	
	@OneToOne
	@JoinColumn(name="status")
	private NXPMPReference status;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBotDomain() {
		return botDomain;
	}

	public void setBotDomain(String botDomain) {
		this.botDomain = botDomain;
	}

	public long getChangeRequestId() {
		return changeRequestId;
	}

	public void setChangeRequestId(long changeRequestId) {
		this.changeRequestId = changeRequestId;
	}

	public Company getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Company companyId) {
		this.companyId = companyId;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public long getDomainId() {
		return domainId;
	}

	public void setDomainId(long domainId) {
		this.domainId = domainId;
	}



	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public UCSVC getServiceId() {
		return serviceId;
	}

	public void setServiceId(UCSVC serviceId) {
		this.serviceId = serviceId;
	}

	public NXPMPReference getStatus() {
		return status;
	}

	public void setStatus(NXPMPReference status) {
		this.status = status;
	}
	
	public UCSVCInstance(){
		
	}
	
	public UCSVCInstance ( Company company , UCSVC service , NXPMPReference status , Date dateCreated, Date lastUpdated ){
		this.companyId = company;
		this.serviceId = service;
		this.status = status;
		this.dateCreated = dateCreated;
		this.lastUpdated = lastUpdated;
	}
}
package com.nextplane.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.tools.ant.types.CommandlineJava.SysProperties;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nextplane.CommonUtils;
import com.nextplane.Constants.ResponseMessage;
import com.nextplane.Constants.ResponseStatus;
import com.nextplane.model.Company;
import com.nextplane.model.ResponseBean;
import com.nextplane.repository.NXPMPReferenceRepository;
import com.nextplane.service.AdministratorService;
import com.nextplane.service.UserService;

@Controller
//@CrossOrigin(origins = "/**")
@RequestMapping(value = "/company")
public class AdminController {

	@Autowired
	AdministratorService adminService;

	@Autowired
	private NXPMPReferenceRepository ssprepo;
	
	@Autowired
	private UserService userService;
	
	@Value("${roles.3}")
	private String ROLE_SUPER_ADMIN;
	
	@Value("${page}")
	private String PAGE;
	@Value("${limit}")
	private String LIMIT;
	@Value("${direction}")
	private String DIRECTION;
	

	private static final Logger logger = LogManager.getLogger(AdminController.class);

	
	/**
	 * Returns the Country , Region, membershipType , ContractType, Entitlements , Sponsers
	 * @returns : ResponseBean  
	 * */
     @RequestMapping(path = "/create",method = RequestMethod.GET,produces = "application/json")
    // @CrossOrigin(origins = "/**")
	 @ResponseBody
	 public ResponseBean createCompany(HttpServletRequest request,HttpServletResponse response){
     
  		/* JsonObject error;*/
  		 JSONObject jsonObject = null; 
  		 HashMap<String, Object> companyRef = null;
	 	 try{
	 		 // get the json object from the request
	 		 jsonObject = adminService.getJsonInputFromRequest(request);
	 		 //get the company references
	 		 companyRef = adminService.getReferencesForAddCompany();
	 		 if(companyRef == null){
	 			  logger.info(ResponseMessage.ERROR_COMPANY_LOADREF);
				   return CommonUtils.getResponseBean(companyRef, ResponseMessage.ERROR_COMPANY_LOADREF);

	 		 }else{
				   logger.info(ResponseMessage.COMPANY_LOADREF);
				   return CommonUtils.getResponseBean(companyRef, ResponseMessage.COMPANY_LOADREF);

	 		 }

	 	 } catch (Exception e) {
	 		if(e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)){
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ERROR_NOT_ADMIN);			

			}else if(e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_EMPTY)){
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_EMPTY);			

			}else if(e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)){
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_INVALID);			

			}else {
  			// writing exception to log
	 		logger.error(ResponseMessage.ERROR_COMPANY_LOADREF);
			return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_COMPANY_LOADREF);			

			}

		 } 


	 }
	 
     /**
      * Saves the company information invoking the saveCompany api in adminService
      * @returns ResponseBean
      * */

	@RequestMapping(path = "/save",method = RequestMethod.POST,produces = "application/json")
	@ResponseBody	
	public ResponseBean save(HttpServletRequest request ,HttpServletResponse response){

	
		Company company=null;
		 JSONObject jsonObject = null; 
		 HashMap<String, Object> companyInput = new HashMap<String, Object>();
	 	 try{
	 		 // Get the jsonobject
	 		 jsonObject = adminService.getJsonInputFromRequest(request);
             //Get the userToke to validate the user
	 		 String userToken = jsonObject.has("userToken")?jsonObject.getString("userToken"):"";
             //Get the corresponding input from the JSONObject
	         companyInput = adminService.getInputFromJson(jsonObject,false);
	         if(userToken == null || (userToken !=null && userToken.equals(""))){
	        	   throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
	           }else if(!userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)){
	        	   throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
		   		}else if(!userService.checkAdminToken(userToken)){
	        	   throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
		   		}
	         // update the token time .. 
	         userService.updateAdminTokenTime(userToken);
	         //throw exceptoion if company input  is null
	         	if(companyInput.get("company") == null){
	        	   throw new Exception(ResponseMessage.ERROR_COMPANY_CREATE_INVALID_DATA);
	           }
	         	else{
	         		 company = adminService.saveCompany(companyInput);
	 	        	// Exception if company is null
		        	   if(company.getName().equalsIgnoreCase("")){
		        		   logger.error(ResponseMessage.ERROR_COMPANY);		        		
		        		   throw new Exception(ResponseMessage.ERROR_COMPANY);
		        	   }//throw exception if company exists
		        	   else if(company.isCompanyExists() != null && company.isCompanyExists()){
		        		   throw new Exception(ResponseMessage.ERROR_COMPANY_EXISTS);
		        	   }//throw exception if not company status is true
		        	   else if(!company.isCompanyStatus()){
		        		 
		        		   throw new Exception(ResponseMessage.ERROR_COMPANY);
		        	   }else{
		        		   // sucessfully saved comapny
			        	   logger.info(ResponseMessage.COMPANY_CREATE);
			   			return CommonUtils.getResponseBean(ResponseStatus.SUCCESS, ResponseMessage.COMPANY_CREATE);			

		        	   }
	         		
	         	}
	           //}

		} catch (Exception e) {
			logger.error("ERROR :  "+e.getMessage()+company);
			if(e.getMessage().contains(ResponseMessage.ERROR_COMPANY_CREATE_INVALID_DATA)){
				logger.error(ResponseMessage.ERROR_COMPANY_CREATE_INVALID_DATA);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_COMPANY_CREATE_INVALID_DATA+companyInput.get("nullValues"));			

			}else if(e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)){
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ERROR_NOT_ADMIN);			

			}else if(e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_EMPTY)){
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_EMPTY);			

			}else if(e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)){
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_INVALID);			

			}else if(e.getMessage().contains(ResponseMessage.ERROR_COMPANY_EXISTS)){
				logger.error(ResponseMessage.ERROR_COMPANY_EXISTS);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_COMPANY_EXISTS);			

			}else if(e.getMessage().contains(ResponseMessage.ERROR_COMPANY)){
				logger.error(ResponseMessage.ERROR_COMPANY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_COMPANY);			

			}else {
				logger.error(ResponseMessage.ERROR_COMPANY + " : "+ e.getMessage() +" "+e.getCause());
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_COMPANY);			

			}
			
		} 
  	   
  	
	}                           
	
	/*
	 * Edit company information 
	 * */
	

	
	@RequestMapping(path = "/edit",method = RequestMethod.POST,produces = "application/json")
	@ResponseBody	
	public ResponseBean edit(HttpServletRequest request){

		JSONObject jsonObject = null;
		Company company=null;
		HashMap<String, Object> companyInput = new HashMap<String, Object>();

	 	 	 try{
	 	 		 // Get the json input
	 	 		 jsonObject = adminService.getJsonInputFromRequest(request);
     	         // get the usertoken to validate the user
	 	 		 String userToken = jsonObject.has("userToken")?jsonObject.getString("userToken"):"";
	 	         //get the company input from the json
	 	 		 companyInput = adminService.getInputFromJson(jsonObject,true);
	 	         
		           if(userToken == null || (userToken !=null && userToken.equals(""))){
		        	   throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
		           }else if(!userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)){
		        	   throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
			   		}else if(!userService.checkAdminToken(userToken)){
		        	   throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			   		} 
		           
		          //update the token time
		           userService.updateAdminTokenTime(userToken);
	 	 		 // exception if company input is null
	 	           if(companyInput.get("company") == null){
		        	   throw new Exception(ResponseMessage.ERROR_COMPANY_CREATE_INVALID_DATA);
		           }else{
		        	   
		        	   company = adminService.editcompany(companyInput);
		        	   // exception if company is null
		        	   if(company == null){
		        		   logger.error(ResponseMessage.ERROR_EDIT_COMPANY);
		        		
		        		   throw new Exception(ResponseMessage.ERROR_EDIT_COMPANY);
		        	   }else if(!company.isCompanyExists()){
		        		   // exceptionn if not company exists
		        		   throw new Exception(ResponseMessage.ERROR_COMPANY_DOESNT_EXISTS);
		        	   }else if(!company.isCompanyStatus()){
		        		   //throw exception if company save status is false
		        		   throw new Exception(ResponseMessage.ERROR_EDIT_COMPANY);
		        	   }else {
		        		 //succesfully edite dcompany
		    			   logger.info(ResponseMessage.EDIT_COMPANY);
		    				return CommonUtils.getResponseBean(company, ResponseMessage.EDIT_COMPANY);

		        	   }
		           }
		} catch (Exception e) {

			System.out.println("eee "+e.getMessage());
			if(e.getMessage().contains(ResponseMessage.ERROR_COMPANY_CREATE_INVALID_DATA)){
				logger.error(ResponseMessage.ERROR_COMPANY_CREATE_INVALID_DATA);
			System.out.println(companyInput.get("nullVallues"));
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_COMPANY_CREATE_INVALID_DATA+companyInput.get("nullValues"));			

			}else if(e.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)){
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ERROR_NOT_ADMIN);			

			}else if(e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_EMPTY)){
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_EMPTY);			

			}else if(e.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)){
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_INVALID);			

			}else if(e.getMessage().contains(ResponseMessage.ERROR_COMPANY_DOESNT_EXISTS)){
				logger.error(ResponseMessage.ERROR_COMPANY_DOESNT_EXISTS);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_COMPANY_DOESNT_EXISTS);			

			}else if(e.getMessage().contains(ResponseMessage.ERROR_EDIT_COMPANY)){
				logger.error(ResponseMessage.ERROR_EDIT_COMPANY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_EDIT_COMPANY);			

			}else {
				System.out.println("the company "+company );
				logger.error(ResponseMessage.ERROR_EDIT_COMPANY + " : "+ e.getMessage() +" "+e.getCause());
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_EDIT_COMPANY);			

			}
 		
		} 
	 	 	 
	}                           
	
	
	/*
	 * list the companies and do pagination :: Need to complete
	 * 
	 * 
	 * */
	
	@RequestMapping(path = "/list",method = RequestMethod.POST,produces = "application/json")
	@ResponseBody	
	public ResponseBean listCompanies(HttpServletRequest request){
		 PageRequest page1 =null;
	
		/*JsonObject error;*/
	
		 JSONObject jsonObject = null; 
		 Page<Company> companyList = null;
		 logger.info("Inside list the companies");
	 	 try{
	 		 // get the json object from the request
	 		 jsonObject = adminService.getJsonInputFromRequest(request);
	 		 // Get the usertoken to validate the user
	 		  String userToken = jsonObject.has("userToken")?jsonObject.getString("userToken"):"";
	 		 
	 		 if(userToken == null || (userToken !=null && userToken.equals(""))){
	        	   throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
	           }else if(!userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)){
	        	   throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
		   		}else if(!userService.checkAdminToken(userToken)){
	        	   throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
		   		}	
	 		    //update user token
	 		 	userService.updateAdminTokenTime(userToken);
	 		 	
		 		int pageNumber = jsonObject.has("page")?Integer.parseInt(jsonObject.getString("page")):Integer.valueOf(PAGE);
		 		int limit =  jsonObject.has("limit")?Integer.parseInt(jsonObject.getString("limit")):Integer.valueOf(LIMIT);
		 		String field =  jsonObject.has("sort")?jsonObject.getString("sort"):"";
  			    String direction =  jsonObject.has("dir")?jsonObject.getString("dir"):DIRECTION;
		 		  
		 		if(jsonObject.has("rel")){
		 			if(jsonObject.getString("rel").equals("next"))
		 				pageNumber = pageNumber + 1;
		 			else if (jsonObject.getString("rel").equals("previous"))
		 				pageNumber = pageNumber -1;
		 		
		 		}
		 		if(field.isEmpty()){
		 			 page1 = new PageRequest(
		 					 pageNumber, limit	);
		 		}
		 		else if(!field.isEmpty() && direction.equals("desc")){
			            page1 = new PageRequest(
								  pageNumber, limit, Direction.DESC, field
								);
		 		}else {
		 		    page1 = new PageRequest(
							  pageNumber, limit, Direction.ASC, field 
							);
		 		}
	 	
		 			System.out.println("PAGE ::: "+page1);
		 			companyList = adminService.showCompanies(page1);
		 			if(companyList == null){
		 				logger.info(ResponseMessage.ERROR_SHOW_COMPANIES);
						return CommonUtils.getResponseBean(companyList, ResponseMessage.ERROR_SHOW_COMPANIES);

		 			}else{

				 		   logger.info(ResponseMessage.SHOW_COMPANIES);
							return CommonUtils.getResponseBean(companyList, ResponseMessage.SHOW_COMPANIES);

		 			}
		 			
	 //		return Response.ok(adminService.showCompanies(page1), MediaType.APPLICATION_JSON).build();
		   		//}
	 	 } catch (Exception exception) {
	 		if(exception.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)){
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ERROR_NOT_ADMIN);			

			}else if(exception.getMessage().contains(ResponseMessage.ADMIN_TOKEN_EMPTY)){
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_EMPTY);			

			}else if(exception.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)){
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_INVALID);			

			}else{
				logger.error(ResponseMessage.ERROR_SHOW_COMPANIES);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_SHOW_COMPANIES);			
			}

		 } 

		
	}
	
	/**
	 * Search for the company with respect to the name
	 * 
	 * @returns REsponseBean 
	 * */
	
	@RequestMapping(path = "/search",method = RequestMethod.POST,produces = "application/json")
	@ResponseBody	
	public ResponseBean searchCompany(HttpServletRequest request){
		 Pageable page1 =null;	
	 JSONObject jsonObject = null; 
	 	 try{
	 		// get the json object
	 		jsonObject = adminService.getJsonInputFromRequest(request);
 		    // get the usertoken to validate the user
	 		String userToken = jsonObject.has("userToken")?jsonObject.getString("userToken"):"";
	 		 
	 		 if(userToken == null || (userToken !=null && userToken.equals(""))){
	        	   throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
	           }else if(!userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)){
	        	   throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
		   		}else if(!userService.checkAdminToken(userToken)){
	        	   throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
		   		}	
	 		 
	 		 //update user token
	 		 	userService.updateAdminTokenTime(userToken);
	 		 	 
	 		 
	 		 // get the name to search for
               String name = jsonObject.has("name")?jsonObject.getString("name"):"";
               //Get the pagination details
               int pageNumber = jsonObject.has("page")?Integer.parseInt(jsonObject.getString("page")):Integer.valueOf(PAGE);
               int limit =  jsonObject.has("limit")?Integer.parseInt(jsonObject.getString("limit")):Integer.valueOf(LIMIT);
               String field =  jsonObject.has("sort")?jsonObject.getString("sort"):"";
			    String direction =  jsonObject.has("dir")?jsonObject.getString("dir"):DIRECTION;
	 		  
	 		if(jsonObject.has("rel")){
	 			if(jsonObject.getString("rel").equals("next"))
	 				pageNumber = pageNumber + 1;
	 			else if (jsonObject.getString("rel").equals("previous"))
	 				pageNumber = pageNumber -1;
	 		
	 		}
	 		if(field.isEmpty()){
	 			 page1 = new PageRequest(
	 					 pageNumber, limit	);
	 		}
	 		else if(!field.isEmpty() && direction.equals("desc")){
		            page1 = new PageRequest(
							  pageNumber, limit, Direction.DESC, field
							);
	 		}else {
	 		    page1 = new PageRequest(
						  pageNumber, limit, Direction.ASC, field 
						);
	 		}
 	
	 			logger.debug("PAGE ::: "+page1);
	 		 
				return CommonUtils.getResponseBean(adminService.searchCompany(name,page1), ResponseMessage.SEARCH_COMPANIES);

	 	//	return Response.ok(adminService.searchCompany(name), MediaType.APPLICATION_JSON).build();
	 	 } catch (Exception exception) {
 			// writing exception to log
	 		if(exception.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)){
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ERROR_NOT_ADMIN);			

			}else if(exception.getMessage().contains(ResponseMessage.ADMIN_TOKEN_EMPTY)){
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_EMPTY);			

			}else if(exception.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)){
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_INVALID);			

			}else{
				logger.error(ResponseMessage.ERROR_SEARCH_COMPANIES);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_SEARCH_COMPANIES);			
			}
	 	 } 

		
	}
	
	/**
	 * 
	 * Show the detailed view of company , with respect to the id
	 * 
	 * @return : ResponseBean
	 * */
	@RequestMapping(path = "/view",method = RequestMethod.POST,produces = "application/json")
	@ResponseBody	
	public ResponseBean viewCompany(HttpServletRequest request){
		
		
		
		JSONObject jsonObject = null;
	 	 try{
	 		
	 		
	 		 	// get the json from the request
		 		jsonObject = adminService.getJsonInputFromRequest(request);
		 		// get the id 
		 		long id = jsonObject.has("oid")?Long.valueOf(jsonObject.getString("oid")):0;
		 		logger.debug("id to view   " + id);
		 		//get the usertoken to validate the user 
	 		    String userToken = jsonObject.has("userToken")?jsonObject.getString("userToken"):"";
		 		 
		 		 if(userToken == null || (userToken !=null && userToken.equals(""))){
		        	   throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
		           }else if(!userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)){
		        	   throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
			   		}else if(!userService.checkAdminToken(userToken)){
		        	   throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			   		}	
		 		 
		 		 //update user token
		 		 	userService.updateAdminTokenTime(userToken);
		 		 
		 		   logger.info(ResponseMessage.VIEW_COMPANY);
		 		   
					return CommonUtils.getResponseBean(adminService.viewCompany(id), ResponseMessage.VIEW_COMPANY);

//	 		return Response.ok(adminService.viewCompany(Long.valueOf(jsonObject.getString("id"))), MediaType.APPLICATION_JSON).build();
	 	 } catch (Exception exception) {if(exception.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)){
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ERROR_NOT_ADMIN);			

			}else if(exception.getMessage().contains(ResponseMessage.ADMIN_TOKEN_EMPTY)){
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_EMPTY);			

			}else if(exception.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)){
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_INVALID);			

			}else{
				logger.error(ResponseMessage.ERROR_VIEW_COMPANY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_VIEW_COMPANY);			
			}

		 } 

		
	}
	
	
	/**
	 * 
	 * Delete the  company,
	 * @returns ResponseBean
	 *  
	 * */
	@RequestMapping(path = "/delete",method = RequestMethod.POST,produces = "application/json")
	@ResponseBody	
	public ResponseBean deleteCompany(HttpServletRequest request){
		
		
		
		JSONObject jsonObject = null;
		Company company = null;
	 	 try{
	 		
	 		
	 		 	// get the json object
		 		jsonObject = adminService.getJsonInputFromRequest(request);
		 		// get the id
		 		long id = jsonObject.has("oid")?Long.valueOf(jsonObject.getString("oid")):0;
		 	    // get the user token to validate the user
 	 		    String userToken = jsonObject.has("userToken")?jsonObject.getString("userToken"):"";
		 		 
		 		 if(userToken == null || (userToken !=null && userToken.equals(""))){
		        	   throw new Exception(ResponseMessage.ADMIN_TOKEN_EMPTY);
		           }else if(!userService.isSuperAdmin(userToken, ROLE_SUPER_ADMIN)){
		        	   throw new Exception(ResponseMessage.ERROR_NOT_ADMIN);
			   		}else if(!userService.checkAdminToken(userToken)){
		        	   throw new Exception(ResponseMessage.ADMIN_TOKEN_INVALID);
			   		}

		 		 //update user token
		 		 	userService.updateAdminTokenTime(userToken);
		 		 
		 		   company = adminService.deleteCompany(id);
		 		   if(company != null){
		 			   if(!company.isCompanyExists()){
		 				   throw new Exception(ResponseMessage.ERROR_COMPANY_DOESNT_EXISTS);
		 			   }
		 		   }else{
		 			  throw new Exception(ResponseMessage.ERROR_COMPANY_DOESNT_EXISTS);
		 		   }
		 		   logger.info(ResponseMessage.DELETE_COMPANY);
					return CommonUtils.getResponseBean(company, ResponseMessage.DELETE_COMPANY);

//	 		return Response.ok(adminService.viewCompany(Long.valueOf(jsonObject.getString("id"))), MediaType.APPLICATION_JSON).build();
	 	 } catch (Exception exception) {if(exception.getMessage().contains(ResponseMessage.ERROR_NOT_ADMIN)){
				logger.error(ResponseMessage.ERROR_NOT_ADMIN);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ERROR_NOT_ADMIN);			

			}else if(exception.getMessage().contains(ResponseMessage.ADMIN_TOKEN_EMPTY)){
				logger.error(ResponseMessage.ADMIN_TOKEN_EMPTY);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_EMPTY);			

			}else if(exception.getMessage().contains(ResponseMessage.ADMIN_TOKEN_INVALID)){
				logger.error(ResponseMessage.ADMIN_TOKEN_INVALID);
				return CommonUtils.getErrorResponseBean(ResponseStatus.ADMIN_INVALID, ResponseMessage.ADMIN_TOKEN_INVALID);			

			}else{
				logger.error(ResponseMessage.ERROR_COMPANY_DOESNT_EXISTS);
				return CommonUtils.getErrorResponseBean(ResponseStatus.FAILURE, ResponseMessage.ERROR_COMPANY_DOESNT_EXISTS);			
			}

		 } 

		
	}
	

}

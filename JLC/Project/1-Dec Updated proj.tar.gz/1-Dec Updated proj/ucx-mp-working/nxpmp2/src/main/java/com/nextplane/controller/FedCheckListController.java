package com.nextplane.controller;

/**
 * Module       : Fed Check List management
 * Class        : FedCheckListController
 * 
 * Created Date : 20/09/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;

import com.nextplane.CommonUtils;
import com.nextplane.model.CheckListInstance;
import com.nextplane.model.FedCheckListGroup;
import com.nextplane.model.PendingFederation;
import com.nextplane.model.ResponseBean;
import com.nextplane.model.SearchValue;
import com.nextplane.service.FedCheckListService;

@Controller
@RequestMapping(value = "/fedCheckList")
public class FedCheckListController {
	
	@Autowired
	private FedCheckListService fedCheckListService;
	
	/**
	 * 
	 * @param searchValue
	 * @return
	 */
	@RequestMapping(value = "/getFedCheckList", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean getFedCheckList(@RequestBody SearchValue searchValue) {
		List<FedCheckListGroup> fedCheckListGroup = fedCheckListService.getCheckLists(searchValue.getpendingFederationId());
   		return CommonUtils.getResponseBean(fedCheckListGroup, "");   			
	}	
	
	/**
	 * 
	 * @param searchValue
	 * @return
	 */
	@RequestMapping(value = "/createCheckList", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean createCheckList(@RequestBody PendingFederation pendingFederation) {
		List<FedCheckListGroup> fedCheckListGroup = null;//fedCheckListService.createCheckLists(pendingFederation);
   		return CommonUtils.getResponseBean(fedCheckListGroup, "");   			
	}	
	
	/**
	 * 
	 * @param searchValue
	 * @return
	 */
	@RequestMapping(value = "/updateCheckLists", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean updateCheckLists(@RequestBody SearchValue searchValue, HttpServletRequest request, HttpServletResponse response, @RequestHeader(value = "uri") String uri) {
		PendingFederation pendingFederaton = fedCheckListService.updateCheckLists(searchValue, uri);
   		return CommonUtils.getResponseBean(pendingFederaton, "");   			
	}	
	
	/**
	 * 
	 * @param searchValue
	 * @return
	 */
	@RequestMapping(value = "/getPendingCheckLists", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseBean getPendingCheckLists(@RequestBody SearchValue searchValue) {
		List<CheckListInstance> checkListInstance = fedCheckListService.getPendingCheckLists(searchValue);
   		return CommonUtils.getResponseBean(checkListInstance, "");   			
	}
}
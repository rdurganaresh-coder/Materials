package com.nextplane.controller;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.nextplane.CommonUtils;
import com.nextplane.Constants.PolicyMessage;
import com.nextplane.Constants.ResponseStatus;
import com.nextplane.model.HashingMember;
import com.nextplane.model.ResponseBean;
import com.nextplane.service.PolicyService;

/**
 * Module       : Policy management
 * Class        : PolicyController
 * 
 * Created Date : 14/11/2016
 * Created By   : SVCIT NXPMP3
 */

@Controller
@RequestMapping(value = "/policy")
public class PolicyController {
	
	@Autowired
	private PolicyService policyService;

	private static final Logger logger = LogManager.getLogger(PolicyController.class);
/*
	@RequestMapping(path = "/getPolicyPage", method = RequestMethod.POST)
	public @ResponseBody ResponseBean getPolicyPage(@RequestHeader(value="userToken", required=true) String userToken) throws IOException {
		
		return CommonUtils.getResponseBean(hashingMember, PolicyMessage.FILE_UPLOADED);
	}*/
	
	
	/**
	 * 
	 * @param file
	 * @param processId
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(path = "/hashFileMembers", method = RequestMethod.POST)
	public @ResponseBody ResponseBean hashMembers(@RequestParam("file") MultipartFile file, @RequestParam("processId") Long processId, @RequestHeader(value="userToken", required=true) String userToken) throws IOException {
		if (!file.isEmpty()) {
			HashingMember hashingMember = policyService.gethashMembers(userToken, file, processId);
			return CommonUtils.getResponseBean(hashingMember, PolicyMessage.FILE_UPLOADED);
		} else {
			return CommonUtils.getResponseBean(ResponseStatus.FAILURE, PolicyMessage.FILE_EMPTY);
		}
	}
	
	/**
	 * 
	 * @param hashingMember
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(path = "/hashListMembers", method = RequestMethod.POST)
	public @ResponseBody ResponseBean hashListMembers(@RequestBody HashingMember hashingMember, @RequestHeader(value="userToken", required=true) String userToken) throws IOException {
		if (hashingMember.getListMembers() != null) {
			List<String> invalidMembers = policyService.saveHashMembers(hashingMember);
			return CommonUtils.getResponseBean(invalidMembers, PolicyMessage.FILE_UPLOADED);
		} else {
			return CommonUtils.getResponseBean(ResponseStatus.FAILURE, PolicyMessage.FILE_EMPTY);
		}
	}

	
	/**
	 * 
	 * @param hashingMember
	 * @param userToken
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(path = "/saveMembers", method = RequestMethod.POST)
	public @ResponseBody ResponseBean saveMembers(@RequestBody HashingMember hashingMember, @RequestHeader(value="userToken", required=true) String userToken) throws IOException {
		if (hashingMember.getProcessId() != null) {
			Boolean flag = policyService.saveMembers(hashingMember.getProcessId());
			return CommonUtils.getResponseBean(flag, PolicyMessage.FILE_UPLOADED);
		} else {
			return CommonUtils.getResponseBean(ResponseStatus.FAILURE, PolicyMessage.FILE_EMPTY);
		}
	}
}

package com.nextplane.repository;

import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.Company;
import com.nextplane.model.CompanyInfo;

public interface CompanyInfoRepository extends CrudRepository<CompanyInfo, Long> {

	
	void delete(CompanyInfo companyInfo);
	
	CompanyInfo findByCompanyid(Company company);
	void deleteAllByCompanyid(Company company);
	
	
}

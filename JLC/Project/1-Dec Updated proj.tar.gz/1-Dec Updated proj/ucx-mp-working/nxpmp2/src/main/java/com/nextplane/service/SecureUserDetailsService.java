package com.nextplane.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.nextplane.model.NXPMPReference;
import com.nextplane.model.UserRoleMapping;
import com.nextplane.repository.NXPMPReferenceRepository;
import com.nextplane.repository.UserRoleMappingRepository;
import com.nextplane.repository.UserRepository;
@Service
public class SecureUserDetailsService implements UserDetailsService{

	
	@Autowired
	UserRepository userrepo;
	@Autowired
	UserRoleMappingRepository repo;
	@Autowired
	NXPMPReferenceRepository refrepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws
	UsernameNotFoundException {
	com.nextplane.model.User user = userrepo.findByUsername(username);
	if (user == null) {
	throw new UsernameNotFoundException("Username " + username + " not found");
	}
	return new User(username, "password", getGrantedAuthorities(username));
	}
	private List<? extends GrantedAuthority> getGrantedAuthorities(String
	username ) {

		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		com.nextplane.model.User user = userrepo.findByUsername(username);
		List<NXPMPReference> roles = refrepo.findByType("role");
		
		for(NXPMPReference roleid : roles){
			UserRoleMapping role  = repo.findByUserAndRole(user, roleid);
		//	UserRoleMapping role  = repo.findBySecUserIdAndSecRoleId(user, roleid);
			
			if(role != null ){
			//	authorities.add(new SimpleGrantedAuthority(role.getSecRoleId().getLname()));
				authorities.add(new SimpleGrantedAuthority(role.getRole().getLname()));
			}
		}

		return authorities;

	}
	


}

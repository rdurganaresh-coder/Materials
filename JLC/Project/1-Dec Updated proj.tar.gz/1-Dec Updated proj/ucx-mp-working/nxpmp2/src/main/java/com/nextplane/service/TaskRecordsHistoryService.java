package com.nextplane.service;

/**
 * Module       : Task History management
 * Class        : Task Records History Service
 * 
 * Created Date : 24/08/2016
 * Created By   : SVCIT NXPMP3
 */

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nextplane.model.TaskRecordsHistory;
import com.nextplane.repository.TaskRecordsHistoryRepository;

@Service
public class TaskRecordsHistoryService {

	@Autowired
	TaskRecordsHistoryRepository taskRecordsHistoryRepository;

	public TaskRecordsHistory createTask(TaskRecordsHistory taskHistory) {
		return taskRecordsHistoryRepository.save(taskHistory);
	}
}

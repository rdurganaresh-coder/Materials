package design_patterns;

import java.util.*;

// ═══════════════════════════════════════════════════════════
// SINGLETON PATTERN
// ═══════════════════════════════════════════════════════════
final class AppConfig {
    private final Map<String, String> settings = new HashMap<>();

    private AppConfig() {
        settings.put("app.name",    "Java OOP Demo");
        settings.put("app.version", "1.0.0");
        settings.put("db.host",     "localhost");
    }

    private static class Holder {
        static final AppConfig INSTANCE = new AppConfig();
    }

    public static AppConfig getInstance() { return Holder.INSTANCE; }
    public String get(String key)         { return settings.getOrDefault(key, ""); }
    public void   set(String key, String val) { settings.put(key, val); }
}

// ═══════════════════════════════════════════════════════════
// BUILDER PATTERN
// ═══════════════════════════════════════════════════════════
final class Pizza {
    private final String  size;
    private final String  crust;
    private final List<String> toppings;
    private final boolean extraCheese;

    private Pizza(Builder b) {
        this.size        = b.size;
        this.crust       = b.crust;
        this.toppings    = Collections.unmodifiableList(b.toppings);
        this.extraCheese = b.extraCheese;
    }

    @Override
    public String toString() {
        return String.format("Pizza{size=%s, crust=%s, toppings=%s, extraCheese=%s}",
                size, crust, toppings, extraCheese);
    }

    static class Builder {
        private final String size;
        private String crust       = "THIN";
        private List<String> toppings = new ArrayList<>();
        private boolean extraCheese = false;

        Builder(String size) { this.size = size; }

        Builder crust(String c)      { this.crust = c;          return this; }
        Builder topping(String t)    { this.toppings.add(t);    return this; }
        Builder extraCheese()        { this.extraCheese = true; return this; }
        Pizza   build()              { return new Pizza(this); }
    }
}

// ═══════════════════════════════════════════════════════════
// OBSERVER PATTERN
// ═══════════════════════════════════════════════════════════
interface EventListener<T> {
    void onEvent(T event);
}

record OrderEvent(String orderId, String type, double amount) {}

class EventBus<T> {
    private final List<EventListener<T>> listeners = new ArrayList<>();

    void subscribe(EventListener<T> listener)   { listeners.add(listener); }
    void unsubscribe(EventListener<T> listener) { listeners.remove(listener); }
    void publish(T event)                       { listeners.forEach(l -> l.onEvent(event)); }
}

// ═══════════════════════════════════════════════════════════
// STRATEGY PATTERN
// ═══════════════════════════════════════════════════════════
@FunctionalInterface
interface PriceStrategy {
    double calculateTotal(double basePrice, int quantity);

    static PriceStrategy standard()      { return (p, q) -> p * q; }
    static PriceStrategy bulkDiscount()  { return (p, q) -> q >= 10 ? p * q * 0.85 : p * q; }
    static PriceStrategy subscription()  { return (p, q) -> p * q * 0.70; }
}

// ═══════════════════════════════════════════════════════════
// DECORATOR PATTERN
// ═══════════════════════════════════════════════════════════
interface TextProcessor {
    String process(String text);
}

class UpperCaseProcessor implements TextProcessor {
    @Override public String process(String t) { return t.toUpperCase(); }
}

class TrimProcessor implements TextProcessor {
    private final TextProcessor wrapped;
    TrimProcessor(TextProcessor w) { this.wrapped = w; }
    @Override public String process(String t) { return wrapped.process(t.trim()); }
}

class PrefixProcessor implements TextProcessor {
    private final TextProcessor wrapped;
    private final String prefix;
    PrefixProcessor(TextProcessor w, String p) { this.wrapped = w; this.prefix = p; }
    @Override public String process(String t) { return prefix + wrapped.process(t); }
}

// ═══════════════════════════════════════════════════════════
// MAIN DEMO
// ═══════════════════════════════════════════════════════════
public class DesignPatternsDemo {
    public static void main(String[] args) {
        // Singleton
        System.out.println("── Singleton ──");
        AppConfig cfg = AppConfig.getInstance();
        System.out.println(cfg.get("app.name") + " v" + cfg.get("app.version"));
        assert AppConfig.getInstance() == cfg;

        // Builder
        System.out.println("\n── Builder ──");
        Pizza p1 = new Pizza.Builder("LARGE")
                .crust("STUFFED").topping("Pepperoni").topping("Mushrooms").extraCheese().build();
        Pizza p2 = new Pizza.Builder("MEDIUM")
                .topping("Corn").topping("Capsicum").build();
        System.out.println(p1);
        System.out.println(p2);

        // Observer (generic EventBus)
        System.out.println("\n── Observer ──");
        EventBus<OrderEvent> bus = new EventBus<>();
        bus.subscribe(e -> System.out.printf("[Email] Order %s: %s ₹%.2f%n", e.orderId(), e.type(), e.amount()));
        bus.subscribe(e -> System.out.printf("[SMS]   Order %s: %s%n", e.orderId(), e.type()));
        bus.publish(new OrderEvent("ORD-001", "PLACED",    1500.0));
        bus.publish(new OrderEvent("ORD-001", "SHIPPED",   0.0));

        // Strategy
        System.out.println("\n── Strategy ──");
        double price = 100.0;
        int qty      = 12;
        System.out.printf("Standard:     ₹%.2f%n", PriceStrategy.standard().calculateTotal(price, qty));
        System.out.printf("Bulk:         ₹%.2f%n", PriceStrategy.bulkDiscount().calculateTotal(price, qty));
        System.out.printf("Subscription: ₹%.2f%n", PriceStrategy.subscription().calculateTotal(price, qty));

        // Decorator
        System.out.println("\n── Decorator ──");
        TextProcessor processor = new PrefixProcessor(
                new TrimProcessor(new UpperCaseProcessor()), ">>> ");
        System.out.println(processor.process("  hello world  "));
    }
}

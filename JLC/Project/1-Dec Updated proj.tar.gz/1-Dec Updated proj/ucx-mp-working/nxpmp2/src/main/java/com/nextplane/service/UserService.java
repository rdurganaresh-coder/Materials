package com.nextplane.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MediaType;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nextplane.repository.CompanyRepository;
import com.nextplane.repository.EmailContentRepository;
import com.nextplane.repository.NXPMPReferenceRepository;
import com.nextplane.repository.UserRoleMappingRepository;
import com.nextplane.repository.UserRepository;
import com.nextplane.repository.VerifcationTokenRepository;
import com.nextplane.Constants.EmailContents;
import com.nextplane.Constants.MailGunConf;
import com.nextplane.Constants.ResponseMessage;
import com.nextplane.Constants.Roles;
import com.nextplane.model.Company;
import com.nextplane.model.EmailContent;
import com.nextplane.model.EmailParams;
import com.nextplane.model.NXPMPReference;
import com.nextplane.model.UserRoleMapping;
import com.nextplane.model.User;
import com.nextplane.model.VerificationToken;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.core.util.MultivaluedMapImpl;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserRoleMappingRepository mapRepo;
	
	@Autowired
	private CompanyRepository companyrepo;
	
	@Autowired
	private NXPMPService nXPMPService;
	
	@Autowired
    private VerifcationTokenRepository verRepo;
	
	@Autowired
    private JavaMailSender javaMailSender;

	@Autowired
	private EmailContentRepository emailContentRepository;
	
	@Autowired
    private UserRoleMappingRepository userRoleMappingRepository;
	
	@Autowired
    private NXPMPReferenceRepository nXPMPReferenceRepository;

	// Get the values from the properties
	
	@Value("${expiry.time}")
	private String EXPIRY_TIME;

	@Value("${timeout}")
	private String TIMEOUT;
	Logger logger = LogManager.getLogger(UserService.class);

	@Value("${expiry.min}")
	private String EXPIRATION_MIN;

	@Value("${expiry.hours}")
	private String EXPIRATION_HOURS;

	@Value("${expiry.days}")
	private String EXPIRATION_DAYS;

	
	/**
	 * @param user
	 * @return
	 */
	@Transactional
	public User saveUser2(User user){
		
		 User savedUser = userRepository.save(user);
		 
		// System.out.println("user" + savedUser.getRoles());

		 
		return savedUser;
		
	}

	/**
	 * 
	 * @param user
	 * @return
	 */
	@Transactional
	public User updateUser(User user) {
		User currUser = userRepository.findOne(user.getUserid());
		if (currUser != null) {			
			currUser.setUsername(user.getEmail());
			currUser.setEmail(user.getEmail());
			currUser.setFirstname(user.getFirstname());
			currUser.setLastname(user.getLastname());
			currUser.setCompanyId(companyrepo.findById(user.getCompanyId().getId()));			
			userRepository.save(currUser);

			// delete the existing roles from the mapping table
			mapRepo.deleteAllByUser(currUser);
			System.out.println(" In edit");

			// save the user and role mapping
			for (String r : user.getRoleIds()) {
				NXPMPReference role = nXPMPReferenceRepository.findById(Long.parseLong(r));
				UserRoleMapping rolemap = new UserRoleMapping(currUser, role);
				mapRepo.save(rolemap);
			}
			System.out.println(" In edit");
			currUser.setUserStatus(true);
		}
		return currUser;
	}

/*	public Page<User> view(Pageable pageable) {
		return userRepository.findAll(pageable);
	}*/ 
	
	/**
	 * List the users 
	 * */
	public Page<User> view(PageRequest pageable) {
		Page<User> users = null;
		try {
			users = (Page<User>)userRepository.findAll(pageable);
			for(User user : users){
			
				List<NXPMPReference> roles = mapRepo.findRoleById(user);
				user.setRoles(roles);
			}
		
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		return users;
	} 
	
	/**
	 * Login the user
	 * */
	public User doLogin(User user) {
		User userInDB = null;
		User userInDBwithPassword = null;
		try {
			
			userInDB = userRepository.findByUsername(user.getEmail() != null?user.getEmail():user.getUsername());
			// this is to be removed after the development is completed
			userInDBwithPassword = userRepository.findByUsernameAndPassword(user.getEmail() != null?user.getEmail():user.getUsername(),user.getPassword());
			PasswordEncoder encoder = new BCryptPasswordEncoder();
			boolean matches = encoder.matches(user.getPassword(),userRepository.getPassword(user.getUsername()));

			// the second condition is to be removed later after the completeion of development
			if(userInDB != null && matches || userInDBwithPassword != null ){
				user = userInDB;
				user.setUserStatus(true);
				user.setUserToken(UUID.randomUUID().toString());
				user.setTokenTime(new Date());
				userRepository.save(user);
				List<NXPMPReference> roles = new ArrayList<NXPMPReference>();
				if(user != null){
					
					roles = mapRepo.findRoleById(user);
					user.setRoles(roles);
					
				
/*					for(String r : user.getRoleIds()){
						System.out.println("helloo" +r);
						NXPMPReference role = nxprefrepo.findById(Long.parseLong(r));
						System.out.println(role.getDname());
						UserRoleMapping rolemap = new UserRoleMapping(user,role);
						mapRepo.save(rolemap);
						roles.add(role);
					
				}*/
					user.setRoles(roles);
				}
				
			}else {
				user.setUserStatus(false);
				throw new Exception(ResponseMessage.ERROR_LOGIN_INVALID_USER);
			}
			

		} catch (Exception e) {
			
			logger.error(e.getMessage());
		
			
		}
		
		return user;
	} 
	
	public HashMap<Object,Object> getReferencesForUsers(){
		HashMap<Object,Object> userRef = new HashMap<Object,Object>();
		try {
		userRef.put("company",companyrepo.findAllByIsDisabledOrderByName(false));
		userRef.put("roles", nXPMPReferenceRepository.findByType("role"));
		}catch(Exception e){
			throw e;
		}
		
		
		return userRef;
	}
	
	@Transactional
	public User saveUser(User user){
		try {
			System.out.println("The user  ::: " + user);
			user.setUsername(user.getEmail());
			user.setLastlogin(new Date());
			user.setCompanyId(companyrepo.findById(user.getCompanyId().getId()));
			if (userRepository.save(user) != null) {
				// set a status to note that there is no exception while saving
				// the user details
				for (String r : user.getRoleIds()) {
					NXPMPReference role = nXPMPReferenceRepository.findById(Long.parseLong(r));
					UserRoleMapping rolemap = new UserRoleMapping(user, role);
					mapRepo.save(rolemap);
				}
				user.setUserStatus(true);
			} else {
				// set the status to false when there is exception .
				user.setUserStatus(false);
			}

		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			if (userRepository.findByEmail(user.getEmail()) != null) {
				if (mapRepo.findByUser(userRepository.findByEmail(user.getEmail())) != null) {
					mapRepo.deleteAllByUser(userRepository.findByEmail(user.getEmail()));
				}
				userRepository.delete(userRepository.findByEmail(user.getEmail()));
			}
			user.setUserStatus(false);
			logger.error(e.getMessage());
		}
		return user;        
	}
	
	public User findUser(Long id){
		  return userRepository.findOne(id);
		 }
		 
	@Transactional
	public String deleteUser(Long id){
			 
			 try {
				
				 	User user = userRepository.findOne(id);
				 	mapRepo.deleteAllByUser(user);
				 	if(verRepo.findByUser(user) != null)
				 		verRepo.deleteByUser(user);
				 		
				 	userRepository.delete(user);
					
		
				return  "User Deleted for Id"+id;
			} catch (Exception e ) {
				System.out.println("Eooro"+e.getMessage());
			return ResponseMessage.ERROR_USER_NOT_DELETED;
				
			}
		  
		 }
		 
	public User findUser(String email){
		return userRepository.findByEmail(email);
		
	}
	
	
	public Page<User> findUserByName(String firstName,Pageable page){
		Page<User> userList = null;
		System.out.println("inside query"+userRepository.findByFirstnameLikeOrLastnameLikeOrEmailLike(firstName+"%",firstName+"%",firstName+"%",page));
		userList = userRepository.findByFirstnameLikeOrLastnameLikeOrEmailLike(firstName+"%",firstName+"%",firstName+"%",page); 
		System.out.println("userist   "+userList);
		if(userList != null ){
			for(User user :userList){
				System.out.println("inside roles0"+user);
				
				List<NXPMPReference> roles = mapRepo.findRoleById(user);
				user.setRoles(roles);
				System.out.println("Roles :::: "+roles);
			}
		}
		return userList;
		
	}
	
	public User findUser(long id){
		User user = userRepository.findOne(id);
		List<NXPMPReference> roles = mapRepo.findRoleById(user);
		user.setRoles(roles);
		return user;
		
	}

	
	public VerificationToken createToken(User user , String token){
		System.out.println("inside token");
		try{
			 
		VerificationToken vToken = new VerificationToken(token, user,calculateExpiryDate(getExpirationInMinutes(Integer.valueOf(EXPIRATION_MIN),Integer.valueOf(EXPIRATION_HOURS),Integer.valueOf(EXPIRATION_DAYS))));
		verRepo.save(vToken);
		return vToken;
		}catch(Exception e){
		System.out.println(e.getMessage());
			return null;
		}
	}
	
    
		public int getExpirationInMinutes(int minutes,int hours,int days){
			return minutes*hours*days;
		}
	
    private Date calculateExpiryDate(int expiryTimeInMinutes) {
    	System.out.println("expiry in minutes "+expiryTimeInMinutes);
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Timestamp(cal.getTime().getTime()));
        cal.add(Calendar.MINUTE, expiryTimeInMinutes);
        System.out.println("expiry date---------------------------->>> "+cal.getTime());
        return cal.getTime();
    }
	
	

    /**
     * 
     * @param scheme
     * @param servername
     * @param port
     * @param user
     * @return
     */
	public boolean sendEmail(String nxpmpUrl, User user) {

		VerificationToken vToken = createToken(user, UUID.randomUUID()
				.toString());
		String emailFrom = "";
		String MAILGUN_API_KEY = nXPMPReferenceRepository.findByLname(MailGunConf.MAILGUN_API_KEY).getDname();
		String MAILGUN_HOST = nXPMPReferenceRepository.findByLname(MailGunConf.MAILGUN_HOST).getDname();

		System.out.println("The token timeout :::: " + vToken.getExpiryDate());
		// System.out.println("The token .... "+vToken.getToken());

		String url =  nxpmpUrl+"/setpassword?code="+vToken.getToken();

		try {
			String emailBody = "<span style=\"color:#4587f0; font-size:30px;\">Hello "
					+ user.getFirstname() +"!</span><br><br><br>"
					+ "<span style=\"font-size:18px; margin-bottom:6px; font-weight:700;"
					+ " display: inline-block;\">Your account has been created</span><br>"
					+ "Thank you for choosing the Nextplane UC Exchange<br> Federation Service. "
					+ "Your management portal account has<br> been created. "
					+ "Your user name is <strong>"+ user.getEmail() +"</strong>"
					+ "<br><br><br>Next step - Please set your initial password<br>"
					+ "<br><!--[if mso]>"
					+ "<v:roundrect xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" "
					+ "href=\""+ url +"\" style=\"height:40px;v-text-anchor:middle;width:235px;\" arcsize=\"5%\" "
					+ "strokecolor=\"#4587f0\" fillcolor=\"#4587f0\"><w:anchorlock/>"
					+ "<center style=\"color:#ffffff;font-family:Arial, Helvetica, sans-serif;font-size:16px;\">"
					+ "Set yout initial password</center> </v:roundrect><![endif]--> "
					+ "<a href=\""+ url +"\" style=\"-webkit-text-size-adjust:none; mso-hide:all; display: inline-block;background-color: #4587f0; "
					+ "border-color: #4587f0; font-size:14px; color: #fff; "
					+ "border-radius: 2px; font-weight: 500; text-transform: uppercase; "
					+ "padding: 11px 17px; text-align: center; text-decoration:none;\">"
					+ "Set yout initial password</a><br /><br /><br /><br />"
					+ "Regards, The Nextplane team<br>For assistance, contact "
					+ "<a style=\"color:#4587f0; text-decoration:none;\" "
					+ "href=\"mailto:"+ EmailContents.SUPPORTEMAIL +"\">"+ 
					EmailContents.SUPPORTEMAIL +"</a>";

			logger.info("Going to sent mail");

			InputStream is = getClass().getResourceAsStream(
					"../../../templates/setPassword.html");
			System.out.println(is);
			String template = IOUtils.toString(is, "UTF-8");

			if (template != null) {
				template = template.replace("${emailBody}", emailBody);
			}

			logger.debug("Send Signup email to " + user.getEmail());
			// save this in log so we can retrieve the URL FIXME: need to store
			// first vs resend activation link

			NXPMPReference repo = nXPMPReferenceRepository
					.findByLname(EmailContents.EMAILFROM);
			if (repo != null) {
				emailFrom = repo.getDname();
			}

		/*	final MimeMessage mimeMessage = this.javaMailSender
					.createMimeMessage();
			final MimeMessageHelper mailMessage = new MimeMessageHelper(
					mimeMessage, "UTF-8");
			mailMessage.setFrom(emailFrom, "Nextplane");

			mailMessage.setTo(user.getEmail());
			mailMessage.setSubject("Welcome to Nextplane UC Exchange");
			mailMessage.setText(template, true);

			javaMailSender.send(mimeMessage);
*/
			 Client client = Client.create();
		      client.addFilter(new HTTPBasicAuthFilter("api", MAILGUN_API_KEY));

		      WebResource webResource = client.resource("https://api.mailgun.net/v2/"
		          + MAILGUN_HOST + "/messages");

		      MultivaluedMapImpl formData = new MultivaluedMapImpl();
		      formData.add("from", emailFrom); // your host email address
		      formData.add("to", user.getEmail());
		      formData.add("subject", "Welcome to Nextplane UC Exchange");
		      formData.add("html", template);

		      ClientResponse clientResponse = webResource.type(
		          MediaType.APPLICATION_FORM_URLENCODED).post(
		          ClientResponse.class, formData);
		      int status = clientResponse.getStatus();
		      if (status >= 400) {
		        System.out.println(clientResponse.getEntity(String.class));
		      }
			user.setUserStatus(true);

		} catch (Exception e) {
			System.out.println(e.getMessage());

			user.setUserStatus(false);
			if (userRepository.findByEmail(user.getEmail()) != null) {
				if (mapRepo.findByUser(user) != null) {
					mapRepo.deleteAllByUser(user);
				}
				userRepository.delete(user);
			}
		}

		return user.isUserStatus();

	}

	
	public VerificationToken checkVerificationToken(VerificationToken token){
		VerificationToken token1 = verRepo.findByToken(token.getToken());
		System.out.println("token .... "+token.getExpiryDate());
		
		if(token1.getExpiryDate().after(new Date())){
			token.setTimeout(true);
		}
		if(token.getToken().equals(token1.getToken())){
			token.setVerified(false);
		}
		
		
		return token;
	}
	
	public boolean isSuperAdmin(String token , String rolename){		
		boolean isSuperAdmin = false;
		List<NXPMPReference> adminRoles = null;
		User admin = userRepository.findByUserToken(token);			
		if(admin != null ){
			adminRoles = mapRepo.findRoleById(admin);
			for(NXPMPReference role : adminRoles){
				if(role.getLname().equals(rolename)){		
					logger.info("role to be "+rolename+" role of user "+role.getLname());	
					isSuperAdmin = true;					
					break;
				}
			}
		}
		return isSuperAdmin;
	}
	
	public boolean checkAdminToken(String token){
		
		User admin = userRepository.findByUserToken(token);
		
		boolean valid = true;
		
		if(admin == null){
			return false;
		}else if(admin != null ){	
			logger.info("The expiry time "+EXPIRY_TIME);
			
			logger.debug("The expiry time "+TimeUnit.MILLISECONDS.toMinutes(new Date().getTime() - admin.getTokenTime().getTime()));
			if(TimeUnit.MILLISECONDS.toMinutes(new Date().getTime() - admin.getTokenTime().getTime()) >Integer.valueOf(EXPIRY_TIME)){
			valid = false;
			}
		}
		
		return valid;
	}
	
	public boolean updateAdminTokenTime(String token){
		
		User admin = userRepository.findByUserToken(token);
		boolean updated = false;
		
		if(admin == null){
			return false;
		}else{
			try{
			admin.setTokenTime(new Date());
			userRepository.save(admin);
			updated = true;
	  User testAdmin = userRepository.findByUserToken(token);
	  System.out.println("The token time :::::: "+testAdmin.getTokenTime());
			}catch(Exception e){
				updated =  false;
			}
		}
		
		return updated;
	}
	
	/**
	 * 
	 * @param company
	 * @return
	 */
	public List<User> filterByCompany(Company company){
		List<User> userlist = new ArrayList<User>();
		userlist = userRepository.findByCompanyId(company);
		return userlist;	
	}
	
	public JSONObject getJsonInputFromRequest(HttpServletRequest request){

		 try{
			//REad the stream and genereate the JSONObject from it 
		   ServletInputStream sInputStream = request.getInputStream();
	         BufferedReader streamReader = new BufferedReader(new InputStreamReader(sInputStream, "UTF-8"));
	         StringBuilder responseStrBuilder = new StringBuilder();
	         logger.debug("Read the input json ..");
	         String inputStr;
	         while ((inputStr = streamReader.readLine()) != null)
	             responseStrBuilder.append(inputStr);

	         JSONObject jsonObject = new JSONObject(responseStrBuilder.toString());
	         System.out.println(jsonObject);
	         return jsonObject;
		 }catch(Exception e){
			 return new JSONObject();
		 }
		 
	 }

	
	/**
	 * Verifiies the token
	 * @param : token
	 * @return : VerificationToken
	 * */
	public VerificationToken verifyTokenForSignup(String code){
		VerificationToken token = new VerificationToken();
			// get the verification token object 
			token = verRepo.findByToken(code);
			System.out.println("token ...... "+token);
			if(token != null){
				//check the expiry date
				System.out.println("expiry "+token.getExpiryDate());
				if(token.getExpiryDate().compareTo(new Date()) > Integer.valueOf(TIMEOUT)){
				
					token.setTimeout(true);
				}else{
					token.setTimeout(false);
				}
				if(token.getUser() !=null){
					// set the verification cod efor user
					System.out.println("the user "+token.getUser());
					token.getUser().setVerificationToken(code);
				}
				token.setVerified(true);
			}
			else{
				System.out.println("in here"+token);
				if(token !=null)
					token.setVerified(false);
			}				
		return token;
}
	
	/**
	 * @param : String token , password
	 * @return : user
	 * 
	 * Set the password for the user and delete verification token
	 * */
	@Transactional
	public User savePassword(String code ,String password){		
		User user = new User();
		// get the verification object
		VerificationToken token = verRepo.findByToken(code);

		// get e user with te code
		user = token.getUser();
		logger.debug("User  with the code:: " + user.getFirstname());

		PasswordEncoder encoder = new BCryptPasswordEncoder();
		if (user != null) {
			
			// save the password
			user.setPassword(encoder.encode(password));
			user.setUserStatus(true);
			userRepository.save(user);	
			
			//Delete verification token.
			verRepo.deleteById(token.getId());
		}
		return user;
	}

	/**
	 * 
	 * @param token
	 * @return
	 */
	public User getUserFromToken(String token){		
		User user = null;
		user = userRepository.findByUserToken(token);
		return user;
	}
	
	/**
	 * Update manage user
	 * @param user
	 * @return
	 */
	public User updateManageUser(User user){		
		User saveUser = userRepository.findByUserToken(user.getUserToken());
		saveUser.setFirstname(user.getFirstname());
		saveUser.setLastname(user.getLastname());
		saveUser.setMobilephone(user.getMobilephone());
		saveUser.setWorkphone(user.getWorkphone());
		saveUser.setTitle(user.getTitle());
		userRepository.save(saveUser);
		return user;
	}
	
	/**
	 * 
	 * @param token
	 * @param role
	 * @return
	 */
	public Boolean GetTaskRole(String token, String role){
		NXPMPReference rolename = nXPMPReferenceRepository.findByLname(role);
		UserRoleMapping userRole = mapRepo.findByUserAndRole(userRepository.findByUserToken(token), rolename);
		if(userRole == null)			
			return false;
		else			
			return true;
	}	
	
	public List<User> getUserByCompany(Company company){
		List<User> userlist = new ArrayList<User>();
		userlist = userRepository.getUserByCompany(company);
		return userlist;	
	}
	
	public String generateEmailUsers(Company company) {
		String fromEmail = "";
		List<User> user = userRoleMappingRepository.findUserByRoleAndCompany(nXPMPReferenceRepository.findByLname(Roles.ROLE_ADMIN), company);
		System.out.println("company =================="+company);
		for (Iterator<User> iterator = user.iterator(); iterator.hasNext();) {
			User user2 = (User) iterator.next();			
			if(fromEmail.equalsIgnoreCase(""))
				fromEmail = "";
			else
				fromEmail = fromEmail + " , ";
			fromEmail = fromEmail + user2.getEmail();
			System.out.println(fromEmail);
		}
		return fromEmail;
	}	

	/**
	 * 
	 * @param password
	 * check min length 6 max 30
	 * atleast combination uppercase, lowercase letters and (0-9 digit or special character) should be there.
	 * 
	 * @return 
	 */
	public Boolean validatePassword(String password){
	    String regexp = "(?=.*[a-z])(?=.*[A-Z])((?=.*[0-9])|(?=.*[@#$%^&+=]))(?=\\S+$).{6,30}";
	    return password.matches(regexp);	    
    }
	
	/**
	 * 
	 * @param user
	 * @return
	 */
	public Boolean sendPasswordToken(User user){
		if(user != null){
			VerificationToken vToken = createToken(user, UUID.randomUUID().toString());
			String url =  user.getNxpmpUrl()+"/setpassword?code="+vToken.getToken();
			String userName = user.getFirstname()+" "+user.getLastname();
			
			EmailContent email = emailContentRepository.findBySubjectName(EmailContents.RESET_UCADMIN_PASSWORD);
			EmailParams emailParams = new EmailParams(user.getEmail(), userName, email, url);
			nXPMPService.sendMailNotification(emailParams);
			return true;
		}else
			return false;
	}
	
	/**
	 * 
	 * @param email
	 * @return
	 */
	public User findByEmail(String email) {
		return userRepository.findByEmail(email);
	}
	
	/**
	 * 
	 * @param id
	 * @return
	 */
	public User findOne(Long id) {
		return userRepository.findOne(id);
	}
}
package com.nextplane.repository;

import org.springframework.data.repository.CrudRepository;

import com.nextplane.model.EmailContent;

public interface EmailContentRepository extends CrudRepository<EmailContent, Long> {

	EmailContent findBySubjectName(String subject);
	
}

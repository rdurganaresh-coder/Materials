# ☕ Java OOP Masterclass

> A complete, hands-on reference project covering every Object-Oriented Programming concept in Java — from fundamentals to advanced patterns.

---

## 📚 Table of Contents

| # | Topic | File | Concepts Covered |
|---|-------|------|-----------------|
| 1 | [Classes & Objects](docs/01-classes-and-objects.md) | `src/basics/` | Classes, Objects, Constructors, `this`, `static` |
| 2 | [Encapsulation](docs/02-encapsulation.md) | `src/encapsulation/` | Access Modifiers, Getters/Setters, JavaBeans |
| 3 | [Inheritance](docs/03-inheritance.md) | `src/inheritance/` | `extends`, `super`, Method Overriding, Constructor Chaining |
| 4 | [Polymorphism](docs/04-polymorphism.md) | `src/polymorphism/` | Overloading, Overriding, Runtime & Compile-time Polymorphism |
| 5 | [Abstraction](docs/05-abstraction.md) | `src/abstraction/` | Abstract Classes, Abstract Methods, Templates |
| 6 | [Interfaces](docs/06-interfaces.md) | `src/interfaces/` | Interfaces, Default Methods, Functional Interfaces |
| 7 | [Advanced OOP](docs/07-advanced-oop.md) | `src/advanced/` | Inner Classes, Generics, Enums, Records |
| 8 | [Design Patterns](docs/08-design-patterns.md) | `src/design_patterns/` | Singleton, Factory, Builder, Observer, Strategy |
| 9 | [SOLID Principles](docs/09-solid-principles.md) | — | SRP, OCP, LSP, ISP, DIP |
| 10 | [Project: Bank System](docs/10-capstone-project.md) | `src/` | All concepts combined |

---

## 🗂️ Project Structure

```
java-oop-masterclass/
├── README.md                    ← You are here
├── docs/
│   ├── 01-classes-and-objects.md
│   ├── 02-encapsulation.md
│   ├── 03-inheritance.md
│   ├── 04-polymorphism.md
│   ├── 05-abstraction.md
│   ├── 06-interfaces.md
│   ├── 07-advanced-oop.md
│   ├── 08-design-patterns.md
│   ├── 09-solid-principles.md
│   └── 10-capstone-project.md
└── src/
    ├── basics/
    ├── encapsulation/
    ├── inheritance/
    ├── polymorphism/
    ├── abstraction/
    ├── interfaces/
    ├── advanced/
    └── design_patterns/
```

---

## 🚀 How to Use This Project

1. **Read** each `docs/` markdown file for concepts + explanations
2. **Study** the source code in the corresponding `src/` folder
3. **Run** the examples in any Java IDE (IntelliJ, Eclipse, VS Code)
4. **Practice** by modifying and extending the examples

### Requirements
- Java 17+ (uses Records, Sealed Classes, Text Blocks)
- Any Java IDE or `javac` + `java` CLI

---

## 🧠 OOP Pillars at a Glance

```
┌─────────────────────────────────────────────────────┐
│                   OOP PILLARS                       │
├─────────────┬──────────────┬──────────┬─────────────┤
│ ENCAPSULATION│ INHERITANCE  │POLYMORPHISM│ ABSTRACTION│
│             │              │          │             │
│ Bundle data │ Reuse code   │ Many forms│ Hide detail │
│ + methods   │ from parent  │ one name  │ show essence│
│             │              │          │             │
│ private     │ extends      │ overload  │ abstract    │
│ getters     │ super()      │ override  │ interface   │
│ setters     │ @Override    │ casting   │ template    │
└─────────────┴──────────────┴──────────┴─────────────┘
```

---

## 📌 Quick Concept Reference

| Concept | Keyword | Purpose |
|---------|---------|---------|
| Class | `class` | Blueprint for objects |
| Object | `new` | Instance of a class |
| Constructor | Same name as class | Initialize object |
| Inheritance | `extends` | Child reuses parent code |
| Interface | `implements` | Contract a class must follow |
| Abstract | `abstract` | Cannot instantiate, must extend |
| Override | `@Override` | Redefine parent method |
| Overload | Same name, diff params | Multiple method signatures |
| Final | `final` | Prevent extension/override |
| Static | `static` | Belongs to class, not instance |
| Encapsulation | `private` + getters | Data hiding |
| Polymorphism | Parent ref → Child obj | Flexible type references |

---

*Built as a complete Java OOP learning reference. Each section stands alone or flows sequentially.*

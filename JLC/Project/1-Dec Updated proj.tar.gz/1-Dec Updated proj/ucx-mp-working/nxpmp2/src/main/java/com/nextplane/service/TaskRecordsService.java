package com.nextplane.service;

/**
 * Module       : Task management
 * Class        : Task Controller
 * 
 * Created Date : 27/07/2016
 * Created By   : SVCIT NXPMP3
 */

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.nextplane.Constants.Roles;
import com.nextplane.Constants.TaskStatus;
import com.nextplane.Constants.TasksResponseMessage;
import com.nextplane.model.Company;
import com.nextplane.model.NXPMPReference;
import com.nextplane.model.PageableNxp;
import com.nextplane.model.PendingFederation;
import com.nextplane.model.TaskRecords;
import com.nextplane.model.TaskRecordsHistory;
import com.nextplane.model.TaskType;
import com.nextplane.model.UCDomain;
import com.nextplane.model.User;
import com.nextplane.repository.CompanyRepository;
import com.nextplane.repository.NXPMPReferenceRepository;
import com.nextplane.repository.TaskRecordsHistoryRepository;
import com.nextplane.repository.TaskRecordsRepository;
import com.nextplane.repository.UCDomainRepository;
import com.nextplane.repository.UserRepository;

@Service
public class TaskRecordsService {

	@Autowired
	private TaskRecordsRepository tRecordsRepository;

	@Autowired
	private TaskTypeService taskTypeService;
	
	@Autowired
	private CompanyRepository cCompanyRepository;

	@Autowired
	private NXPMPReferenceRepository nXPMPReferenceRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private TaskRecordsHistoryRepository tRecordsHistoryRepository;
	
	@Autowired
	private UserService userService;
	
	@Autowired 
	private UCDomainRepository ucDomainRepository;
	
	@Value("${roles.3}")
	private String rolesSuperAdmin;
	
	private static final Logger logger = LoggerFactory.getLogger(TaskRecordsService.class);
	
	public Long createTask(UCDomain domain, TaskRecords task, int priority) {		

		Long commonTaskValue = null;
		if(domain.getChangeRequestId() == null) {
			NXPMPReference commonTask = nXPMPReferenceRepository.findOneByType(TasksResponseMessage.COMMON_TASK_ID);
			commonTask.setVersion(commonTask.getVersion()+1);
			nXPMPReferenceRepository.save(commonTask);
			commonTaskValue = commonTask.getVersion();
		}else
			commonTaskValue = domain.getChangeRequestId();
				
		TaskType taskType = taskTypeService.findByTypeAndPriority(task.getFormKey(), priority);
		if(taskType != null) {
			TaskRecords taskObj = new TaskRecords(
				task.getAssignedTo(),
				task.getFormKey(),
				task.getTimeAssigned(),
				task.getCompanyId(), 
				task.getSrcDomainId(),
				task.getDestDomainId(), 
				task.getTimeAssigned(), 
				commonTaskValue
			);
			taskObj.setPriority(taskType.getPriority());
			taskObj.setTaskStatus(taskType.getDefultStatus());
			taskObj.setTaskId(taskType);
			tRecordsRepository.save(taskObj); 
		}
		return commonTaskValue;
	}
	
	public Page<TaskRecords> list(Pageable pageable) {
		return tRecordsRepository.findAll(pageable);
	}
	
	public Page<TaskRecords> findByTaskStatus(PageableNxp pageableTask) {
		User user = userRepository.findByUserToken(pageableTask.getUserToken());
		Company userCompnyId = null;
		Page<TaskRecords> allTasks = null;
		String taskRole = "";

		if(user.getCompanyId() != null)
			userCompnyId = user.getCompanyId();
		
		if(userService.isSuperAdmin(pageableTask.getUserToken(), Roles.ROLE_SUPER_ADMIN)) {
			taskRole = Roles.ROLE_SUPER_ADMIN;
			userCompnyId = null;
		}
		else if(userService.isSuperAdmin(pageableTask.getUserToken(), Roles.ROLE_SALES))
			taskRole = Roles.ROLE_SALES;
		else if(userService.isSuperAdmin(pageableTask.getUserToken(), Roles.ROLE_USER))
			taskRole = Roles.ROLE_USER;
		else
			taskRole = "";

		if(userCompnyId == null)
			allTasks = tRecordsRepository.findFedTasksUCX(pageableTask.getvSearch(), taskRole, pageableTask.getPageable());
		else		
			allTasks = tRecordsRepository.findFedTasks(pageableTask.getvSearch(), userCompnyId, taskRole, pageableTask.getPageable());
		return allTasks;
	}

	// For domain task complete
	public TaskRecords updateTasks(long commonTaskId) {
		TaskRecords currentTask = tRecordsRepository.findByTaskIdByOne(commonTaskId,  TaskStatus.PENDING);		
		if(currentTask != null) {
			currentTask.setTaskStatus(TaskStatus.COMPLETED);
			return tRecordsRepository.save(currentTask);
		}
		else
			return currentTask;
	}

	public TaskRecords findById(long id) {
		return tRecordsRepository.findById(id);
	}
	
	public TaskRecords getTaskRecord(long id){		
		return new TaskRecords(userRepository.findOne(id), "/testService/test2", new Date(), cCompanyRepository.findOne(new Long(1)),  new UCDomain(), null, new Date(), null);
	}
	
	public TaskRecords getTaskRecord(long id, String formKey, User user , UCDomain srcDomainId ,UCDomain destDomainId){	
		return(new TaskRecords(user, formKey,new Date() ,user.getCompanyId(), srcDomainId, destDomainId, new Date(),srcDomainId.getChangeRequestId()));
	}
	
	public List<TaskRecords> getTaskRecordsForCommonTaskId(long commonTaskId){
		List<TaskRecords> tasks = null;		
		try {			
			tasks = tRecordsRepository.findByCommonTaskId(commonTaskId);			
		} catch (Exception e) {
			System.out.println("Error :  "+e.getMessage());
		}		
		return tasks;
	}

	public TaskRecordsHistory updateTaskHistory(String type, User createdBy,
			Long dfid, String srcDomain, String destDomain, String description,int srvPort, 
			Date createdTime) {
		TaskRecordsHistory history = null;
		try {
			history = new TaskRecordsHistory(type, createdBy, dfid, srcDomain, destDomain, description, srvPort, createdTime);
			tRecordsHistoryRepository.save(history);
		} catch (Exception e) {
			logger.error("Error  : " + e.getMessage());
		}
		return history;
	}

	public String getReferenceValueForHistory(String type) {
		String refValue = "";
		NXPMPReference ref = nXPMPReferenceRepository.findByLname(type);
		if (ref != null)
			refValue = ref.getDname();
		return refValue;
	}

	public String getDateString(Date date) {
		SimpleDateFormat format = new SimpleDateFormat("MMM d yyyy, hh:mm a");
		String dateString = format.format(date);
		return dateString;
	}

	public List<TaskRecordsHistory> getTaskRecorHistory(String type, Long dfid) {
		List<TaskRecordsHistory> historyLists = null;
		try {
			historyLists = tRecordsHistoryRepository.findAllByDfIdAndType(dfid, type);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return historyLists;
	}

	public List<TaskRecordsHistory> findAllByDfIdAndTypeAndCreatedByNull(String type, Long id) {
		List<TaskRecordsHistory> verificationHistoryLists = null;
		try {
			verificationHistoryLists = tRecordsHistoryRepository.findTop1ByDfIdAndTypeAndCreatedByNullOrderByCreatedTimeDesc(id, type);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return verificationHistoryLists;
	}
	public TaskRecordsHistory updateDNSTaskHistory(String type, User createdBy,
			Long dfid, String srcDomain, String destDomain, String description, Integer srvPort, Integer xmppPort, 
			 Boolean srvPortStatus, Boolean xmppPortStatus, Date createdTime) {
		TaskRecordsHistory history = null;
		try {
			history = new TaskRecordsHistory(type, createdBy, dfid, srcDomain, destDomain, description, 
					 srvPort, xmppPort, srvPortStatus, xmppPortStatus, createdTime);
			tRecordsHistoryRepository.save(history);
		} catch (Exception e) {
			logger.error("Error  : " + e.getMessage());
		}
		return history;
	}
	

	public Long createFederationTask(TaskRecords task, PendingFederation pendingFederation, int priority) {		

		Company userCompnyId = null;
		Long commonTaskValue = null;
		
		//Set common task value if domain/federation already created.
		if(pendingFederation.getCommonTaskId() == null) {
			NXPMPReference commonTask = nXPMPReferenceRepository.findOneByType(TasksResponseMessage.COMMON_TASK_ID);
			commonTask.setVersion(commonTask.getVersion()+1);
			nXPMPReferenceRepository.save(commonTask);
			commonTaskValue = commonTask.getVersion();
		}else
			commonTaskValue = pendingFederation.getCommonTaskId();
			
		TaskType taskType = taskTypeService.findByTypeAndPriority(task.getFormKey(), priority);		
		
		//set company....
		if(taskType.getTaskRole().equalsIgnoreCase(Roles.ROLE_ADMIN_SRC))
			userCompnyId = task.getSrcDomainId().getCompanyid();
		else if(taskType.getTaskRole().equalsIgnoreCase(Roles.ROLE_ADMIN_DESC))
			userCompnyId = task.getDestDomainId().getCompanyid();
		else if(taskType.getTaskRole().equalsIgnoreCase(Roles.ROLE_SUPER_ADMIN))
			userCompnyId = null;
		else userCompnyId = task.getSrcDomainId().getCompanyid();
				
		//Objrct for task creation
		TaskRecords taskObj = new TaskRecords(
			task.getAssignedTo(),
			task.getFormKey(),
			task.getTimeAssigned(),
			userCompnyId, 
			task.getSrcDomainId(),
			task.getDestDomainId(), 
			task.getTimeAssigned(), 
			commonTaskValue
		);
		taskObj.setPriority(taskType.getPriority());
		taskObj.setTaskStatus(taskType.getDefultStatus());
		taskObj.setTaskId(taskType);
		tRecordsRepository.save(taskObj); 
		return commonTaskValue;
	}
	
	//for federation task complete
	public TaskRecords updateCurrentTasks(Long taskId) {
		TaskRecords currentTask = tRecordsRepository.findById(taskId);		
		if(currentTask != null) {
			currentTask.setTaskStatus(TaskStatus.COMPLETED);
			return tRecordsRepository.save(currentTask);
		}
		else
			return currentTask;
	}
	
}

package com.nextplane.repository;

/**
 * Module       : Task management
 * Class        : Task Controller
 * 
 * Created Date : 27/07/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nextplane.model.TaskType;

public interface TaskTypeRepository extends JpaRepository<TaskType, Long> {

	List<TaskType> findByType(String type);
	List<TaskType> findByTypeOrderByPriority(String type);
	TaskType findByTypeAndPriority(String type, int priority);
}

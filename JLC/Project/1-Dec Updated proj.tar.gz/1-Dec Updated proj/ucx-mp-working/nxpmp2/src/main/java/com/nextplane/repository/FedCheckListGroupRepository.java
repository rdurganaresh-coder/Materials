package com.nextplane.repository;

/**
 * Module       : Fed Check List Group management
 * Class        : FedCheckListGroupRepository
 * 
 * Created Date : 20/09/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nextplane.model.FedCheckListGroup;

public interface FedCheckListGroupRepository extends JpaRepository<FedCheckListGroup, Long> {

	List<FedCheckListGroup> findAllByGroupType(String groupType);
}

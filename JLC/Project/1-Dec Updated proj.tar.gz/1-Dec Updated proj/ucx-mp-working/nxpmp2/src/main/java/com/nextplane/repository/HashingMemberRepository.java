package com.nextplane.repository;

/**
 * Module       : Policy management
 * Class        : HashingMemberRepository
 * 
 * Created Date : 24/11/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.nextplane.model.HashingMember;

@Transactional
public interface HashingMemberRepository extends PagingAndSortingRepository<HashingMember, Long> {

	@Query("SELECT emailId FROM HashingMember WHERE processId = ?1")
	List<String> getAllByprocessId(Long processId);
	
	List<HashingMember> findByProcessId(Long processId);

	Integer deleteByProcessId(Long processId);
}
package com.nextplane.model;

public class EmailParams {

	private String emailTo;
	private String subject;
	private String subjectName;
	private String userName;
	private String content;
	private String url;
	
	public String getEmailTo() {
		return emailTo;
	}
	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	public EmailParams(String emailTo,String userName, EmailContent email, String url) {
		super();
		this.emailTo = emailTo;
		this.subject = email.getSubject();
		this.subjectName = email.getSubjectName();
		this.userName = userName;
		this.content = email.getContent();
		this.url = url;
	}
	
	@Override
	public String toString() {
		return "EmailParams [emailTo=" + emailTo + ", subject=" + subject
				+ ", subjectName=" + subjectName + ", userName=" + userName
				+ ", content=" + content + ", url=" + url + "]";
	}	
}

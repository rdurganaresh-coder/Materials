package advanced;

import java.util.*;
import java.util.function.*;

// ── Generic Stack ─────────────────────────────────────────────────
class Stack<T> {
    private final List<T> data = new ArrayList<>();

    public void push(T item) { data.add(item); }

    public T pop() {
        if (isEmpty()) throw new NoSuchElementException("Stack is empty");
        return data.remove(data.size() - 1);
    }

    public T peek() {
        if (isEmpty()) throw new NoSuchElementException("Stack is empty");
        return data.get(data.size() - 1);
    }

    public boolean isEmpty() { return data.isEmpty(); }
    public int     size()    { return data.size(); }

    @Override
    public String toString() { return data.toString(); }
}

// ── Generic Pair (Record) ─────────────────────────────────────────
record Pair<A, B>(A first, B second) {
    public static <X, Y> Pair<X, Y> of(X x, Y y) { return new Pair<>(x, y); }
    public Pair<B, A> swap() { return new Pair<>(second, first); }
}

// ── Enum with abstract method ─────────────────────────────────────
enum MathOp {
    ADD("+")      { @Override public double apply(double a, double b) { return a + b; } },
    SUBTRACT("-") { @Override public double apply(double a, double b) { return a - b; } },
    MULTIPLY("×") { @Override public double apply(double a, double b) { return a * b; } },
    DIVIDE("÷")   {
        @Override public double apply(double a, double b) {
            if (b == 0) throw new ArithmeticException("Division by zero");
            return a / b;
        }
    };

    private final String symbol;
    MathOp(String symbol) { this.symbol = symbol; }

    public abstract double apply(double a, double b);
    @Override public String toString() { return symbol; }
}

// ── Record with validation ────────────────────────────────────────
record Person(String name, int age, String email) {
    public Person {  // compact constructor
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name required");
        if (age < 0 || age > 150)           throw new IllegalArgumentException("Invalid age: " + age);
        if (!email.contains("@"))           throw new IllegalArgumentException("Invalid email");
        name  = name.trim();
        email = email.toLowerCase();
    }

    public boolean isAdult() { return age >= 18; }
}

// ── Main Demo ─────────────────────────────────────────────────────
public class AdvancedDemo {

    // Generic utility method
    public static <T extends Comparable<T>> T clamp(T value, T min, T max) {
        if (value.compareTo(min) < 0) return min;
        if (value.compareTo(max) > 0) return max;
        return value;
    }

    public static void main(String[] args) {
        // Generic Stack
        Stack<String> stack = new Stack<>();
        stack.push("Java");
        stack.push("OOP");
        stack.push("Generics");
        System.out.println("Stack: " + stack);
        System.out.println("Pop:   " + stack.pop());
        System.out.println("Peek:  " + stack.peek());

        System.out.println();

        // Enum with abstract methods
        double a = 10, b = 3;
        for (MathOp op : MathOp.values())
            System.out.printf("%.0f %s %.0f = %.2f%n", a, op, b, op.apply(a, b));

        System.out.println();

        // Records
        Person alice = new Person("Alice Sharma", 28, "Alice@Email.COM");
        System.out.println(alice);
        System.out.println("Adult: " + alice.isAdult());

        // Generic Pair
        Pair<String, Integer> nameAge = Pair.of("Bob", 25);
        System.out.println("Pair: " + nameAge + " | Swapped: " + nameAge.swap());

        // Generic clamp
        System.out.println("Clamp 150 to [0,100]: " + clamp(150, 0, 100));
        System.out.println("Clamp -5  to [0,100]: " + clamp(-5, 0, 100));
        System.out.println("Clamp 50  to [0,100]: " + clamp(50, 0, 100));
    }
}

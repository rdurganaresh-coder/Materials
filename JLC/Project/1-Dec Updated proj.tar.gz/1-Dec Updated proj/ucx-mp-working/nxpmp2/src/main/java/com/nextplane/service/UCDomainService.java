package com.nextplane.service;

/**
 * Module       : UCDomain
 * Class    	: UCDomainService
 * 
 * Created Date : 01/08/2016
 * Created By   : SVCIT NXPMP3
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zendesk.client.v2.Zendesk;
import org.zendesk.client.v2.model.Priority;
import org.zendesk.client.v2.model.Status;
import org.zendesk.client.v2.model.Ticket;
import org.zendesk.client.v2.model.Ticket.Requester;
import org.zendesk.client.v2.model.Type;

import com.nextplane.NXPMPComparator;
import com.nextplane.Constants.DomainMessage;
import com.nextplane.Constants.EmailContents;
import com.nextplane.Constants.Lookups;
import com.nextplane.Constants.Roles;
import com.nextplane.Constants.RunSelftests;
import com.nextplane.Constants.UCID;
import com.nextplane.Constants.ZendeskRef;
import com.nextplane.model.CheckListInstance;
import com.nextplane.model.Company;
import com.nextplane.model.NXPMPReference;
import com.nextplane.model.PageableNxp;
import com.nextplane.model.Runselftest_instance;
import com.nextplane.model.TaskRecordsHistory;
import com.nextplane.model.UCBaseRule;
import com.nextplane.model.UCChecklistGroup;
import com.nextplane.model.UCChecklistRules;
import com.nextplane.model.UCChecklists;
import com.nextplane.model.UCDomain;
import com.nextplane.model.UCPlatform;
import com.nextplane.model.User;
import com.nextplane.repository.ChecklistInstanceRepository;
import com.nextplane.repository.CompanyRepository;
import com.nextplane.repository.NXPMPReferenceRepository;
import com.nextplane.repository.RunselftestRepository;
import com.nextplane.repository.SRVRecordsRepository;
import com.nextplane.repository.TaskRecordsHistoryRepository;
import com.nextplane.repository.TaskRecordsRepository;
import com.nextplane.repository.UCBaseRuleRepository;
import com.nextplane.repository.UCChecklistGroupRepository;
import com.nextplane.repository.UCChecklistRuleRepository;
import com.nextplane.repository.UCDomainRepository;
import com.nextplane.repository.UCPlarformRepository;
import com.nextplane.repository.UserRepository;
import com.nextplane.repository.UserRoleMappingRepository;

@Service
public class UCDomainService {

	Logger logger = LogManager.getLogger(UCDomainService.class);

	@Autowired
	UCPlarformRepository uCPlarformRepository;

	@Autowired
	UCDomainRepository domainRepo;

	@Autowired
	NXPMPReferenceRepository nXPMPReferenceRepository;

	@Autowired
	UCBaseRuleRepository baseRepo;

	@Autowired
	CompanyRepository compRepo;

	@Autowired
	ChecklistInstanceRepository checklistInstanceRepo;

	@Autowired
	private TaskRecordsService taskrecordsService;

	@Autowired
	private CheckListService checkListService;
	
	@Autowired
	NXPMPService nxpmpService;

	@Autowired
	RunselftestRepository selftestRepo;
	
	@Autowired
	TaskRecordsHistoryRepository taskhistoryRepo;
	
	
	@Autowired
	TaskRecordsRepository taskrecordsRepo;

	@Autowired
	UserRoleMappingRepository roleRepo;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UCChecklistGroupRepository uCChecklistGroupRepository;
		
	@Autowired
	private UCChecklistRuleRepository uCChecklistRuleRepository;
	
	@Autowired
	private SRVRecordsRepository sRVRecordsRepository;	

	@Autowired 
	UserRepository userRepository;
	
	@Value("${domainType.1}")
	private String DOMAIN_TYPE;

	@Value("${skype}")
	private String SKYPE;

	@Value("${cisco}")
	private String CISCO;
	
	@Value("${roles.3}")
	private String ROLE_SUPER_ADMIN;

	public List<UCPlatform> getUCDomains() {
		List<UCPlatform> domains = new ArrayList<UCPlatform>();
		try {
			domains = uCPlarformRepository.findUCTypes();
			System.out.println("Domians ..... " + domains);

		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}

		return domains;
	}

	public UCPlatform getUCDomainAndRule(long ucTypeId) {

		UCPlatform ucplatform = null;
		 NXPMPReference rule = null;
		 String[] ruleIds = null;
		 List<UCBaseRule>  ruleLists = new ArrayList<>();
	
		try {
			ucplatform = uCPlarformRepository.findOne(ucTypeId) ;
			if(ucplatform != null){
				
				
				Long baseRuleId = ucplatform.getUcbaseruleid().getId();
				if(baseRuleId != null)
					rule = nXPMPReferenceRepository.findByLname(baseRuleId.toString());
				if(rule != null){
					String  rules = rule.getDname();
					if(rules != null)
						ruleIds = rules.split(","); 	
										
				}
				for(String id : ruleIds){
					UCBaseRule baseRule = baseRepo.findOne(new Long(id));
					if(baseRule != null && baseRule.getId() == 1){
						return ucplatform;
					}else if (baseRule != null && baseRule.getId() == 2){
						return ucplatform;
					}else {
						
						ruleLists.add(baseRule);
					}
				}
				ucplatform.setRuleList(ruleLists);
			}
				
			 return ucplatform;
			
		} catch (Exception e) {
			logger.error("The Exception "+e.getMessage());
			return null;
		}	
	}

	@Transactional
	public UCDomain saveUCDomain(UCDomain ucdomain) {
		UCDomain domain = null;
		int version = 0;
		boolean isEdit = false;
		boolean openFed = false;
		String skypeSRV = "";
		String ciscoSRV = "";
		
		String ucid5 = "";
		String ucid13 = "";
		NXPMPReference srv = nXPMPReferenceRepository.findByLname(SKYPE); 
		if(srv != null)
			skypeSRV = srv.getDname();
		srv = nXPMPReferenceRepository.findByLname(CISCO);
		if(srv != null)
			ciscoSRV = srv.getDname();
		srv = nXPMPReferenceRepository.findByLname(UCID.UCID5);
		if(srv != null)
			ucid5 = srv.getDname();
		srv = nXPMPReferenceRepository.findByLname(UCID.UCID13);
		if(srv != null)
			ucid13 = srv.getDname();

		try {
			// Check if isEdit

			if (ucdomain.getId() != null || ucdomain.getUcid() != null) {
				ucdomain.setId(ucdomain.getUcid());
				isEdit = true;
				domain = domainRepo.findByIdAndEnabled(ucdomain.getId(), true);
			} else {
				domain = domainRepo.findByDomainNameAndEnabled(
						ucdomain.getDomainName(), true);
			}

			// 1 . Check the domain for the Id , name and status

			// throw exception if it already exists if not edit or not exist if
			// edit
			if (isEdit && domain == null)
				throw new Exception(DomainMessage.DOMAIN_NOT_FOUND);
			else if (!isEdit && domain != null) {
				domain.setDomainExists(true);
				throw new Exception(DomainMessage.DOMAIN_EXISTS);

			} else {
				UCPlatform platform = uCPlarformRepository.findById(ucdomain
						.getUcType().getId());

				if (domain == null) {
					domain = new UCDomain();
					// set the domain name and uctype
					domain.setDomainName(ucdomain.getDomainName());
					domain.setCompanyid(ucdomain.getCompanyid());

				} else
					version = domain.getVersion();
				// UCPlatform platform =
				// ucPlatformrepo.findById(ucdomain.getUcType().getId());

				// Get the UCtype and B1aseRule id and check if it 4 or 6
				  if(platform.getUcbaseruleid().getId() == 4 || platform.getUcbaseruleid().getId() == 6) {
						//Check if srv record is empty and throw exception
						if(ucdomain.isSrvRecord() == null){
							domain.setDomainStatus(false);
							throw new Exception(" SRV Record cannot be null ");
						}else{ 
								// check if FQDN is not present and throw exception
								domain.setSrvRecord(ucdomain.getSrvRecord());
								if(!ucdomain.isSrvRecord()){
									if(ucdomain.getFqdn() == null || ucdomain.getFqdn().isEmpty()){
										domain.setDomainStatus(false);
										throw new Exception("FQDN cannot be empty");
									}else{
										System.out.println("inside to set open fed null");
										domain.setFqdn(ucdomain.getFqdn());
										domain.setOpenFed(null);
									}
									
								}else if(ucdomain.isSrvRecord() && platform.getUcbaseruleid().getId() == 4){
									domain.setFqdn(null);
									domain.setOpenFed(null);

								}else if (platform.getUcbaseruleid().getId() == 6){
									//check if open fed is present , else throw exception
									if(ucdomain.isOpenFed() == null ){
										domain.setDomainStatus(false);
										throw new Exception("Open Fed cannot be null ");
									}else{
										domain.setOpenFed(ucdomain.isOpenFed());
										domain.setFqdn(null);
									}
							}
						}
							
					} else if(platform.getUcbaseruleid().getId() == 8){
						//check if fqdn is present else throw exception
						if(ucdomain.getFqdn() == null){
							domain.setDomainStatus(false);
							throw new Exception("FQDN cannot be null");
						}else {
							domain.setFqdn(ucdomain.getFqdn());
							domain.setOpenFed(null);
						}
					}else if (platform.getId() == Integer.parseInt(ucid5)){
						ciscoSRV = ciscoSRV.replace("$domianName", ucdomain.getDomainName());
						domain.setFqdn(ciscoSRV);
						domain.setOpenFed(null);						
					}else if(platform.getId() == Integer.parseInt(ucid13)){
						skypeSRV = skypeSRV.replace("$domianName", ucdomain.getDomainName());						
						domain.setFqdn(skypeSRV);
						domain.setOpenFed(null);
					}
				  
				if (ucdomain.getDomainName() != null && !ucdomain.getDomainName().isEmpty()) {
					domain.setDomainName(ucdomain.getDomainName());
				}

				domain.setEdit(isEdit);
				    
				// update the version
				domain.setVersion(++version);

				/*
				 * // set the domain name and uctype
				 * domain.setUcType(ucdomain.getUcType());
				 * domain.setDomainName(ucdomain.getDomainName());
				 */
				domain.setUcType(platform);

				// set the date
				domain.setDateCreated(new Date());
				domain.setLastUpdated(new Date());

				// set the other properties

				domain.setIsPublicDomain(false);
				domain.setIsActive(false);
				domain.setIsPrivate(false);

				NXPMPReference ref = nXPMPReferenceRepository.findByLname(DOMAIN_TYPE);

				domain.setDomainType(ref);
				domain.setIsNcoreReady(false);

				domain.setDomainStatus(true);
				domain.setEnabled(true);
				domain.setDeactivate(false);
				domain.setLists(null);
				
				// save the domain .
				domainRepo.save(domain);

				if (domain.isOpenFed() == null || !domain.isOpenFed())
					openFed = false;
				else
					openFed = true;

				// delete checklist instance if already exists

				checklistInstanceRepo.deleteByDomainId(domain.getId());

				// add the check lists to checklist instance table and create
				// the task
				checkListService.saveCheckListInstance(domain.getUcType()
						.getId(), openFed, domain.getId(), "DOMAIN", "", null,
						null, new Long(domain.getVersion()), ucdomain
								.getCheckedId());

				// check if all are checked ?
				Long count = checkListService.getUnCheckedCount(domain.getId(),
						false);

				if (count != null && count == 0)
					domain.setAllChecked(true);

			}

			// 2. Check the conditions
			// 2.a - srv record if no : gateway/fqdn is present ?
			// 2.b - srv record if yes : OPen fed is present
			// 2.c - if uctype - 13 or 5 : set the fqdn value

		} catch (Exception e) {
			logger.error("Domain save failed due to  !! " + e.getMessage());
			if (domain != null)
				domain.setDomainStatus(false);
		}

		return domain;
	}

	public UCDomain viewDomain(String userToken, long id) {
		UCDomain domain = null;
		List<CheckListInstance> lists = null;
		List<TaskRecordsHistory> tasks = null;
		List<TaskRecordsHistory> taskVerifylists = null;
		List<UCChecklists> verCheckList = new ArrayList<UCChecklists>();
		
		Runselftest_instance selftest = null ;
		String type = taskrecordsService.getReferenceValueForHistory("DOMAIN");
		String domainName = "";
		Boolean srvCheck = null;
			domain = domainRepo.findById(id);
			if (domain != null) {
				lists = checklistInstanceRepo.findAllByDomainId(domain.getId());
				tasks = taskrecordsService.getTaskRecorHistory(type, domain.getId());
				taskVerifylists = taskrecordsService.findAllByDfIdAndTypeAndCreatedByNull(type, domain.getId());
				selftest = selftestRepo.findByUcdomain(domain.getId());

				if( domain.getDomainName() != null)
					domainName = domain.getDomainName();
				if(domain.getSrvRecord() != null)
					srvCheck = domain.getSrvRecord();
			}
			UCPlatform uCPlatform = uCPlarformRepository.findById(domain.getUcType().getId());

			// For UC in a company
			if(userService.isSuperAdmin(userToken, Roles.ROLE_SUPER_ADMIN))
				domain.setUserList(userService.getUserByCompany(domain.getCompanyid()));
			
			Boolean openFed = false;
			if (domain.getOpenFed() != null)
				openFed = domain.getOpenFed();			
			
			UCChecklistRules uCChecklistRules = uCChecklistRuleRepository.findByUcplatformIdAndOpenFed(uCPlatform, openFed);
			Boolean srvShow;
			if(srvCheck == null)
				srvShow = false;	
			else 
				srvShow = true;
			List <UCChecklistGroup> uCChecklistGroup = uCChecklistGroupRepository.findByGroupTypeAndTypeAndSrvShowOrderByChecklistId(String.valueOf(uCChecklistRules.getChecklistGroup()), Lookups.SRV_VERIFICATION, srvShow);
			List<NXPMPReference> nXPMPReference = nXPMPReferenceRepository.findByType(Lookups.SRV_VALUES);
			List<NXPMPReference> checkNXPMPReference = nXPMPReferenceRepository.findByType(Lookups.CHECK_LIST_VALUES);
			
			if(uCChecklistGroup != null) {
				Set<UCChecklists> ucCheckset = new HashSet<UCChecklists>(); 
				for (Iterator<UCChecklistGroup> iterator = uCChecklistGroup.iterator(); iterator.hasNext();) {
					UCChecklistGroup ucChecklistGroup2 = (UCChecklistGroup) iterator.next();

					if(srvCheck == null)
						ucCheckset.add(ucChecklistGroup2.getChecklistId());	
					else if(srvCheck == false)
						ucCheckset.add(ucChecklistGroup2.getSrvNo());
					else
						ucCheckset.add(ucChecklistGroup2.getSrvYes());	
				}
				List<UCChecklists> ucChecklists = new ArrayList<UCChecklists>(ucCheckset);
				Collections.sort(ucChecklists, new NXPMPComparator());			
				
				for (Iterator<UCChecklists> iterator = ucChecklists.iterator(); iterator.hasNext();) {
					UCChecklists UCChecklists = (UCChecklists) iterator.next();
						
					for (Iterator<NXPMPReference> iterator2 = nXPMPReference.iterator(); iterator2.hasNext();) {
						NXPMPReference nxpmpReference = (NXPMPReference) iterator2.next();
						if(UCChecklists.getDescription().contains(nxpmpReference.getDname())) {							
							UCChecklists.setDescription(UCChecklists.getDescription().replace(nxpmpReference.getDname(), nxpmpReference.getLname()));
						}
						if(UCChecklists.getDescription().contains(Lookups.NXPFS_FQDN))
							UCChecklists.setDescription(UCChecklists.getDescription().replace(Lookups.NXPFS_FQDN, nXPMPReferenceRepository.findByDname(Lookups.NXPFS_FQDN).getLname()));
						
						if(UCChecklists.getDescription().contains(Lookups.DOMAIN_NAME))
								UCChecklists.setDescription(UCChecklists.getDescription().replace(Lookups.DOMAIN_NAME, domainName));
					}					
				verCheckList.add(UCChecklists);
				}
			}

			
			for (Iterator<CheckListInstance> iterator = lists.iterator(); iterator.hasNext();) {
				CheckListInstance checkListInstance = (CheckListInstance) iterator.next();
				UCChecklists UCChecklists = checkListInstance.getChecklistId();			
				for (Iterator<NXPMPReference> iterator2 = checkNXPMPReference.iterator(); iterator2.hasNext();) {
					NXPMPReference nxpmpReference = (NXPMPReference) iterator2.next();				
					if(UCChecklists.getDescription().contains(nxpmpReference.getDname())) {
						String replaceVal = "";
						if(nxpmpReference.getDname().equalsIgnoreCase(Lookups.EDGE_NAME))
							replaceVal = uCPlatform.getEdgename();
						else if(nxpmpReference.getDname().equalsIgnoreCase(Lookups.DOMAIN1_NAME))
							replaceVal = domainName;					
						else if(nxpmpReference.getDname().equalsIgnoreCase(Lookups.DOMAIN2_NAME))
							replaceVal = domainName;
						else
							replaceVal = nxpmpReference.getLname();
						UCChecklists.setDescription(UCChecklists.getDescription().replace(nxpmpReference.getDname(), replaceVal));
					}
					if(UCChecklists.getDescription().contains(Lookups.CUSER_FQDN)) {
						UCChecklists.setDescription(UCChecklists.getDescription().replace(Lookups.CUSER_FQDN, domain.getFqdn()));
					}
				}
			}
			
			domain.setLists(lists);
			domain.setTasklists(tasks);
			domain.setTaskVerifylists(taskVerifylists);
			domain.setSelftestInstance(selftest);
			domain.setSrvVerification(verCheckList);	
		return domain;
	}

	public Page<UCDomain> showDomainsByStatus(Company company,
			boolean isActive, PageRequest page1) {
		Page<UCDomain> domainList = null;
		try {
			if (company == null)
				domainList = domainRepo.findAllByIsActive(isActive, page1);
			else
				domainList = domainRepo.findAllByCompanyidAndIsActive(company,
						isActive, page1);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return domainList;
	}

	public UCDomain getDomainDate(long id) {
		Date d = null;
		UCDomain domain = new UCDomain();
		try {
			d = domainRepo.getDomainDate(id);
			System.out.println("the date ===== " + d);
			domain.setDateCreated(d);

		} catch (Exception e) {
			// TODO: handle exception
		}

		return domain;
	}
// api to send email 
	/**
	 * 
	 * @param domain
	 * @param user
	 * @param type
	 * @param url
	 */
	public void sendNotificationForNewDoman(UCDomain domain, User user, String type, String url){		
		HashMap<String, String> params = new HashMap<String, String>();
		try {
			// get the params for the sending email
			
			   
				if(domain.getDomainName() != null)
				   params.put("domainName", domain.getDomainName());
			   else 
				   params.put("domainName", "NULL");
			   
			   if(domain.getUcType() != null) 
				   params.put("uctype" ,domain.getUcType().getUcname());
			   else
				   params.put("uctype" ,"NULL");
			   
			   if(domain.getCompanyid().getName() != null )
				   params.put("company", domain.getCompanyid().getName());
			   else
				   params.put("company", "NULL");
			   
			   if(domain.getOpenFed() != null)
				   params.put("openfed", domain.getOpenFed().toString());
			   else 
				   params.put("openfed", "NULL");
			   
			   if(domain.getFqdn() != null)
				   params.put("fqdn", domain.getFqdn().toString());
			   else
				   params.put("fqdn", "NULL");
			   
			   if(domain.getSrvRecord() != null)
				   params.put("srvRecord",domain.getSrvRecord().toString());
			   else
				   params.put("srvRecord","NULL");
			   
			   if(domain.getIsPublicDomain() != null)
				   params.put("isPublic", domain.getIsPublicDomain().toString());
			   else
				   params.put("isPublic", "NULL");
			   
			   if(user.getCompanyId().getName() != null)
				   params.put("email", user.getEmail());
			   else
				   params.put("email", "test@svcloudit.com");
			   
			   if(user.getCompanyId().getName() != null)
				   params.put("name", user.getCompanyId().getName());
			   else
				   params.put("name", "");
			   
			   if(url != null && !url.equals("") || url.length() != 0){
				   params.put("url",url);
			   	   params.put("email", getUCXEmail());
			   }else{
				   params.put("url","");
			   } 
			   
			  			   
			   nxpmpService.sendNotification(params, type);
			
			
			
				
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	public Page<UCDomain> listDomains(boolean isActive, Pageable page) {

		Page<UCDomain> domains = null;

		try {

			domains = domainRepo.findAllByIsActive(isActive, page);
		} catch (Exception e) {
			// TODO: handle exception
		}

		return domains;
	}

	public List<CheckListInstance> getChecklistsForDomain(Long domainId) {

		List<CheckListInstance> checklists = null;
		try {

			checklists = checklistInstanceRepo.findAllByDomainId(domainId);
		} catch (Exception e) {
			logger.error("Error in retrieving " + e.getMessage());
		}
		return checklists;
	}

	public UCDomain updateDomainWithCRId(UCDomain domain, Long task) {

		try {

			domain.setChangeRequestId(task);
			domainRepo.save(domain);
		} catch (Exception e) {
			// TODO: handle exception
		}

		return domain;
	}

	
	public UCDomain runSelfTests(boolean addToContacts, boolean confirmAvailable, boolean sendHello,boolean  comfirmResponse , Long ucid){
		UCDomain domain = null;
		
		try {
			domain = domainRepo.findById(ucid);
			
			Runselftest_instance selftest = selftestRepo.findByUcdomain(ucid);
			
			if(selftest == null){
				selftest = new Runselftest_instance(ucid,addToContacts,confirmAvailable,sendHello,comfirmResponse );
			} else{
				selftest.setAddToContactList(addToContacts);
				selftest.setConfirmAvailable(confirmAvailable);
				selftest.setSendHello(sendHello);
				selftest.setComfirmResponse(comfirmResponse);
			}
			
			selftestRepo.save(selftest);
			// check if all the boolean values are set true and update runselftest boolean in domain to true.
			
			if(selftest.isAddToContactList() && selftest.isConfirmAvailable() && selftest.isSendHello() && selftest.isComfirmResponse() ){
				domain.setRunSelfTest(true);
			} else{
				domain.setRunSelfTest(false);
			}
			 domain.setSelftestInstance(selftest);
			 domainRepo.save(domain);
			// update the history 
			
			
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		
		return domain;
	}

	public UCDomain approveDomain(boolean approve, Long ucid) {
		UCDomain domain = null;
		try {

			domain = domainRepo.findById(ucid);
			domain.setIsActive(approve);

			domainRepo.save(domain);
			// update the history

		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return domain;
	}

	public Page<UCDomain> searchDomainsByDomainNameAndStatus(Company company,
			String domainName, boolean isActive, PageRequest page1) {
		Page<UCDomain> domainList = null;
		try {
			if (company == null)
				domainList = domainRepo.findAllByIsActiveAndDomainNameLike(
						isActive, domainName, page1);
			else
				domainList = domainRepo
						.findAllByCompanyidAndIsActiveAndDomainNameLike(
								company, isActive, domainName, page1);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return domainList;
	}

	/*public UCDomain verifyDomain(UCDomain domain, String userToken, boolean verify, Long domainId) throws JSONException {
		try {
			User user = userService.getUserFromToken(userToken);			
			checkListService.saveTaskHistory(domain, domainId, user);
			sendNotificationForNewDoman(domain, user, EmailContents.VERIFICATION, "");
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return domain;
	}
*/
	
	public String getUrlForEmail(String scheme , String servername, String port ,String id){
		String url = scheme + "://" + servername + ":" + port + "domain/approve/"+id;
		
		return url;
		
	}
	
	
	public List<NXPMPReference> getSelftest() {
		List <NXPMPReference> selftests = null;
		try {
			selftests = nXPMPReferenceRepository.findByType(RunSelftests.RUNSELFTEST);
			
			
		} catch (Exception e) {
			logger.error("Exception  .... "+e.getMessage());
		}
		
		return selftests;
	}


	public String getUCXEmail(){
		String email ="";
		try {
			NXPMPReference emailRef = nXPMPReferenceRepository.findByLname(EmailContents.UCXEMAIL);
			
			List<User> users = roleRepo.findByRole(nXPMPReferenceRepository.findByLname(ROLE_SUPER_ADMIN));
			for(User user :users)	{
				email = email+","+user.getEmail();
			}
			
			
			if(emailRef != null){
				email = emailRef.getDname();
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Exception ..."+e.getMessage());
		}
		return email;
	}
	@Transactional
	public UCDomain deleteDomain(Long ucid){
		
		UCDomain domain = null;
		
		try {
			
			domain = domainRepo.findByIdAndIsActiveAndRunSelfTest(ucid, false,false);
			System.out.println(domain.getDomainName());
			if(domain != null){
				taskhistoryRepo.deleteByDfId(ucid);
				taskrecordsRepo.deleteBySrcDomainId(domain);
				checklistInstanceRepo.deleteByDomainId(ucid);
				selftestRepo.deleteByUcdomain(ucid);
				sRVRecordsRepository.deleteByDomainId(domain);
				domainRepo.delete(ucid);
				
			}
			
		} catch (Exception e) {
			logger.error("Exception "+e.getMessage());
		}
		
		return domain;
	}

	public Ticket createZendeskTicket(String subject, String body){
		
		String requester = nXPMPReferenceRepository.findByLname(ZendeskRef.REQUESTER).getDname();
		String url = nXPMPReferenceRepository.findByLname(ZendeskRef.URL).getDname();
		String requesterPassword = nXPMPReferenceRepository.findByLname(ZendeskRef.REQUESTER_PASSWORD).getDname();
		String token = nXPMPReferenceRepository.findByLname(ZendeskRef.TOKEN).getDname();
		Type type = this.getTicketType( nXPMPReferenceRepository.findByLname(ZendeskRef.TICKET_TYPE).getDname());
		Priority priority = this.getTicketPriority( nXPMPReferenceRepository.findByLname(ZendeskRef.TICKET_PRIORITY).getDname());
		
		Long assignee = Long.valueOf(nXPMPReferenceRepository.findByLname(ZendeskRef.ASSIGNEE).getDname());
		
		Zendesk zd = null;
		Ticket ticket = null;

		/*String requester = "zendesksandbox@svcloudit.com";
		String url = "https://nextplane1470323086.zendesk.com";
		String requesterPassword = "NPzen%1234";
		String token = "Vqi09ZVRXHZzpzxati86xIr0ILO7mwptNnznWZ33";
		Long assignee = Long.valueOf("10978301988");
		Zendesk zd = null;
		Ticket ticket = null;
*/		try {
			Requester requesterId = new Requester(requester);
			if( token !=null && token.length() != 0 && requesterPassword != null && requesterPassword.length() != 0){
				zd = new Zendesk.Builder(url)
		        .setUsername(requester)
		        .setPassword(requesterPassword)
		        .setToken(token)
		        .build();
			}else if(token !=null && token.length() != 0 ){
				zd = new Zendesk.Builder(url)
		        .setUsername(requester)
		        .setToken(token)
		        .build();
			} else if(requesterPassword != null && requesterPassword.length() != 0){
				zd = new Zendesk.Builder(url)
		        .setUsername(requester)
		        .setPassword(requesterPassword)
		        .build();
			} else{
				zd = new Zendesk.Builder(url)
		        .setUsername(requester)
		        .build();
			}
			

			//	Assign
			
			ticket = new Ticket(requesterId, subject, null);
			ticket.setRequester(requesterId);
			ticket.setGroupId(new Long(30217967));
			//ticket.setGroupId(new Long(25578825));
			ticket.setAssigneeId(assignee);
			ticket.setDescription(body);
			ticket.setType(type);
			ticket.setPriority(priority);
			//ticket.sets
			zd.createTicket(ticket);
		} catch (Exception e) {
			logger.error("Exception in creating ticket "+e.getMessage());
		} finally{
			zd.close();
		}
		
		
		return ticket;
		
	}

	public Ticket closeZendeskTicket(String domainName){
		Ticket t = null;;
		
		String requester = nXPMPReferenceRepository.findByLname(ZendeskRef.REQUESTER).getDname();
		String url = nXPMPReferenceRepository.findByLname(ZendeskRef.URL).getDname();
		String requesterPassword = nXPMPReferenceRepository.findByLname(ZendeskRef.REQUESTER_PASSWORD).getDname();
		String token = nXPMPReferenceRepository.findByLname(ZendeskRef.TOKEN).getDname();
		Zendesk zd = null;
		try {
			if( token !=null && token.length() != 0 && requesterPassword != null && requesterPassword.length() != 0){
				zd = new Zendesk.Builder(url)
		        .setUsername(requester)
		        .setPassword(requesterPassword)
		        .setToken(token)
		        .build();
			}else if(token !=null && token.length() != 0 ){
				zd = new Zendesk.Builder(url)
		        .setUsername(requester)
		        .setToken(token)
		        .build();
			} else if(requesterPassword != null && requesterPassword.length() != 0){
				zd = new Zendesk.Builder(url)
		        .setUsername(requester)
		        .setPassword(requesterPassword)
		        .build();
			} else{
				zd = new Zendesk.Builder(url)
		        .setUsername(requester)
		        .build();
			}
			//	Assign
			
			for( Ticket ticket : zd.getTickets()){
				
				if(ticket.getSubject() != null && ticket.getSubject().contains(domainName)){
					if(ticket.getStatus() == Status.OPEN ){
						ticket.setStatus(Status.CLOSED);
						zd.updateTicket(ticket);
						t=ticket;
					}
					
				}
			}

		} catch (Exception e) {
			logger.error("Exception in closing the ticket"+e.getMessage());
		}

		
		return t;
		
	}
	
	
	public Type getTicketType(String type){
		
		switch (type) {
		case ZendeskRef.TASK: return Type.TASK;
		case ZendeskRef.PROBLEM: return Type.PROBLEM;
		case ZendeskRef.INCIDENT: return Type.INCIDENT;
		case ZendeskRef.QUESTION: return Type.QUESTION;
		default:return Type.TASK;
			
		}
	}
	public Priority getTicketPriority(String type){
			
		switch (type) {
		case ZendeskRef.HIGH: return Priority.HIGH;
		case ZendeskRef.LOW: return Priority.LOW;
		case ZendeskRef.NORMAL: return Priority.NORMAL;
		case ZendeskRef.URGENT: return Priority.URGENT;
		default:return Priority.NORMAL;
			
		}
	}

	/**
	 * 
	 * @param user
	 * @return
	 * UCX Admin :- Send count of all active domain 12/10/2016
	 */
	public Long getDomainCount (User user){
		Long activeDomainCount = null;		
		if(userService.isSuperAdmin(user.getUserToken() , Roles.ROLE_SUPER_ADMIN))
			activeDomainCount = domainRepo.getCountOfAllDomains();
		else
			activeDomainCount = domainRepo.getCountOfDomains(user.getCompanyId());
		return activeDomainCount;
	}

	public List<UCDomain> getDomainsForFederation(Company company, Pageable page) {
		List<UCDomain> domains = null;
		try {
			Page<UCDomain> doms = domainRepo.findAllByCompanyidAndIsActive(
					company, true, page);
			domains = doms.getContent();
		} catch (Exception e) {
			logger.error("Exception in getting the domains");
		}
		return domains;
	}

	public Page<Company> getDestinationCompaniesForFederation(Long id,Pageable page){
		Page<Company> companies = null;
		try {
			companies = domainRepo.findAllActiveCompanyWithActiveDomains(id,page);
		} catch (Exception e) {
			logger.error("Exception in getting the companies "+e.getMessage());
		}
		return companies;
	}

	public HashMap<String, List<UCDomain>> getDestinationDomainsForSelectedCompanies(
			List<Long> companyIds) {
		HashMap<String, List<UCDomain>> destDomains = new HashMap<String, List<UCDomain>>();

		try {
			for (Long id : companyIds) {
				Company company = compRepo.findById(id);
				if (company != null) {
					Page<UCDomain> domains = domainRepo
							.findAllByCompanyidAndIsActive(company, true, null);
					if (domains != null)
						destDomains
								.put(company.getName(), domains.getContent());

				}

			}

		} catch (Exception e) {
			logger.error("Exception in getting the domains " + e.getMessage());
		}
		return destDomains;

	}
	public Page<Company> searchDestinationCompaniesForFederation(Long id,String companyName,Pageable page){
		Page<Company> companies = null;
		try {
			companies = domainRepo.searchAllActiveCompanyWithActiveDomains(id,companyName,page);
		} catch (Exception e) {
			logger.error("Exception in getting the companies "+e.getMessage());
		}
		return companies;
	}
	
	/**
	 * 
	 * @param user
	 * @return
	 */
	public Long getDomainCountBadge (User user){
		Long activeDomainCount = null;		
		if(userService.isSuperAdmin(user.getUserToken() , Roles.ROLE_SUPER_ADMIN))
			activeDomainCount = domainRepo.getDomainCountBadgeUCX();
		else
			activeDomainCount = domainRepo.getDomainCountBadge(user.getCompanyId());
		return activeDomainCount;
	}

	/**
	 * 
	 * @param pageableNxp
	 * @return
	 */
	public HashMap<String, List<UCDomain>> getAllDomainsAndCompany(PageableNxp pageableNxp) {
		pageableNxp.setPageable();		
		User user = userRepository.findByUserToken(pageableNxp.getUserToken());			
		HashMap<String, List<UCDomain>> destDomains = new HashMap<String, List<UCDomain>>();
		Page<Company> company = null;
		System.out.println("fsdfsdf"+pageableNxp.getvSearch());
		if(!pageableNxp.getvSearch().equalsIgnoreCase("")) {
			System.out.println("fsdfsdf"+pageableNxp.getvSearch());
			company = domainRepo.searchAllActiveCompanyWithActiveDomains(user.getCompanyId().getId(), "%"+pageableNxp.getvSearch()+"%", pageableNxp.getPageable());
		}else
			company = domainRepo.findAllActiveCompanyWithActiveDomains(user.getCompanyId().getId(), pageableNxp.getPageable());
		
		for (Iterator<Company> iterator = company.getContent().iterator(); iterator.hasNext();) {
			Company company2 = (Company) iterator.next();
			if (company2 != null) {
				List<UCDomain> domains = domainRepo.findByCompanyidAndIsActiveOrderByDomainName(company2, true);
				if (domains.size() > 0)
					destDomains.put(company2.getName(), domains);
			}
		}
		return destDomains;

	}
}
package com.nextplane.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nextplane.Constants.CompanyType;
import com.nextplane.model.Company;
import com.nextplane.model.CompanyEntitlements;
import com.nextplane.model.CompanyInfo;
import com.nextplane.model.Companyucsvc;
import com.nextplane.model.NXPMPReference;
import com.nextplane.model.UCSVC;
import com.nextplane.model.UCSVCDetails;
import com.nextplane.model.UCSVCInstance;
import com.nextplane.repository.CompanyInfoRepository;
import com.nextplane.repository.CompanyRepository;
import com.nextplane.repository.CompanyucsvcRepository;
import com.nextplane.repository.NXPMPReferenceRepository;
import com.nextplane.repository.UCSVCInstanceRepository;
import com.nextplane.repository.UCSVCRepository;
import com.nextplane.utils.ValidationUtil;

@Service
@PropertySource("classpath:config.properties")
public class AdministratorService {

	@Autowired
	private NXPMPReferenceRepository ssprepo;

	@Autowired
	private CompanyRepository comprepo;
	
	@Autowired
	private UCSVCRepository ucsvcrepo;
	
	@Autowired
	private CompanyucsvcRepository compucsvcrepo;
	
	@Autowired
	private CompanyInfoRepository infoRepo;
	
	@Autowired
	private UCSVCInstanceRepository ucsvcirepoo;
	
	/* Load the values from the config.properties*/
	
	@Value("${membershipType.2}")
	private  String COMMUNITY_BUSINESS;
	
	@Value("${membershipType.3}")
	private  String COMMUNITY_ENTERPRISE;
	
	@Value("${ucserviceType.3}")
	private  String AV_FED;
	
	@Value("${servicestatusType.2}")
	private  String ACTIVE;
	
	@Value("${companyType.1}")
	private String COMPANY_TYPE;
	
	@Value("${yahoo}")
	private String YAHOO;
	
	@Value("${VoiceAndVideo}")
	private String VOICEANDVIDEO;
	
	
	
	
	Logger logger = LogManager.getLogger("nxpmp.service");
	

	
	/*
	 * Gets the Country , Region, company type , contract type , membershiptype
	 * sponsernames , entitlements, voice and video details
	 * */
	public HashMap<String, Object> getReferencesForAddCompany(){
		HashMap<String, Object> map = new HashMap<String, Object>();
			try{
					
				   map.put("country", ssprepo.findByType("country"));
				   map.put("region", ssprepo.findByType("region"));
				   map.put("companyType", ssprepo.findByType("companyType"));
				   map.put("contractType", ssprepo.findByType("contractType"));
				   map.put("membershipType", ssprepo.findByType("membershipType"));
				   map.put("sponserList", comprepo.getSponsernames(COMMUNITY_BUSINESS,COMMUNITY_ENTERPRISE));
				   map.put("entitlements",ucsvcrepo.getEntitlements());
				   map.put("voiceandvideo", ucsvcrepo.getUCSVCDetailsList());
				   
			 
				

 			}catch(HibernateException he){
 				System.out.println("errpr");
				logger.error(he.getMessage());
			
			}catch (Exception e){
				logger.error(e.getMessage());
			}
			

			
			
			return map;
		}

	

/*
 * Gets the companies to show in the view
 * @param : PageReqest
 * @return : Page<Company>
 */
public Page<Company> showCompanies(PageRequest page1){
	Page<Company> companyList =null ;
	 // List <Company> companyList = new ArrayList<Company>();
		try{
/* Load the companies from the database
 * */
			// companyList=  (Page<Company>)comprepo.findAll(page1);
			companyList = comprepo.findAllByIsDisabled(false,page1);
			System.out.println("Company List " + companyList);
			}catch(HibernateException he){
				System.out.println("error");
			logger.error(he.getMessage());
		
		}catch (Exception e){
			logger.error(e.getMessage());
		}
		

		
		
		return companyList;
	}


/*
 * Gets the companies correponding to the name
 * 
 * @param : String name , Pageable page
 * @return : Page<Company>
 */
public Page<Company> searchCompany(String name,Pageable page){
	
	
	Page<Company> companyList =null ;
	try{
	
		 companyList = comprepo.findAllByNameLike(name+"%",page);
	}catch(DataAccessException de){
		
	}catch(Exception e){
		
	}
	
	return companyList;
	}


/*
 * View  the companies correponding to the id
 */
public HashMap<String, Object> viewCompany1(long id){
	
	HashMap<String, Object> company = new HashMap<String, Object>();
 	try{
 		Company com = comprepo.findById(id);
		company.put("company", com) ;
		company.put("companyInfo", infoRepo.findByCompanyid(com));
		System.out.println("Entiltemnets   "+compucsvcrepo.findByCompanyid(com));
		company.put("companyEntitlements", compucsvcrepo.findByCompanyid(com));
		
		if(company == null)
			 new Exception("There is no Company with the id"+id);
		 

		}catch (Exception e){
			logger.error(e.getMessage());
			System.out.println("errpr");
		}
		

		
		
		return company;
	}


/*
 * View  the companies correponding to the id
 * 
 * @param : long id
 * @return : Company
 */
public Company viewCompany(long id){
	/*
	 * Initialise the objects before values are retrived
	 * */
	Company company = null;
	CompanyInfo companyInfo = null;
	List<Companyucsvc> services = null;
	List<CompanyEntitlements> entitlements = new ArrayList<CompanyEntitlements>();
 	try{
 		// Get the company from DB for the id
 		company = comprepo.findById(id);
		// If company is null throw exception
		if(company == null)
			 new Exception("There is no Company with the id"+id);
		else {
		// Get the company info and the  services entitled for the company	

			companyInfo =  infoRepo.findByCompanyid(company);

			services = compucsvcrepo.findByCompanyid(company);
			if(companyInfo != null){
				// Set the country and region from the company info to display
				
				if(companyInfo.getCountry()!= null && !companyInfo.getCountry().getDname().isEmpty()){
					company.setCountry(companyInfo.getCountry());
				}else{
					company.setCountry(null);
				}
				
				if(companyInfo.getRegion()!= null && !companyInfo.getRegion().getDname().isEmpty()){
					company.setRegion(companyInfo.getRegion());
				}else{
					company.setRegion(null);
				}
				
				
			}
			if(services != null){
				// Set the services information in the company object to display
				for(Companyucsvc service:services){
					long callVoume = 0;
					long serviceId = 0;
					if(service != null){
						if(service.getCallVolume() != null)
							callVoume = service.getCallVolume().getId();
				/*		if(service.getService() != null)
							serviceId = service.getService().getId();
			*/			CompanyEntitlements ce = new CompanyEntitlements(service.getService(), callVoume, service.getYahooUsercount());	
						entitlements.add(ce);
								
					}
					
				}
			}
			
			if(entitlements !=null){
				company.setCompanyEntitlements(entitlements);
			}
			
		}

		}catch (Exception e){
			logger.error(e.getMessage());

		}

		return company;
	}

/***
 * Get the Inputs from the JSON Object
 * @param : JSONObject , boolean isEdit
 * @return HashMap<String,Object>
 */

public HashMap<String, Object> getInputFromJson(JSONObject jsonObject,boolean isEdit){
	 // Get the required info for the Company from the json object
	
	HashMap<String, Object>  ref = new HashMap<String, Object>();
	List<UCSVC> services = new ArrayList<UCSVC>();
	Company company =null;
	CompanyInfo companyInfo  = null;
	boolean valid = false;
	int visible = 0;
	String countryRef="";
	String regionRef="";
	String sponserRef = "";
	boolean isCountry = false;
	boolean isRegion = false;
	boolean isSponser = false;
    NXPMPReference country = null;
    NXPMPReference region = null;
    Long sponser = null;
    try{
    	// get the values from the json object
    	System.out.println("the edit ... "+isEdit);
	    long id =  jsonObject.has("oid")?Long.valueOf(jsonObject.getString("oid")):0;
	    String name = jsonObject.has("name")?jsonObject.getString("name"):"";

	    if(jsonObject.has("sponser")){
	    	isSponser = true;
	    	sponserRef = jsonObject.getString("sponser");
	    	   if(sponserRef== null || sponserRef!=null && sponserRef.isEmpty()){
	    		   
	   	    		sponser = null;
	    	   }
	   	    	else{
	   	    		sponser = Long.parseLong(sponserRef);
	   	    	}
	   	    }
	    
	 
	     
	    
	    int contractTerm =  jsonObject.has("contractTerm")?Integer.parseInt(jsonObject.getString("contractTerm")):0;
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	    Date serviceDate = null;
	    if(jsonObject.has("servicedate"))
	    	serviceDate = formatter.parse(jsonObject.getString("servicedate")); 
	    int licenseCount = jsonObject.has("paidLicense")?Integer.parseInt(jsonObject.getString("paidLicense")):0;
	    int allowedFederations =  jsonObject.has("allowedFederations")?Integer.parseInt(jsonObject.getString("allowedFederations")):0;
	    String orgstatus = jsonObject.has("orgstatus")?jsonObject.getString("orgstatus"):"0";
	    
	    // Get the reference information from the id from json
	    NXPMPReference membershipType =ssprepo.findById(Long.parseLong(jsonObject.has("membershipType")?jsonObject.getString("membershipType"):"0"));
	    NXPMPReference contractType=ssprepo.findById( Long.parseLong(jsonObject.has("contractType")?jsonObject.getString("contractType"):"0"));

	    //set the boolean value : valid to true if orgStatus in json is 1
	    if(orgstatus.isEmpty())
	    	visible = 0;
	    else
	    	visible = Integer.parseInt(orgstatus);
	    
	    if(visible == 0)
	    	valid = false;
	    else if(visible ==1)
	    	valid = true;
	    else
	    	valid = false;
	    	
	
	    String yahooUsers = jsonObject.has("yahoo_users")?jsonObject.getString("yahoo_users"):"0";
	    //set the yahooUsers to 0 if it is empty
	    if(yahooUsers.isEmpty())
	    	yahooUsers = "0";
	    int yahooUserCount = Integer.valueOf(yahooUsers);
	   
	    long voiceandvideo = jsonObject.has("voiceandvideo")?Long.parseLong(jsonObject.getString("voiceandvideo")):0;
		    	
	    
	    if(jsonObject.has("country")){
	    	isCountry = true;
	    	
	    	System.out.println("Edit company ::: "+isCountry);
	    	countryRef =jsonObject.getString("country");
	    	if(countryRef ==null || (countryRef!=null && countryRef.isEmpty()))
		    	country=null;
	    	else 
	    		country= ssprepo.findById(Long.parseLong(countryRef));
		    
	    }
	    if(jsonObject.has("region")){
	    	isRegion = true;
	    	regionRef = jsonObject.getString("region");
    	   if(regionRef ==null || (regionRef!=null && regionRef.isEmpty()))
		    	region = null;
    	   else
    		   region = ssprepo.findById(Long.parseLong(regionRef));
	    }
	    	
	   System.out.println("The country and region ..........."+country +"    region "+region);
	  		// Get the Callvoulme (UCSVCDetails) corresponding to the id in json
	    UCSVCDetails callVolume = ucsvcrepo.getUCSVCDetails(voiceandvideo);
    
	    JSONArray entitlements = jsonObject.has("entitlements")? jsonObject.getJSONArray("entitlements"):null;
	    // Check if it save and the values are not null
	   
	    if(isEdit){
	    	company  = new Company(name, sponser, membershipType, contractType, contractTerm, licenseCount, allowedFederations, getCompanyTypeUCX());
        	/*companyInfo= new CompanyInfo(company, country, getCompanyTypeUCX(), region);
            companyInfo.setLastUpdated(new Date());
*/
	 	    company.setLastUpdated(new Date());
            company.setDisabled(false);
            company.setValid(valid);
	    }	
	    else {
	    	if( ValidationUtil.checkValues(name, membershipType, contractType) == null ||ValidationUtil.checkValues(name, membershipType, contractType).size() == 0 ){
	    
	    	company  = new Company(name, sponser, membershipType, contractType, contractTerm, licenseCount, allowedFederations, getCompanyTypeUCX());
        	companyInfo= new CompanyInfo(company, country, getCompanyInfoTypeUCX(), region);
        	
    	 // Find the renewal date corresponding to the 
    	    Calendar cal = Calendar.getInstance();
    	    cal.setTime(new Date());
    	    cal.add(Calendar.YEAR, contractTerm);
    	// Set the company information for date, disabled , valid etc 
        	company.setDateCreated(new Date());
	 	    company.setLastUpdated(new Date());
            company.setRenewalDate(cal.getTime());
            company.setDisabled(false);
            company.setValid(valid);
         // Set the company info information for date              
        	companyInfo.setDateCreated(new Date());
        	companyInfo.setLastUpdated(new Date());
	    }
	    // Check if it is edit
	         	
	    else{
	    	logger.debug("ValidationUtil.checkValues(name, membershipType, contractType) ::: "+ValidationUtil.checkValues(name, membershipType, contractType));
	    	System.out.println("ValidationUtil.checkValues(name, membershipType, contractType) ::: "+ValidationUtil.checkValues(name, membershipType, contractType));
	    	//Set the company to null if there is error
	    	company = null;
	    }
	    }
        company.setServiceDate(serviceDate);
	   // Set the map with the information to be sent 
	    ref.put("name", name);
	    if(id != 0)
	    	ref.put("id", id);
	    ref.put("company", company);
	    ref.put("entitlements", entitlements);
	    ref.put("nullValues", ValidationUtil.checkValues(name, membershipType, contractType));
	    ref.put("companyInfo",companyInfo);
	    ref.put("yahooUserCount",new Integer(yahooUserCount));
	    ref.put("callVolume", callVolume);
	    if(isCountry)
	    	ref.put("country", country);
	    if(isRegion)
	    	ref.put("region",region);
	    if(isSponser)
	    	ref.put("sponser",sponser);

   }catch(Exception e){
	   System.out.println(e.getMessage());
   }
    
   return ref;
}



/**
 * Save   the company information and the corresponding infortmation in companyucsvc and ucsvc_instance table
 * @param : HashMap<String, Object> companyInput
 * @return : Company
 */
@Transactional
public Company saveCompany(HashMap<String, Object> companyInput){


	    // Get the information from the map
		Company company  = (Company)companyInput.get("company");
		String companyName = (String)companyInput.get("name");
		JSONArray entitlements = (JSONArray)companyInput.get("entitlements");
		CompanyInfo companyInfo = (CompanyInfo)companyInput.get("companyInfo");		
		int yahooUsercount = 0;
		UCSVCDetails callVolume = null;
		Company companyexists = null;
		
	try{
		// Check the db if the company already exists
		if(company.getId() != null)
			companyexists = comprepo.findById(company.getId());
		Company companyexits2 = comprepo.findByName(company.getName());
		// Get the status of the service from the properties file
		NXPMPReference serviceActive = ssprepo.findByLname(ACTIVE);
		// Get the companytype for UCX
		NXPMPReference companyType = getCompanyTypeUCX();
		if(companyexists != null || companyexits2 != null){
			// throw wexceptoin if company already exists
			company.setCompanyExists(true); 
			throw new Exception("Company Already Exists");
		}
		else{
			logger.debug("Going to save the company .... ");
			//if(comprepo.save(company) != null){
			// save company 
			comprepo.save(company);
			// save company info
			infoRepo.save(companyInfo);
			// update the companyucsvc and ucsvc_instnace for the company and the entitlements selected
			// itereate through the selected entitlements
			for(int i =0;i<entitlements.length();i++){
					for(UCSVC service : sortedServices()){
						
					    if(entitlements.get(i) != null){ 
						long entitlementId = Long.parseLong(entitlements.get(i).toString());
						// get the service selected 
					    UCSVC serviceAdded = ucsvcrepo.findOne(entitlementId);
					    if(serviceAdded != null && serviceAdded.getName().equals(service.getName())){
					    	// check if the service is yahoo to set the usercount
					    	if(serviceAdded.getName().equals(YAHOO)){
					    		yahooUsercount = (Integer)companyInput.get("yahooUserCount");
					    		callVolume = null;
					    	}
					    	//check if the service is voice and video to set the call volume
					    	if(serviceAdded.getName().equals(VOICEANDVIDEO)){
					    		callVolume =  (UCSVCDetails)companyInput.get("callVolume");
					    		yahooUsercount = 0;
					    	}
					    	
					    	// Create the companyucsvc object for the service selected and the company
					    	Companyucsvc compucsvc = new Companyucsvc(company, serviceAdded, company.getDateCreated(), true,yahooUsercount,callVolume);
					    	// save the company service record
					    	compucsvcrepo.save(compucsvc);
					    	if(!service.isRequiresProvision()  && ! getServiceAVTestRequirement(service.getId(), company.getId())){
					    	
					    	// Get the ucsvc instance for the service and company
					    	 UCSVCInstance serviceInstance = ucsvcirepoo.findByCompanyIdAndServiceId(company, serviceAdded);
					    	 // if the record is already present set its status to active
					    	 if(serviceInstance != null){
					    		 serviceInstance.setStatus(serviceActive);
					    	 } else {
					    		//create a new service instance with active status
					    		 
					    		 serviceInstance = new UCSVCInstance(company, serviceAdded, serviceActive, company.getDateCreated(), company.getLastUpdated());
					    		 
					    	 }
					    	  // save it to db
					    		ucsvcirepoo.save(serviceInstance);
					    		
					    		}
					    		}
					    	}
	
							
								}
							
					}
			// If all set , set the company save status to true .... 
			company.setCompanyStatus(true);
				//}
			//else{
			//	company.setCompanyStatus(false);
			//}
			
		}
		return company;
				
			}catch (Exception e){
				logger.error("ERRROOORRRRRR IN SAVING COMPANY : "+company+ " due to "+e.getMessage()+" "+e.getCause() );
				
				//set the company save status to false
				company.setCompanyStatus(false);
				
				return company;
				
			}
	
	
	}

	



/*
 * Get the serives sorted by name
 * */
public List<UCSVC> sortedServices() {
	return ucsvcrepo.sortedServices();
	
}

public NXPMPReference getCompanyTypeUCX(){
	return ssprepo.findByLname(COMPANY_TYPE);
}


public NXPMPReference getCompanyInfoTypeUCX(){
	return ssprepo.findByLname(CompanyType.PUBLIC);
}

/*
 * To check if AV Test is needed for the service
 * */
public boolean  getServiceAVTestRequirement(long serviceId , long companyId){
	
		boolean requiresAVTest = false;
		UCSVC ucsvc = ucsvcrepo.findOne(serviceId);
		Company company = comprepo.findById(companyId);
		
		
		if(ucsvc.getUcServiceType() == ssprepo.getUCServiceType(AV_FED)){
			requiresAVTest = true;
			// need to check for AVTestResult --
		}
	
	return requiresAVTest;
}


public Company getCompany(String name){
	
	return comprepo.findByName(name);
}

//name, sponser, membershipTypeId,contractTypeId,contractTerm,startDate,licenseCount,allowedFederations,entitlements

/**
 * Edit the company details
 * 
 * @param : HashMap<String,Object>()
 * @return : Company
 */
@Transactional
public Company editcompany(HashMap<String, Object> companyInput){	
	// Get the company from the DB with the id 
	Company company  = comprepo.findById((Long)(companyInput.containsKey("id")?companyInput.get("id"):0));
	// Get the company info from DB for the comapny

	CompanyInfo companyInfo = infoRepo.findByCompanyid(company);

	logger.info("Company to edit"+company );
	logger.debug("Company to edit"+company );
	
	// Get the information from the map
	JSONArray entitlements = (JSONArray)companyInput.get("entitlements");
	int yahooUsercount = 0;
	UCSVCDetails callVolume = null;

	try{
		//Need to implement to check the version of the edit with the databse version . 
		
		//update the company details
		
		if(company == null){
			// Set the company exists to false and throw exception
			company.setCompanyExists(false);
			throw new Exception("The company doesnt exists !!");
		}else{
			
				// Get the company and company info from the map
				Company updatedCompany = (Company)companyInput.get("company");
				
				if(companyInfo == null){
					
					companyInfo = new CompanyInfo();					
					companyInfo.setCompanyid(company);
					}
		
				logger.info("Company to edit"+company +" with the information from "+updatedCompany);

				// set the updated values of the company from map to the company object
				if(updatedCompany.getName() != null)
					company.setName(updatedCompany.getName());
				if(updatedCompany.getMembershipType() != null)
					company.setMembershipType(updatedCompany.getMembershipType());
				if(updatedCompany.getContractType() != null)
					company.setContractType(updatedCompany.getContractType());
				if(updatedCompany.getContractTerm() != 0)
					company.setContractTerm(updatedCompany.getContractTerm());
				
				if(updatedCompany.getLicenseCount() != null)
					company.setLicenseCount(updatedCompany.getLicenseCount());
				if(updatedCompany.getAllowedFederations() != null)
					company.setAllowedFederations(updatedCompany.getAllowedFederations());
				if(updatedCompany.getServiceDate() != null)
					company.setServiceDate(updatedCompany.getServiceDate());
				
				if(companyInput.containsKey("sponser"))
					company.setSponserId((Long)companyInput.get("sponser"));
				company.setValid(updatedCompany.isValid());
	
				System.out.println("The company info ............"+companyInfo.getCountry());
				// set the updated values of the companyinfo from map to the company object
				if(companyInput.containsKey("country")){
					System.out.println(" companyInput.containsKey(country)  "+companyInput.containsKey("country"));
					companyInfo.setCountry((NXPMPReference)companyInput.get("country"));}
				if(companyInput.containsKey("region")){
					companyInfo.setRegion((NXPMPReference)companyInput.get("region"));}

				System.out.println();
					
				//Get the servce active status and company type
				NXPMPReference serviceActive = ssprepo.findByLname(ACTIVE);
				NXPMPReference companyType = getCompanyTypeUCX();
	
			
				//	if(comprepo.save(company) != null){
				// Update the company and company info
				comprepo.save(company);
				
				if(companyInfo.getDateCreated() == null)
					companyInfo.setDateCreated(new Date());
				if(companyInfo.getLastUpdated() == null)
					companyInfo.setLastUpdated(new Date());
				infoRepo.save(companyInfo);
				
				// remove the serice and company info from the companyucsvc table
				if(compucsvcrepo.findByCompanyid(company) !=null)
					compucsvcrepo.deleteAllByCompanyid(company);
				// update the companyucsvc and ucsvcdetails
				for(int i =0;i<entitlements.length();i++){
					for(UCSVC service : sortedServices()){
					
					    if(entitlements.get(i) != null){ 
							long entitlementId = Long.parseLong(entitlements.get(i).toString());
						    UCSVC serviceAdded = ucsvcrepo.findOne(entitlementId);
						    
						    if(serviceAdded != null && serviceAdded.getName().equals(service.getName())){
						    //Get the yahoousercount / call volume if they are the respective selected service
						    	if(serviceAdded.getName().equals(YAHOO)){
						    		yahooUsercount = (Integer)companyInput.get("yahooUserCount");
						    		callVolume = null;
						    	}
						    	if(serviceAdded.getName().equals(VOICEANDVIDEO)){
						    		callVolume =  (UCSVCDetails)companyInput.get("callVolume");
						    		yahooUsercount = 0;
						    	}
						    	
						    // create the companyucsvc and save	
					    	Companyucsvc compucsvc = new Companyucsvc(company, serviceAdded, company.getDateCreated(), true,yahooUsercount,callVolume);
					    	compucsvcrepo.save(compucsvc);
					    	if(!service.isRequiresProvision()  && ! getServiceAVTestRequirement(service.getId(), company.getId())){
						    	// create the ucsvcinstance and save	
					    	    UCSVCInstance serviceInstance = ucsvcirepoo.findByCompanyIdAndServiceId(company, serviceAdded);
						    	 if(serviceInstance != null){
						    		 serviceInstance.setStatus(serviceActive);
						    	 } else {
						    		//create a new service instance with active status
						    		 
						    		 serviceInstance = new UCSVCInstance(company, serviceAdded, serviceActive, company.getDateCreated(), company.getLastUpdated());
						    		 
						    	 }
						    		ucsvcirepoo.save(serviceInstance);
						    		
						    	}
						    }
						    }
			
								
							}
						}
					// set the status to true if successfuly edited
					company.setCompanyStatus(true);
					company.setCompanyExists(true);
/*		}else{
			company.setCompanyStatus(false);
		}
*/			
		
		}
		return company;
		
		}catch (Exception e){
			logger.error("ERROR Editing the company "+company+" "+e.getMessage()+" "+e.getCause());
			company.setCompanyStatus(false);
			return company;
			
		}
		

		
		
	
	}


public NXPMPReference getReferenceInfo(long id){
	return ssprepo.findById(id);
	
}

/**
 * get the JSONinput from the request object
 * 
 * @param : request
 * @return : JSONObject
 * */
 public JSONObject getJsonInputFromRequest(HttpServletRequest request){

	 try{
		//REad the stream and genereate the JSONObject from it 
	   ServletInputStream sInputStream = request.getInputStream();
         BufferedReader streamReader = new BufferedReader(new InputStreamReader(sInputStream, "UTF-8"));
         StringBuilder responseStrBuilder = new StringBuilder();
         logger.debug("Read the input json ..");
         String inputStr;
         while ((inputStr = streamReader.readLine()) != null)
             responseStrBuilder.append(inputStr);

         JSONObject jsonObject = new JSONObject(responseStrBuilder.toString());
         return jsonObject;
	 }catch(Exception e){
		 return new JSONObject();
	 }
	 
 }

 

 
 /**
  * Delete  the company 
  * 
  * @param : long id
  * @return : Company
  */
 public Company deleteCompany(long id){
 	
 	Company company = null;
 	try{
 		// find the company and set the status to disabled
  		 company = comprepo.findById(id);
  		 if(company == null){
  			 company.setCompanyExists(false);
  		 }else{
  			 company.setCompanyExists(true);
  			 company.setDisabled(true);
  		 }

 		}catch (Exception e){
 			logger.error(e.getMessage());

 		}

 		return company;
 	}

 

}

	

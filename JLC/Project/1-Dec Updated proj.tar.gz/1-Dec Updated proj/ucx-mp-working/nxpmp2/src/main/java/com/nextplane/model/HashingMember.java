package com.nextplane.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

/**
 * Module       : Policy management
 * Class        : Member
 * 
 * Created Date : 15/11/2016
 * Created By   : SVCIT NXPMP3
 */

@Entity
@Table(name = "HashingMember")
public class HashingMember {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;	
	private String firstName;
	private String lastName;
	private String emailId;	
	private Long processId;	

	@Transient
	private MultipartFile file;
	
	@Transient
	private List<String> listMembers;	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Long getProcessId() {
		return processId;
	}
	public void setProcessId(Long processId) {
		this.processId = processId;
	}	
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	public List<String> getListMembers() {
		return listMembers;
	}
	public void setListMembers(List<String> listMembers) {
		this.listMembers = listMembers;
	}
	public HashingMember(){}
	public HashingMember(String firstName, String lastName, String emailId, Long processId) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.processId = processId;
	}
	
	@Override
	public String toString() {
		return "Member [id=" + id + ", firstName=" + firstName + ", lastName="
				+ lastName + ", emailId=" + emailId + "]";
	}	
}